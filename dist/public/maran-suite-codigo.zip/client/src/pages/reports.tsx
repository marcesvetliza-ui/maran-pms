import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  LineChart,
  BarChart,
  PieChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Line,
  Bar,
  Pie,
  Cell,
} from "recharts";
import {
  Download,
  Printer,
  BarChart3,
  TrendingUp,
  Hotel,
  CreditCard,
  Users,
  Brush,
  UtensilsCrossed,
  Globe,
} from "lucide-react";

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
  "#8884d8",
  "#82ca9d",
  "#ffc658",
];

function formatARS(value: number): string {
  return (
    "$ " +
    value
      .toFixed(2)
      .replace(".", ",")
      .replace(/\B(?=(\d{3})+(?!\d))/g, ".")
  );
}

function formatDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function getPresetDates(preset: string): { from: string; to: string } {
  const now = new Date();
  const to = formatDate(now);
  let from: string;
  switch (preset) {
    case "today":
      from = to;
      break;
    case "week": {
      const d = new Date(now);
      d.setDate(d.getDate() - 7);
      from = formatDate(d);
      break;
    }
    case "month": {
      const d = new Date(now);
      d.setMonth(d.getMonth() - 1);
      from = formatDate(d);
      break;
    }
    case "year": {
      const d = new Date(now);
      d.setFullYear(d.getFullYear() - 1);
      from = formatDate(d);
      break;
    }
    default:
      from = to;
  }
  return { from, to };
}

function exportCSV(headers: string[], rows: string[][], filename: string) {
  const csvContent = [
    headers.join(","),
    ...rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")),
  ].join("\n");
  const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${filename}-${formatDate(new Date())}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function LoadingSkeleton() {
  return (
    <div className="space-y-3">
      {[...Array(5)].map((_, i) => (
        <Skeleton key={i} className="h-10 w-full" />
      ))}
    </div>
  );
}

type OccupancyRow = { date: string; available: number; occupied: number; occupancy: number; totalRooms: number };
type RevenueByTypeRow = { type: string; rooms: number; nightsSold: number; revenue: number; adr: number; percentage: number };
type ChannelRow = { source: string; reservations: number; nights: number; revenue: number; commission: number; net: number; percentage: number };
type ReservationRow = { code: string; guest: string; company: string; room: string; type: string; checkIn: string; checkOut: string; nights: number; source: string; status: string; total: number; paid: number; balance: number };
type PaymentMethod = { method: string; count: number; total: number; percentage: number };
type PaymentsData = { byMethod: PaymentMethod[]; grandTotal: number };
type TopGuestRow = { rank: number; guest: string; code: string; stays: number; nights: number; revenue: number; lastVisit: string; segment: string };
type HousekeepingData = { daily: { date: string; completed: number; pending: number; urgent: number }[]; byType: { type: string; count: number }[]; totalCompleted: number; totalPending: number };
type RestaurantData = { totalOrders: number; totalRevenue: number; totalCovers: number; avgTicket: number; topItems: { name: string; count: number; revenue: number }[]; byArea: { name: string; orders: number; revenue: number; covers: number }[] };

export default function ReportsPage() {
  const defaults = getPresetDates("month");
  const [from, setFrom] = useState(defaults.from);
  const [to, setTo] = useState(defaults.to);
  const [activeTab, setActiveTab] = useState("occupancy");
  const [statusFilter, setStatusFilter] = useState("all");

  function applyPreset(preset: string) {
    const d = getPresetDates(preset);
    setFrom(d.from);
    setTo(d.to);
  }

  const fetchReport = async (url: string) => {
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok) throw new Error(`${res.status}: ${await res.text()}`);
    return res.json();
  };

  const occupancy = useQuery<OccupancyRow[]>({
    queryKey: ["/api/reports/occupancy", from, to],
    queryFn: () => fetchReport(`/api/reports/occupancy?from=${from}&to=${to}`),
    enabled: activeTab === "occupancy",
  });

  const revenueByType = useQuery<RevenueByTypeRow[]>({
    queryKey: ["/api/reports/revenue-by-room-type", from, to],
    queryFn: () => fetchReport(`/api/reports/revenue-by-room-type?from=${from}&to=${to}`),
    enabled: activeTab === "revenue-type",
  });

  const byChannel = useQuery<ChannelRow[]>({
    queryKey: ["/api/reports/by-channel", from, to],
    queryFn: () => fetchReport(`/api/reports/by-channel?from=${from}&to=${to}`),
    enabled: activeTab === "channel",
  });

  const reservations = useQuery<ReservationRow[]>({
    queryKey: ["/api/reports/reservations", from, to, statusFilter],
    queryFn: () => fetchReport(`/api/reports/reservations?from=${from}&to=${to}&status=${statusFilter === "all" ? "" : statusFilter}`),
    enabled: activeTab === "reservations",
  });

  const payments = useQuery<PaymentsData>({
    queryKey: ["/api/reports/payments", from, to],
    queryFn: () => fetchReport(`/api/reports/payments?from=${from}&to=${to}`),
    enabled: activeTab === "payments",
  });

  const topGuests = useQuery<TopGuestRow[]>({
    queryKey: ["/api/reports/top-guests", from, to],
    queryFn: () => fetchReport(`/api/reports/top-guests?from=${from}&to=${to}&limit=50`),
    enabled: activeTab === "top-guests",
  });

  const housekeeping = useQuery<HousekeepingData>({
    queryKey: ["/api/reports/housekeeping", from, to],
    queryFn: () => fetchReport(`/api/reports/housekeeping?from=${from}&to=${to}`),
    enabled: activeTab === "housekeeping",
  });

  const restaurant = useQuery<RestaurantData>({
    queryKey: ["/api/reports/restaurant", from, to],
    queryFn: () => fetchReport(`/api/reports/restaurant?from=${from}&to=${to}`),
    enabled: activeTab === "restaurant",
  });

  type BillingPaymentRow = { id: string; reservation_id: string; amount: string; method: string; date: string; reference: string; billing_target: string; reservation_code: string; room_number: string; guest_name: string; company_name: string };
  type BillingData = { payments: BillingPaymentRow[]; summary: { totalPayments: number; totalAmount: number; guestTotal: number; companyTotal: number; byMethod: Record<string, { count: number; total: number }> } };

  const billing = useQuery<BillingData>({
    queryKey: ["/api/reports/billing", from, to],
    queryFn: () => fetchReport(`/api/reports/billing?from=${from}&to=${to}`),
    enabled: activeTab === "billing",
  });

  const handleExportCSV = () => {
    switch (activeTab) {
      case "occupancy":
        if (occupancy.data) {
          exportCSV(
            ["Fecha", "Hab. Disponibles", "Hab. Ocupadas", "% Ocupación"],
            occupancy.data.map((r) => [r.date, String(r.available), String(r.occupied), `${r.occupancy}%`]),
            "ocupacion"
          );
        }
        break;
      case "revenue-type":
        if (revenueByType.data) {
          exportCSV(
            ["Tipo", "Habitaciones", "Noches vendidas", "Revenue", "ADR", "% del total"],
            revenueByType.data.map((r) => [r.type, String(r.rooms), String(r.nightsSold), formatARS(r.revenue), formatARS(r.adr), `${r.percentage}%`]),
            "revenue-por-tipo"
          );
        }
        break;
      case "channel":
        if (byChannel.data) {
          exportCSV(
            ["Canal", "Reservas", "Noches", "Revenue", "Comisión", "Neto", "%"],
            byChannel.data.map((r) => [r.source, String(r.reservations), String(r.nights), formatARS(r.revenue), formatARS(r.commission), formatARS(r.net), `${r.percentage}%`]),
            "por-canal"
          );
        }
        break;
      case "reservations":
        if (reservations.data) {
          exportCSV(
            ["Código", "Huésped", "Empresa", "Habitación", "Tipo", "Check-in", "Check-out", "Noches", "Canal", "Estado", "Total", "Pagado", "Saldo"],
            reservations.data.map((r) => [r.code, r.guest, r.company, r.room, r.type, r.checkIn, r.checkOut, String(r.nights), r.source, r.status, formatARS(r.total), formatARS(r.paid), formatARS(r.balance)]),
            "reservas"
          );
        }
        break;
      case "payments":
        if (payments.data) {
          exportCSV(
            ["Método", "Transacciones", "Monto total", "%"],
            payments.data.byMethod.map((r) => [r.method, String(r.count), formatARS(r.total), `${r.percentage}%`]),
            "pagos"
          );
        }
        break;
      case "top-guests":
        if (topGuests.data) {
          exportCSV(
            ["Ranking", "Huésped", "Código", "Estadías", "Noches", "Revenue", "Última visita", "Segmento"],
            topGuests.data.map((r) => [String(r.rank), r.guest, r.code, String(r.stays), String(r.nights), formatARS(r.revenue), r.lastVisit, r.segment]),
            "huespedes-frecuentes"
          );
        }
        break;
      case "housekeeping":
        if (housekeeping.data) {
          exportCSV(
            ["Tipo de tarea", "Cantidad"],
            housekeeping.data.byType.map((r) => [r.type, String(r.count)]),
            "housekeeping"
          );
        }
        break;
      case "restaurant":
        if (restaurant.data) {
          exportCSV(
            ["Producto", "Cantidad", "Revenue"],
            restaurant.data.topItems.map((r) => [r.name, String(r.count), formatARS(r.revenue)]),
            "restaurante"
          );
        }
        break;
      case "billing":
        if (billing.data) {
          const methodLabels: Record<string, string> = { efectivo: "Efectivo", tarjeta_debito: "Tarjeta Débito", tarjeta_credito: "Tarjeta Crédito", transferencia: "Transferencia", mercadopago: "MercadoPago", cuenta_corriente: "Cta. Corriente" };
          exportCSV(
            ["Fecha", "Reserva", "Habitación", "Huésped", "Empresa", "Método", "Factura a", "Monto", "Referencia"],
            billing.data.payments.map((p) => [
              p.date, p.reservation_code || "-", p.room_number || "-", p.guest_name || "-", p.company_name || "-",
              methodLabels[p.method] || p.method, p.billing_target === "company" ? "Empresa" : "Huésped",
              formatARS(parseFloat(p.amount || "0")), p.reference || ""
            ]),
            "facturacion"
          );
        }
        break;
    }
  };

  return (
    <div className="flex flex-col gap-6 p-6" data-testid="reports-page">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight" data-testid="text-reports-title">
          Reportes
        </h1>
        <p className="text-muted-foreground">Análisis y estadísticas del hotel</p>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => applyPreset("today")} data-testid="button-preset-today">
                Hoy
              </Button>
              <Button variant="outline" size="sm" onClick={() => applyPreset("week")} data-testid="button-preset-week">
                Semana
              </Button>
              <Button variant="outline" size="sm" onClick={() => applyPreset("month")} data-testid="button-preset-month">
                Mes
              </Button>
              <Button variant="outline" size="sm" onClick={() => applyPreset("year")} data-testid="button-preset-year">
                Año
              </Button>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <label className="text-sm text-muted-foreground">Desde</label>
              <Input
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="w-auto"
                data-testid="input-date-from"
              />
              <label className="text-sm text-muted-foreground">Hasta</label>
              <Input
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="w-auto"
                data-testid="input-date-to"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2 ml-auto">
              <Button variant="outline" size="sm" onClick={handleExportCSV} data-testid="button-export-csv">
                <Download className="h-4 w-4 mr-1" />
                Exportar CSV
              </Button>
              <Button variant="outline" size="sm" onClick={() => window.print()} data-testid="button-print">
                <Printer className="h-4 w-4 mr-1" />
                Imprimir
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} data-testid="tabs-reports">
        <TabsList className="flex flex-wrap h-auto gap-1">
          <TabsTrigger value="occupancy" data-testid="tab-occupancy">
            <Hotel className="h-4 w-4 mr-1" />
            Ocupación
          </TabsTrigger>
          <TabsTrigger value="revenue-type" data-testid="tab-revenue-type">
            <TrendingUp className="h-4 w-4 mr-1" />
            Revenue por Tipo
          </TabsTrigger>
          <TabsTrigger value="channel" data-testid="tab-channel">
            <Globe className="h-4 w-4 mr-1" />
            Por Canal
          </TabsTrigger>
          <TabsTrigger value="reservations" data-testid="tab-reservations">
            <BarChart3 className="h-4 w-4 mr-1" />
            Reservas
          </TabsTrigger>
          <TabsTrigger value="payments" data-testid="tab-payments">
            <CreditCard className="h-4 w-4 mr-1" />
            Pagos
          </TabsTrigger>
          <TabsTrigger value="top-guests" data-testid="tab-top-guests">
            <Users className="h-4 w-4 mr-1" />
            Huéspedes Frecuentes
          </TabsTrigger>
          <TabsTrigger value="housekeeping" data-testid="tab-housekeeping">
            <Brush className="h-4 w-4 mr-1" />
            Housekeeping
          </TabsTrigger>
          <TabsTrigger value="restaurant" data-testid="tab-restaurant">
            <UtensilsCrossed className="h-4 w-4 mr-1" />
            Restaurante
          </TabsTrigger>
          <TabsTrigger value="billing" data-testid="tab-billing">
            <CreditCard className="h-4 w-4 mr-1" />
            Facturación
          </TabsTrigger>
        </TabsList>

        <TabsContent value="occupancy" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Ocupación Diaria</CardTitle>
            </CardHeader>
            <CardContent>
              {occupancy.isLoading ? (
                <LoadingSkeleton />
              ) : occupancy.data && occupancy.data.length > 0 ? (
                <>
                  <div className="h-72 mb-6">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={occupancy.data}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                        <YAxis unit="%" />
                        <Tooltip formatter={(v: number) => [`${v}%`, "Ocupación"]} />
                        <Legend />
                        <Line type="monotone" dataKey="occupancy" name="% Ocupación" stroke={COLORS[0]} strokeWidth={2} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="overflow-auto">
                    <Table data-testid="table-occupancy">
                      <TableHeader>
                        <TableRow>
                          <TableHead>Fecha</TableHead>
                          <TableHead className="text-right">Hab. Disponibles</TableHead>
                          <TableHead className="text-right">Hab. Ocupadas</TableHead>
                          <TableHead className="text-right">% Ocupación</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {occupancy.data.map((row, i) => (
                          <TableRow key={i} data-testid={`row-occupancy-${i}`}>
                            <TableCell>{row.date}</TableCell>
                            <TableCell className="text-right">{row.available}</TableCell>
                            <TableCell className="text-right">{row.occupied}</TableCell>
                            <TableCell className="text-right">{row.occupancy}%</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay datos para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue-type" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Revenue por Tipo de Habitación</CardTitle>
            </CardHeader>
            <CardContent>
              {revenueByType.isLoading ? (
                <LoadingSkeleton />
              ) : revenueByType.data && revenueByType.data.length > 0 ? (
                <>
                  <div className="h-72 mb-6">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={revenueByType.data}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="type" tick={{ fontSize: 12 }} />
                        <YAxis />
                        <Tooltip formatter={(v: number) => [formatARS(v), "Revenue"]} />
                        <Legend />
                        <Bar dataKey="revenue" name="Revenue" fill={COLORS[0]} radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="overflow-auto">
                    <Table data-testid="table-revenue-type">
                      <TableHeader>
                        <TableRow>
                          <TableHead>Tipo</TableHead>
                          <TableHead className="text-right">Habitaciones</TableHead>
                          <TableHead className="text-right">Noches vendidas</TableHead>
                          <TableHead className="text-right">Revenue</TableHead>
                          <TableHead className="text-right">ADR</TableHead>
                          <TableHead className="text-right">% del total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {revenueByType.data.map((row, i) => (
                          <TableRow key={i} data-testid={`row-revenue-type-${i}`}>
                            <TableCell>{row.type}</TableCell>
                            <TableCell className="text-right">{row.rooms}</TableCell>
                            <TableCell className="text-right">{row.nightsSold}</TableCell>
                            <TableCell className="text-right">{formatARS(row.revenue)}</TableCell>
                            <TableCell className="text-right">{formatARS(row.adr)}</TableCell>
                            <TableCell className="text-right">{row.percentage}%</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay datos para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="channel" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Revenue por Canal</CardTitle>
            </CardHeader>
            <CardContent>
              {byChannel.isLoading ? (
                <LoadingSkeleton />
              ) : byChannel.data && byChannel.data.length > 0 ? (
                <>
                  <div className="h-72 mb-6">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={byChannel.data}
                          dataKey="revenue"
                          nameKey="source"
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          label={({ source, percentage }: { source: string; percentage: number }) => `${source} (${percentage}%)`}
                        >
                          {byChannel.data.map((_, i) => (
                            <Cell key={i} fill={COLORS[i % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(v: number) => [formatARS(v), "Revenue"]} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="overflow-auto">
                    <Table data-testid="table-channel">
                      <TableHeader>
                        <TableRow>
                          <TableHead>Canal</TableHead>
                          <TableHead className="text-right">Reservas</TableHead>
                          <TableHead className="text-right">Noches</TableHead>
                          <TableHead className="text-right">Revenue</TableHead>
                          <TableHead className="text-right">Comisión</TableHead>
                          <TableHead className="text-right">Neto</TableHead>
                          <TableHead className="text-right">%</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {byChannel.data.map((row, i) => (
                          <TableRow key={i} data-testid={`row-channel-${i}`}>
                            <TableCell>{row.source}</TableCell>
                            <TableCell className="text-right">{row.reservations}</TableCell>
                            <TableCell className="text-right">{row.nights}</TableCell>
                            <TableCell className="text-right">{formatARS(row.revenue)}</TableCell>
                            <TableCell className="text-right">{formatARS(row.commission)}</TableCell>
                            <TableCell className="text-right">{formatARS(row.net)}</TableCell>
                            <TableCell className="text-right">{row.percentage}%</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay datos para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reservations" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle>Detalle de Reservas</CardTitle>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48" data-testid="select-status-filter">
                  <SelectValue placeholder="Filtrar por estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los estados</SelectItem>
                  <SelectItem value="confirmed">Confirmada</SelectItem>
                  <SelectItem value="pending">Pendiente</SelectItem>
                  <SelectItem value="checked_in">Check-in</SelectItem>
                  <SelectItem value="checked_out">Check-out</SelectItem>
                  <SelectItem value="cancelled">Cancelada</SelectItem>
                  <SelectItem value="no_show">No Show</SelectItem>
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
              {reservations.isLoading ? (
                <LoadingSkeleton />
              ) : reservations.data && reservations.data.length > 0 ? (
                <div className="overflow-auto">
                  <Table data-testid="table-reservations">
                    <TableHeader>
                      <TableRow>
                        <TableHead>Código</TableHead>
                        <TableHead>Huésped</TableHead>
                        <TableHead>Empresa</TableHead>
                        <TableHead>Habitación</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Check-in</TableHead>
                        <TableHead>Check-out</TableHead>
                        <TableHead className="text-right">Noches</TableHead>
                        <TableHead>Canal</TableHead>
                        <TableHead>Estado</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                        <TableHead className="text-right">Pagado</TableHead>
                        <TableHead className="text-right">Saldo</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reservations.data.map((row, i) => (
                        <TableRow key={i} data-testid={`row-reservation-${i}`}>
                          <TableCell className="font-mono text-sm">{row.code}</TableCell>
                          <TableCell>{row.guest}</TableCell>
                          <TableCell>{row.company || "-"}</TableCell>
                          <TableCell>{row.room}</TableCell>
                          <TableCell>{row.type}</TableCell>
                          <TableCell>{row.checkIn}</TableCell>
                          <TableCell>{row.checkOut}</TableCell>
                          <TableCell className="text-right">{row.nights}</TableCell>
                          <TableCell>{row.source}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" data-testid={`badge-status-${i}`}>
                              {row.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">{formatARS(row.total)}</TableCell>
                          <TableCell className="text-right">{formatARS(row.paid)}</TableCell>
                          <TableCell className="text-right font-medium">
                            {row.balance > 0 ? (
                              <span className="text-red-600 dark:text-red-400">{formatARS(row.balance)}</span>
                            ) : (
                              formatARS(row.balance)
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay reservas para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Pagos por Método</CardTitle>
            </CardHeader>
            <CardContent>
              {payments.isLoading ? (
                <LoadingSkeleton />
              ) : payments.data && payments.data.byMethod.length > 0 ? (
                <>
                  <div className="mb-4">
                    <p className="text-lg font-semibold" data-testid="text-payments-grand-total">
                      Total General: {formatARS(payments.data.grandTotal)}
                    </p>
                  </div>
                  <div className="h-72 mb-6">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={payments.data.byMethod} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="method" type="category" width={120} tick={{ fontSize: 12 }} />
                        <Tooltip formatter={(v: number) => [formatARS(v), "Monto"]} />
                        <Legend />
                        <Bar dataKey="total" name="Monto total" fill={COLORS[1]} radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="overflow-auto">
                    <Table data-testid="table-payments">
                      <TableHeader>
                        <TableRow>
                          <TableHead>Método</TableHead>
                          <TableHead className="text-right">Transacciones</TableHead>
                          <TableHead className="text-right">Monto total</TableHead>
                          <TableHead className="text-right">%</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {payments.data.byMethod.map((row, i) => (
                          <TableRow key={i} data-testid={`row-payment-${i}`}>
                            <TableCell>{row.method}</TableCell>
                            <TableCell className="text-right">{row.count}</TableCell>
                            <TableCell className="text-right">{formatARS(row.total)}</TableCell>
                            <TableCell className="text-right">{row.percentage}%</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay datos de pagos para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="top-guests" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Huéspedes Frecuentes</CardTitle>
            </CardHeader>
            <CardContent>
              {topGuests.isLoading ? (
                <LoadingSkeleton />
              ) : topGuests.data && topGuests.data.length > 0 ? (
                <div className="overflow-auto">
                  <Table data-testid="table-top-guests">
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right">Ranking</TableHead>
                        <TableHead>Huésped</TableHead>
                        <TableHead>Código</TableHead>
                        <TableHead className="text-right">Estadías</TableHead>
                        <TableHead className="text-right">Noches</TableHead>
                        <TableHead className="text-right">Revenue</TableHead>
                        <TableHead>Última visita</TableHead>
                        <TableHead>Segmento</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {topGuests.data.map((row, i) => (
                        <TableRow key={i} data-testid={`row-top-guest-${i}`}>
                          <TableCell className="text-right font-medium">{row.rank}</TableCell>
                          <TableCell>{row.guest}</TableCell>
                          <TableCell className="font-mono text-sm">{row.code}</TableCell>
                          <TableCell className="text-right">{row.stays}</TableCell>
                          <TableCell className="text-right">{row.nights}</TableCell>
                          <TableCell className="text-right">{formatARS(row.revenue)}</TableCell>
                          <TableCell>{row.lastVisit}</TableCell>
                          <TableCell>
                            <Badge variant="secondary">{row.segment}</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay datos de huéspedes para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="housekeeping" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Housekeeping</CardTitle>
            </CardHeader>
            <CardContent>
              {housekeeping.isLoading ? (
                <LoadingSkeleton />
              ) : housekeeping.data ? (
                <>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold" data-testid="text-hk-completed">{housekeeping.data.totalCompleted}</p>
                        <p className="text-sm text-muted-foreground">Completadas</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold" data-testid="text-hk-pending">{housekeeping.data.totalPending}</p>
                        <p className="text-sm text-muted-foreground">Pendientes</p>
                      </CardContent>
                    </Card>
                  </div>
                  {housekeeping.data.byType.length > 0 && (
                    <div className="overflow-auto">
                      <Table data-testid="table-housekeeping">
                        <TableHeader>
                          <TableRow>
                            <TableHead>Tipo de tarea</TableHead>
                            <TableHead className="text-right">Cantidad</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {housekeeping.data.byType.map((row, i) => (
                            <TableRow key={i} data-testid={`row-housekeeping-${i}`}>
                              <TableCell>{row.type}</TableCell>
                              <TableCell className="text-right">{row.count}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay datos de housekeeping para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="restaurant" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Restaurante</CardTitle>
            </CardHeader>
            <CardContent>
              {restaurant.isLoading ? (
                <LoadingSkeleton />
              ) : restaurant.data ? (
                <>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold" data-testid="text-rest-orders">{restaurant.data.totalOrders}</p>
                        <p className="text-sm text-muted-foreground">Pedidos</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold" data-testid="text-rest-revenue">{formatARS(restaurant.data.totalRevenue)}</p>
                        <p className="text-sm text-muted-foreground">Revenue</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold" data-testid="text-rest-covers">{restaurant.data.totalCovers}</p>
                        <p className="text-sm text-muted-foreground">Cubiertos</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold" data-testid="text-rest-avg-ticket">{formatARS(restaurant.data.avgTicket)}</p>
                        <p className="text-sm text-muted-foreground">Ticket Promedio</p>
                      </CardContent>
                    </Card>
                  </div>

                  {restaurant.data.topItems.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3">Top 10 Productos</h3>
                      <div className="overflow-auto">
                        <Table data-testid="table-restaurant-top-items">
                          <TableHeader>
                            <TableRow>
                              <TableHead>Producto</TableHead>
                              <TableHead className="text-right">Cantidad</TableHead>
                              <TableHead className="text-right">Revenue</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {restaurant.data.topItems.slice(0, 10).map((row, i) => (
                              <TableRow key={i} data-testid={`row-top-item-${i}`}>
                                <TableCell>{row.name}</TableCell>
                                <TableCell className="text-right">{row.count}</TableCell>
                                <TableCell className="text-right">{formatARS(row.revenue)}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}

                  {restaurant.data.byArea.length > 0 && (
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Por Área</h3>
                      <div className="overflow-auto">
                        <Table data-testid="table-restaurant-by-area">
                          <TableHeader>
                            <TableRow>
                              <TableHead>Área</TableHead>
                              <TableHead className="text-right">Pedidos</TableHead>
                              <TableHead className="text-right">Revenue</TableHead>
                              <TableHead className="text-right">Cubiertos</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {restaurant.data.byArea.map((row, i) => (
                              <TableRow key={i} data-testid={`row-area-${i}`}>
                                <TableCell>{row.name}</TableCell>
                                <TableCell className="text-right">{row.orders}</TableCell>
                                <TableCell className="text-right">{formatARS(row.revenue)}</TableCell>
                                <TableCell className="text-right">{row.covers}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay datos de restaurante para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle data-testid="text-billing-title">Reporte de Facturación</CardTitle>
            </CardHeader>
            <CardContent>
              {billing.isLoading ? (
                <LoadingSkeleton />
              ) : billing.data ? (
                <>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <Card className="border">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-muted-foreground">Total Cobrado</p>
                        <p className="text-2xl font-bold text-primary" data-testid="text-billing-total">{formatARS(billing.data.summary.totalAmount)}</p>
                      </CardContent>
                    </Card>
                    <Card className="border">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-muted-foreground">Transacciones</p>
                        <p className="text-2xl font-bold">{billing.data.summary.totalPayments}</p>
                      </CardContent>
                    </Card>
                    <Card className="border">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-muted-foreground">Facturado a Huéspedes</p>
                        <p className="text-2xl font-bold text-blue-600">{formatARS(billing.data.summary.guestTotal)}</p>
                      </CardContent>
                    </Card>
                    <Card className="border">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-muted-foreground">Facturado a Empresas</p>
                        <p className="text-2xl font-bold text-orange-600">{formatARS(billing.data.summary.companyTotal)}</p>
                      </CardContent>
                    </Card>
                  </div>

                  {Object.keys(billing.data.summary.byMethod).length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3">Por Método de Pago</h3>
                      <div className="h-[250px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={Object.entries(billing.data.summary.byMethod).map(([method, data]) => ({
                                name: ({efectivo:"Efectivo",tarjeta_debito:"T. Débito",tarjeta_credito:"T. Crédito",transferencia:"Transferencia",mercadopago:"MercadoPago",cuenta_corriente:"Cta. Corriente"} as Record<string,string>)[method] || method,
                                value: data.total,
                                count: data.count,
                              }))}
                              dataKey="value"
                              nameKey="name"
                              cx="50%"
                              cy="50%"
                              outerRadius={80}
                              label={({ name, percent }: any) => `${name} (${(percent * 100).toFixed(0)}%)`}
                            >
                              {Object.keys(billing.data.summary.byMethod).map((_, i) => (
                                <Cell key={i} fill={COLORS[i % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value: number) => formatARS(value)} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}

                  <h3 className="text-lg font-semibold mb-3">Detalle de Comprobantes</h3>
                  <div className="overflow-auto">
                    <Table data-testid="table-billing">
                      <TableHeader>
                        <TableRow>
                          <TableHead>Fecha</TableHead>
                          <TableHead>Reserva</TableHead>
                          <TableHead>Hab.</TableHead>
                          <TableHead>Huésped</TableHead>
                          <TableHead>Método</TableHead>
                          <TableHead>Factura a</TableHead>
                          <TableHead className="text-right">Monto</TableHead>
                          <TableHead>Referencia</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {billing.data.payments.map((p, i) => (
                          <TableRow key={p.id || i} data-testid={`row-billing-${i}`}>
                            <TableCell className="text-sm">{new Date(p.date + "T12:00:00").toLocaleDateString("es-AR")}</TableCell>
                            <TableCell className="font-mono text-xs">{p.reservation_code || "-"}</TableCell>
                            <TableCell>{p.room_number || "-"}</TableCell>
                            <TableCell>{p.guest_name || "-"}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs">
                                {({efectivo:"Efectivo",tarjeta_debito:"T. Débito",tarjeta_credito:"T. Crédito",transferencia:"Transferencia",mercadopago:"MercadoPago",cuenta_corriente:"Cta. Corriente"} as Record<string,string>)[p.method] || p.method}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={p.billing_target === "company" ? "secondary" : "outline"} className="text-xs">
                                {p.billing_target === "company" ? (p.company_name || "Empresa") : "Huésped"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right font-medium">{formatARS(parseFloat(p.amount || "0"))}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">{p.reference || "-"}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground text-center py-8">No hay datos de facturación para el período seleccionado</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}