import { randomUUID } from "crypto";

export function getArgentinaToday(): string {
  return new Date().toLocaleDateString("en-CA", { timeZone: "America/Argentina/Buenos_Aires" });
}

const giftVoucherAreas = ["alojamiento", "restaurant", "spa", "otro"] as const;
const giftVoucherStatuses = ["activo", "usado", "vencido", "cancelado"] as const;
const giftVoucherValueTypes = ["monetario", "descriptivo"] as const;

function parseGiftVoucherArea(value: string): GiftVoucher["area"] {
  if (giftVoucherAreas.includes(value as GiftVoucher["area"])) {
    return value as GiftVoucher["area"];
  }
  throw new Error(`Área de voucher inválida: ${value}`);
}

function parseGiftVoucherStatus(value: string): GiftVoucher["status"] {
  if (giftVoucherStatuses.includes(value as GiftVoucher["status"])) {
    return value as GiftVoucher["status"];
  }
  throw new Error(`Estado de voucher inválido: ${value}`);
}

function parseGiftVoucherValueType(value: string): GiftVoucher["valueType"] {
  if (giftVoucherValueTypes.includes(value as GiftVoucher["valueType"])) {
    return value as GiftVoucher["valueType"];
  }
  throw new Error(`Tipo de valor de voucher inválido: ${value}`);
}

import { eq, and, or, desc, asc, sql, ilike, count, ne, lt, gt, lte, gte, inArray, not, isNull, getTableColumns } from "drizzle-orm";
import { db, pool } from "./db";
import { IStorage } from "./storage";
import {
  type User, type InsertUser,
  type Room, type InsertRoom,
  type RoomType, type InsertRoomType,
  type RatePlan, type InsertRatePlan, type RatePlanWithRoomType,
  type Company, type InsertCompany,
  type Agency, type InsertAgency,
  type Guest, type InsertGuest,
  type BedType, type InsertBedType,
  type Reservation, type InsertReservation,
  type Charge, type InsertCharge,
  type ChargeType, type InsertChargeType, chargeTypes,
  type LoanItem, type InsertLoanItem, loanItems,
  type ItemLoan, type InsertItemLoan, type ItemLoanWithItem, itemLoans,
  type Payment, type InsertPayment,
  type CancelledReservationLog, type InsertCancelledReservationLog,
  type OTAChannel, type InsertOTAChannel, type OTAChannelWithStats,
  type OTAReservationLog, type InsertOTAReservationLog, type OTAReservationLogWithChannel,
  type RoomWithType, type ReservationWithDetails,
  type RoomStatus, type ReservationStatus, type ReservationSource,
  type PlanningData, type PlanningCellStatus,
  type Group, type InsertGroup,
  type GroupRoomBlock, type InsertGroupRoomBlock,
  type GroupReservationLink, type InsertGroupReservationLink,
  type GroupWithDetails, type GroupRoomBlockWithDetails,
  type GroupCharge, type InsertGroupCharge,
  type GroupPayment, type InsertGroupPayment,
  type GroupFolioData,
  type GuestReview, type InsertGuestReview, type GuestReviewWithDetails, type SentimentType,
  type HousekeepingTask, type InsertHousekeepingTask, type HousekeepingTaskWithRoom,
  type RestaurantArea, type InsertRestaurantArea,
  type RestaurantTable, type InsertRestaurantTable, type RestaurantTableWithArea,
  type MenuCategory, type InsertMenuCategory,
  type MenuItem, type InsertMenuItem, type MenuItemWithCategory,
  type RestaurantOrder, type InsertRestaurantOrder, type RestaurantOrderWithDetails,
  type OrderItem, type InsertOrderItem,
  type TableReservation, type InsertTableReservation, type TableReservationWithTable,
  type RestaurantTimeSlot, type InsertRestaurantTimeSlot,
  type OrderSplit, type InsertOrderSplit,
  type Recipe, type InsertRecipe,
  type RecipeIngredient, type InsertRecipeIngredient, type RecipeWithIngredients,
  type ItemCategory, type InsertItemCategory,
  type Supplier, type InsertSupplier,
  type InventoryItem, type InsertInventoryItem, type InventoryItemWithDetails,
  type StockMovement, type InsertStockMovement, type StockMovementWithItem,
  type SpaCabin, type InsertSpaCabin,
  type SpaTreatmentCategory, type InsertSpaTreatmentCategory,
  type SpaTreatment, type InsertSpaTreatment,
  type SpaAppointment, type InsertSpaAppointment, type SpaAppointmentWithDetails, type SpaAppointmentStatus,
  type SpaAccount, type InsertSpaAccount, type SpaAccountStatus, type SpaAccountWithItems,
  type SpaAccountItem, type InsertSpaAccountItem,
  type SpaPayment, type InsertSpaPayment,
  type TreatmentSupply, type InsertTreatmentSupply,
  type EventRoom, type InsertEventRoom, type EventRoomStatus,
  type Event as HotelEvent, type InsertEvent, type EventStatus, type EventType,
  type EventChargeType, type InsertEventChargeType,
  type EventCharge, type InsertEventCharge, type EventChargeWithType,
  type EventWithDetails,
  type EventPlanningData, type EventPlanningCellStatus,
  type EventPayment, type InsertEventPayment,
  type EventTable, type InsertEventTable, type EventTableWithDetails,
  type EventTableCharge, type InsertEventTableCharge,
  type EventTablePayment, type InsertEventTablePayment,
  type MaintenanceStaff, type InsertMaintenanceStaff,
  type WorkOrder, type InsertWorkOrder, type WorkOrderWithDetails, type WorkOrderStatus,
  type SystemUser, type InsertSystemUser,
  type SystemSetting, type InsertSystemSetting,
  type AuditLog, type InsertAuditLog,
  type Package, type InsertPackage, type PackageWithDetails, type PackageStatus,
  type PackageItem, type InsertPackageItem,
  type PackageRoomPrice, type InsertPackageRoomPrice, type PackageRoomPriceWithType,
  type SystemNotification, type InsertSystemNotification, type NotificationArea,
  type WebCheckin, type InsertWebCheckin,
  type GuestPreference, type InsertGuestPreference,
  type StayNote, type InsertStayNote,
  type HospitalityAlert, type InsertHospitalityAlert,
  type CashRegisterConfig, type InsertCashRegisterConfig,
  type CashShift, type InsertCashShift,
  type CashMovement, type InsertCashMovement,
  type CashClosingSummary, type InsertCashClosingSummary,
  type AccountMovement, type InsertAccountMovement, type AccountEntityType,
  type OrderStatus,
  type SpaPaymentMethod,
  type Folio, type InsertFolio, type FolioStatus, type FolioEntityType,
  type FolioMovement, type InsertFolioMovement, type FolioMovementType, type FolioWithMovements,
  users, rooms, roomTypes, ratePlans, companies, agencies, guests, bedTypes,
  reservations, charges, payments, cancelledReservationLogs,
  otaChannels, otaReservationLogs,
  groups, groupRoomBlocks, groupReservationLinks, groupCharges, groupPayments,
  guestReviews, housekeepingTasks,
  restaurantAreas, restaurantTables, menuCategories, menuItems,
  restaurantOrders, orderItems, tableReservations, restaurantTimeSlots,
  restaurantReservationAdvances,
  type RestaurantReservationAdvance, type InsertRestaurantReservationAdvance,
  orderSplits, recipes, recipeIngredients,
  itemCategories, suppliers, inventoryItems, stockMovements, warehouseStock,
  spaCabins, spaTreatmentCategories, spaTreatments, spaAppointments,
  spaAccounts, spaAccountItems, spaPayments, treatmentSupplies,
  eventRooms, events, eventChargeTypes, eventCharges, eventPayments,
  eventTables, eventTableCharges, eventTablePayments,
  maintenanceStaff, workOrders, maintenanceBlocks,
  type MaintenanceBlock, type InsertMaintenanceBlock,
  systemUsers, systemSettings, auditLogs,
  packages, packageItems, packageRoomPrices,
  systemNotifications, webCheckins,
  guestPreferences, stayNotes, hospitalityAlerts,
  cashRegisterConfigs, cashShifts, cashMovements, cashClosingSummaries,
  accountMovements, accountMovementAllocations,
  type AccountRetention, type AccountMovementAllocation, type InsertAccountMovementAllocation,
  folios, folioMovements,
  salesInvoices,
  reservationCompanions,
  type ReservationCompanion, type InsertReservationCompanion,
  giftVouchers,
  type GiftVoucher, type InsertGiftVoucher,
  inventoryCounts,
  inventoryCountItems,
} from "@shared/schema";

export class DatabaseStorage implements IStorage {

  // Reservation Companions
  async getReservationCompanions(reservationId: string): Promise<ReservationCompanion[]> {
    return db.select().from(reservationCompanions)
      .where(eq(reservationCompanions.reservationId, reservationId))
      .orderBy(asc(reservationCompanions.createdAt));
  }

  async addReservationCompanion(data: InsertReservationCompanion): Promise<ReservationCompanion> {
    const [created] = await db.insert(reservationCompanions).values({ ...data, id: randomUUID() } as any).returning();
    return created;
  }

  async updateReservationCompanion(id: string, data: Partial<InsertReservationCompanion>): Promise<ReservationCompanion> {
    const updateData: any = { ...data };
    if (!updateData.dateOfBirth) delete updateData.dateOfBirth;
    const [updated] = await db.update(reservationCompanions).set(updateData).where(eq(reservationCompanions.id, id)).returning();
    return updated;
  }

  async deleteReservationCompanion(id: string): Promise<void> {
    await db.delete(reservationCompanions).where(eq(reservationCompanions.id, id));
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values(user as any).returning();
    return created;
  }

  async getRoomTypes(): Promise<RoomType[]> {
    return db.select().from(roomTypes);
  }

  async getRoomType(id: string): Promise<RoomType | undefined> {
    const [rt] = await db.select().from(roomTypes).where(eq(roomTypes.id, id));
    return rt;
  }

  async createRoomType(roomType: InsertRoomType): Promise<RoomType> {
    const [created] = await db.insert(roomTypes).values(roomType as any).returning();
    return created;
  }

  async updateRoomType(id: string, roomType: Partial<InsertRoomType>): Promise<RoomType | undefined> {
    const [updated] = await db.update(roomTypes).set(roomType as any).where(eq(roomTypes.id, id)).returning();
    return updated;
  }

  async deleteRoomType(id: string): Promise<boolean> {
    const result = await db.delete(roomTypes).where(eq(roomTypes.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getRatePlans(): Promise<RatePlanWithRoomType[]> {
    const plans = await db.select().from(ratePlans);
    const types = await db.select().from(roomTypes);
    const typesMap = new Map(types.map(t => [t.id, t]));
    return plans.map(p => ({ ...p, roomType: typesMap.get(p.roomTypeId)! }));
  }

  async getRatePlan(id: string): Promise<RatePlanWithRoomType | undefined> {
    const [plan] = await db.select().from(ratePlans).where(eq(ratePlans.id, id));
    if (!plan) return undefined;
    const [rt] = await db.select().from(roomTypes).where(eq(roomTypes.id, plan.roomTypeId));
    return { ...plan, roomType: rt };
  }

  async getRatePlansByRoomType(roomTypeId: string): Promise<RatePlan[]> {
    return db.select().from(ratePlans).where(eq(ratePlans.roomTypeId, roomTypeId));
  }

  async createRatePlan(ratePlan: InsertRatePlan): Promise<RatePlan> {
    const [created] = await db.insert(ratePlans).values(ratePlan as any).returning();
    return created;
  }

  async updateRatePlan(id: string, ratePlan: Partial<InsertRatePlan>): Promise<RatePlan | undefined> {
    const [updated] = await db.update(ratePlans).set(ratePlan as any).where(eq(ratePlans.id, id)).returning();
    return updated;
  }

  async deleteRatePlan(id: string): Promise<boolean> {
    const result = await db.delete(ratePlans).where(eq(ratePlans.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getRooms(): Promise<RoomWithType[]> {
    const allRooms = await db.select().from(rooms);
    const types = await db.select().from(roomTypes);
    const typesMap = new Map(types.map(t => [t.id, t]));
    return allRooms
      .filter(r => typesMap.has(r.roomTypeId))
      .map(r => ({ ...r, roomType: typesMap.get(r.roomTypeId)! }));
  }

  async getRoomsActive(): Promise<RoomWithType[]> {
    const allRooms = await this.getRooms();
    return allRooms.filter(r => r.isActive !== false);
  }

  async getRoom(id: string): Promise<RoomWithType | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    if (!room) return undefined;
    const [rt] = await db.select().from(roomTypes).where(eq(roomTypes.id, room.roomTypeId));
    return { ...room, roomType: rt };
  }

  async getRoomByNumber(roomNumber: string): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.roomNumber, roomNumber));
    return room;
  }

  async createRoom(room: InsertRoom): Promise<Room> {
    const [created] = await db.insert(rooms).values(room as any).returning();
    return created;
  }

  async updateRoom(id: string, room: Partial<InsertRoom>): Promise<Room | undefined> {
    const safeUpdates: Record<string, any> = {};
    for (const [key, val] of Object.entries(room)) {
      if (val !== undefined) safeUpdates[key] = val;
    }
    if (Object.keys(safeUpdates).length === 0) {
      const [existing] = await db.select().from(rooms).where(eq(rooms.id, id));
      return existing;
    }
    const [updated] = await db.update(rooms).set(safeUpdates as any).where(eq(rooms.id, id)).returning();
    return updated;
  }

  async deleteRoom(id: string): Promise<boolean> {
    const result = await db.delete(rooms).where(eq(rooms.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getCompanies(): Promise<Company[]> {
    return db.select().from(companies).orderBy(asc(companies.razonSocial));
  }

  async getCompany(id: string): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company;
  }

  async searchCompanies(query: string): Promise<Company[]> {
    return db.select().from(companies).where(
      or(
        ilike(companies.razonSocial, `%${query}%`),
        ilike(companies.nombreFantasia, `%${query}%`),
        ilike(companies.cuilCuit, `%${query}%`)
      )
    );
  }

  async createCompany(company: InsertCompany): Promise<Company> {
    const [created] = await db.insert(companies).values(company as any).returning();
    return created;
  }

  async updateCompany(id: string, company: Partial<InsertCompany>): Promise<Company | undefined> {
    const safeData: Record<string, any> = {};
    for (const [key, value] of Object.entries(company)) {
      if (["id", "createdAt"].includes(key) || value === undefined) continue;
      safeData[key] = value;
    }
    if (Object.keys(safeData).length === 0) return undefined;
    const [updated] = await db.update(companies).set(safeData).where(eq(companies.id, id)).returning();
    return updated;
  }

  async deleteCompany(id: string): Promise<boolean> {
    const result = await db.delete(companies).where(eq(companies.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getAgencies(): Promise<Agency[]> {
    return db.select().from(agencies).orderBy(asc(agencies.razonSocial));
  }

  async getAgency(id: string): Promise<Agency | undefined> {
    const [agency] = await db.select().from(agencies).where(eq(agencies.id, id));
    return agency;
  }

  async searchAgencies(query: string): Promise<Agency[]> {
    return db.select().from(agencies).where(
      or(
        ilike(agencies.razonSocial, `%${query}%`),
        ilike(agencies.nombreFantasia, `%${query}%`),
        ilike(agencies.cuilCuit, `%${query}%`)
      )
    );
  }

  async createAgency(agency: InsertAgency): Promise<Agency> {
    const [created] = await db.insert(agencies).values(agency as any).returning();
    return created;
  }

  async updateAgency(id: string, agency: Partial<InsertAgency>): Promise<Agency | undefined> {
    const safeData: Record<string, any> = {};
    for (const [key, value] of Object.entries(agency)) {
      if (["id", "createdAt"].includes(key) || value === undefined) continue;
      safeData[key] = value;
    }
    if (Object.keys(safeData).length === 0) return undefined;
    const [updated] = await db.update(agencies).set(safeData).where(eq(agencies.id, id)).returning();
    return updated;
  }

  async deleteAgency(id: string): Promise<boolean> {
    const result = await db.delete(agencies).where(eq(agencies.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getGuests(): Promise<Guest[]> {
    return db.select().from(guests).where(
      or(isNull(guests.codigo), not(ilike(guests.codigo, 'GROUP-%')))
    );
  }

  async getGuest(id: string): Promise<Guest | undefined> {
    const [guest] = await db.select().from(guests).where(eq(guests.id, id));
    return guest;
  }

  async searchGuests(query: string): Promise<Guest[]> {
    return db.select().from(guests).where(
      and(
        or(isNull(guests.codigo), not(ilike(guests.codigo, 'GROUP-%'))),
        or(
          ilike(guests.firstName, `%${query}%`),
          ilike(guests.lastName, `%${query}%`),
          ilike(guests.email, `%${query}%`),
          ilike(guests.documentNumber, `%${query}%`),
          ilike(guests.phone, `%${query}%`),
          ilike(guests.cuilCuit, `%${query}%`)
        )
      )
    ).limit(20);
  }

  async createGuest(guest: InsertGuest): Promise<Guest> {
    const [created] = await db.insert(guests).values(guest as any).returning();
    return created;
  }

  async updateGuest(id: string, guest: Partial<InsertGuest>): Promise<Guest | undefined> {
    const [updated] = await db.update(guests).set(guest as any).where(eq(guests.id, id)).returning();
    return updated;
  }

  async deleteGuest(id: string): Promise<boolean> {
    const result = await db.delete(guests).where(eq(guests.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getBedTypes(): Promise<BedType[]> {
    return db.select().from(bedTypes);
  }

  async getBedType(id: string): Promise<BedType | undefined> {
    const [bt] = await db.select().from(bedTypes).where(eq(bedTypes.id, id));
    return bt;
  }

  async createBedType(bedType: InsertBedType): Promise<BedType> {
    const [created] = await db.insert(bedTypes).values(bedType as any).returning();
    return created;
  }

  async updateBedType(id: string, bedType: Partial<InsertBedType>): Promise<BedType | undefined> {
    const [updated] = await db.update(bedTypes).set(bedType as any).where(eq(bedTypes.id, id)).returning();
    return updated;
  }

  async deleteBedType(id: string): Promise<boolean> {
    const [existing] = await db.select().from(bedTypes).where(eq(bedTypes.id, id));
    if (!existing) return false;
    await db.update(bedTypes).set({ isActive: false }).where(eq(bedTypes.id, id));
    return true;
  }

  // Single reservation enrichment — uses Promise.all to parallelize all sub-queries
  private async enrichReservation(reservation: Reservation): Promise<ReservationWithDetails> {
    const [
      [guest],
      [room],
      chargesList,
      paymentsList,
      ratePlanResult,
      companyResult,
      agencyResult,
      groupLinkResult,
    ] = await Promise.all([
      db.select().from(guests).where(eq(guests.id, reservation.guestId)),
      db.select().from(rooms).where(eq(rooms.id, reservation.roomId)),
      db.select().from(charges).where(eq(charges.reservationId, reservation.id)),
      db.select().from(payments).where(eq(payments.reservationId, reservation.id)),
      reservation.ratePlanId ? db.select().from(ratePlans).where(eq(ratePlans.id, reservation.ratePlanId)) : Promise.resolve([]),
      reservation.companyId ? db.select().from(companies).where(eq(companies.id, reservation.companyId)) : Promise.resolve([]),
      reservation.agencyId ? db.select().from(agencies).where(eq(agencies.id, reservation.agencyId)) : Promise.resolve([]),
      db.select().from(groupReservationLinks).where(eq(groupReservationLinks.reservationId, reservation.id)),
    ]);
    const [roomType] = room ? await db.select().from(roomTypes).where(eq(roomTypes.id, room.roomTypeId)) : [undefined];
    const groupLink = groupLinkResult[0];
    const [groupRow] = groupLink ? await db.select({ id: groups.id, name: groups.name, groupCode: groups.groupCode }).from(groups).where(eq(groups.id, groupLink.groupId)) : [undefined];
    return {
      ...reservation,
      guest: guest!,
      company: companyResult[0],
      agency: agencyResult[0],
      room: room ? { ...room, roomType } : undefined as any,
      ratePlan: ratePlanResult[0],
      charges: chargesList,
      payments: paymentsList,
      groupId: groupRow?.id,
      groupName: groupRow?.name,
      groupCode: groupRow?.groupCode,
    } as any;
  }

  // Bulk enrichment — loads all related data in 8 parallel queries for the entire list (no N+1)
  private async enrichReservations(reservationList: Reservation[]): Promise<ReservationWithDetails[]> {
    if (reservationList.length === 0) return [];

    const reservationIds = reservationList.map(r => r.id);
    const guestIds = [...new Set(reservationList.map(r => r.guestId).filter(Boolean))] as string[];
    const roomIds = [...new Set(reservationList.map(r => r.roomId).filter(Boolean))] as string[];
    const ratePlanIds = [...new Set(reservationList.map(r => r.ratePlanId).filter(Boolean))] as string[];
    const companyIds = [...new Set(reservationList.map(r => r.companyId).filter(Boolean))] as string[];
    const agencyIds = [...new Set(reservationList.map(r => r.agencyId).filter(Boolean))] as string[];

    const [guestList, roomList, allRoomTypes, ratePlanList, chargesList, paymentsList, companyList, agencyList, groupLinkList] = await Promise.all([
      guestIds.length ? db.select().from(guests).where(inArray(guests.id, guestIds)) : Promise.resolve([]),
      roomIds.length ? db.select().from(rooms).where(inArray(rooms.id, roomIds)) : Promise.resolve([]),
      db.select().from(roomTypes),
      ratePlanIds.length ? db.select().from(ratePlans).where(inArray(ratePlans.id, ratePlanIds)) : Promise.resolve([]),
      db.select().from(charges).where(inArray(charges.reservationId, reservationIds)),
      db.select().from(payments).where(inArray(payments.reservationId, reservationIds)),
      companyIds.length ? db.select().from(companies).where(inArray(companies.id, companyIds)) : Promise.resolve([]),
      agencyIds.length ? db.select().from(agencies).where(inArray(agencies.id, agencyIds)) : Promise.resolve([]),
      db.select().from(groupReservationLinks).where(inArray(groupReservationLinks.reservationId, reservationIds)),
    ]);

    // Build group map: reservationId → {groupId, groupName, groupCode}
    const groupLinkMap = new Map<string, string>((groupLinkList as any[]).map((l: any) => [l.reservationId, l.groupId]));
    const groupIds = [...new Set((groupLinkList as any[]).map((l: any) => l.groupId))];
    const groupList = groupIds.length ? await db.select({ id: groups.id, name: groups.name, groupCode: groups.groupCode }).from(groups).where(inArray(groups.id, groupIds)) : [];
    const groupMap = new Map(groupList.map((g: any) => [g.id, g]));

    const guestMap = new Map(guestList.map((g: any) => [g.id, g]));
    const roomMap = new Map(roomList.map((r: any) => [r.id, r]));
    const roomTypeMap = new Map(allRoomTypes.map((t: any) => [t.id, t]));
    const ratePlanMap = new Map(ratePlanList.map((p: any) => [p.id, p]));
    const chargesMap = new Map<string, any[]>();
    for (const c of chargesList as any[]) {
      if (!chargesMap.has(c.reservationId)) chargesMap.set(c.reservationId, []);
      chargesMap.get(c.reservationId)!.push(c);
    }
    const paymentsMap = new Map<string, any[]>();
    for (const p of paymentsList as any[]) {
      if (!paymentsMap.has(p.reservationId)) paymentsMap.set(p.reservationId, []);
      paymentsMap.get(p.reservationId)!.push(p);
    }
    const companyMap = new Map(companyList.map((c: any) => [c.id, c]));
    const agencyMap = new Map(agencyList.map((a: any) => [a.id, a]));

    return reservationList.map(reservation => {
      const room: any = roomMap.get(reservation.roomId);
      const roomType = room ? roomTypeMap.get(room.roomTypeId) : undefined;
      const groupId = groupLinkMap.get(reservation.id);
      const group: any = groupId ? groupMap.get(groupId) : undefined;
      return {
        ...reservation,
        guest: guestMap.get(reservation.guestId) as any,
        company: reservation.companyId ? companyMap.get(reservation.companyId) : undefined,
        agency: reservation.agencyId ? agencyMap.get(reservation.agencyId) : undefined,
        room: room ? { ...room, roomType } : undefined as any,
        ratePlan: reservation.ratePlanId ? ratePlanMap.get(reservation.ratePlanId) : undefined,
        charges: chargesMap.get(reservation.id) || [],
        payments: paymentsMap.get(reservation.id) || [],
        groupId: group?.id,
        groupName: group?.name,
        groupCode: group?.groupCode,
      };
    });
  }

  async getReservations(options?: {
    dateFrom?: string;
    dateTo?: string;
    dateMode?: string;
    dateField?: string;
    /** Filter to only these statuses at DB level */
    statuses?: string[];
    /** Server-side text search: guest name, room number, or reservation ID — applied via SQL JOIN + ILIKE */
    search?: string;
    /** SQL-level LIMIT applied before enrichment (default: unlimited) */
    limit?: number;
  }): Promise<ReservationWithDetails[]> {
    const conditions = [];

    if (options?.dateMode === "all") {
      // no date filter
    } else if (options?.dateField === "createdAt" && (options?.dateFrom || options?.dateTo)) {
      if (options.dateFrom) {
        conditions.push(sql`DATE(${reservations.createdAt}) >= ${options.dateFrom}`);
      }
      if (options.dateTo) {
        conditions.push(sql`DATE(${reservations.createdAt}) <= ${options.dateTo}`);
      }
    } else if (options?.dateFrom || options?.dateTo) {
      if (options.dateFrom) {
        conditions.push(gte(reservations.checkInDate, options.dateFrom));
      }
      if (options.dateTo) {
        conditions.push(lte(reservations.checkInDate, options.dateTo));
      }
    } else {
      const today = getArgentinaToday();
      conditions.push(
        or(
          inArray(reservations.status, ["pending", "confirmed", "checked_in"]),
          and(
            gte(reservations.checkInDate, today),
            ne(reservations.status, "cancelled")
          )
        )
      );
    }

    // Status filter at DB level
    if (options?.statuses && options.statuses.length > 0) {
      conditions.push(inArray(reservations.status, options.statuses as ReservationStatus[]));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    const limitVal = options?.limit && options.limit > 0 ? options.limit : undefined;

    let rawRows: any[];

    if (options?.search && options.search.trim()) {
      // Push search into SQL via LEFT JOIN on guests + rooms, with ILIKE conditions.
      // Use getTableColumns(reservations) so the result set contains only reservation
      // columns, keeping the shape compatible with enrichReservations.
      const q = `%${options.search.trim()}%`;
      const searchCondition = or(
        sql`CAST(${reservations.id} AS TEXT) ILIKE ${q}`,
        sql`CONCAT(COALESCE(${guests.firstName}, ''), ' ', COALESCE(${guests.lastName}, '')) ILIKE ${q}`,
        ilike(rooms.roomNumber, q)
      );
      const combinedWhere = whereClause ? and(whereClause, searchCondition) : searchCondition;

      const joinQuery = db
        .select(getTableColumns(reservations))
        .from(reservations)
        .leftJoin(guests, eq(reservations.guestId, guests.id))
        .leftJoin(rooms, eq(reservations.roomId, rooms.id))
        .where(combinedWhere)
        .orderBy(desc(reservations.checkInDate));

      rawRows = limitVal ? await joinQuery.limit(limitVal) : await joinQuery;
    } else {
      // No text search: simple query with optional LIMIT.
      const simpleQuery = db
        .select()
        .from(reservations)
        .where(whereClause)
        .orderBy(asc(reservations.checkInDate));

      rawRows = limitVal ? await (simpleQuery as any).limit(limitVal) : await simpleQuery;
    }

    return this.enrichReservations(rawRows);
  }

  async getReservation(id: string): Promise<ReservationWithDetails | undefined> {
    const [res] = await db.select().from(reservations).where(eq(reservations.id, id));
    if (!res) return undefined;
    return this.enrichReservation(res);
  }

  async getReservationByCode(code: string): Promise<ReservationWithDetails | undefined> {
    const [res] = await db.select().from(reservations).where(eq(reservations.reservationCode, code));
    if (!res) return undefined;
    return this.enrichReservation(res);
  }

  async getRecentReservations(limit: number): Promise<ReservationWithDetails[]> {
    const allRes = await db.select().from(reservations).orderBy(desc(reservations.createdAt)).limit(limit);
    return this.enrichReservations(allRes);
  }

  async getReservationsForCheckIn(): Promise<ReservationWithDetails[]> {
    const todayStr = getArgentinaToday();
    const allRes = await db.select().from(reservations).where(
      and(
        inArray(reservations.status, ["confirmed", "pending", "tentative", "web_checkin"] as any),
        eq(reservations.checkInDate, todayStr)
      )
    );
    return this.enrichReservations(allRes);
  }

  async getReservationsForCheckOut(): Promise<ReservationWithDetails[]> {
    const today = new Date().toLocaleDateString("en-CA", { timeZone: "America/Argentina/Buenos_Aires" });
    // Include checked_in (all dates) + confirmed/pending with checkout <= today
    const allRes = await db.select().from(reservations).where(
      or(
        eq(reservations.status, "checked_in"),
        and(
          inArray(reservations.status, ["confirmed", "pending"] as any),
          lte(reservations.checkOutDate, today)
        )
      )
    );
    return this.enrichReservations(allRes);
  }

  async getCheckInsByDate(date: string): Promise<ReservationWithDetails[]> {
    const allRes = await db.select().from(reservations).where(
      and(eq(reservations.checkInDate, date), eq(reservations.status, "checked_in"))
    );
    return this.enrichReservations(allRes);
  }

  async getReservationsByGuest(guestId: string): Promise<ReservationWithDetails[]> {
    const allRes = await db.select().from(reservations).where(eq(reservations.guestId, guestId));
    return this.enrichReservations(allRes);
  }

  async createReservation(reservation: InsertReservation): Promise<Reservation> {
    const [created] = await db.insert(reservations).values(reservation as any).returning();
    return created;
  }

  async updateReservation(id: string, reservation: Partial<InsertReservation>): Promise<Reservation | undefined> {
    const safeData: Record<string, any> = {};
    const protectedFields = ["id", "createdAt", "reservationCode"];
    const fkFields = ["guestId", "roomId", "roomTypeId"];
    const validStatuses = ["tentative", "pending", "confirmed", "checked_in", "checked_out", "cancelled", "no_show"];
    for (const [key, value] of Object.entries(reservation)) {
      if (protectedFields.includes(key)) continue;
      if (value === undefined) continue;
      if (fkFields.includes(key) && value === "") continue;
      if (key === "status" && (value === "" || value === null || !validStatuses.includes(value as string))) continue;
      safeData[key] = value;
    }
    if (Object.keys(safeData).length === 0) return undefined;
    const [updated] = await db.update(reservations).set(safeData).where(eq(reservations.id, id)).returning();
    return updated;
  }

  async deleteReservation(id: string): Promise<boolean> {
    const result = await db.delete(reservations).where(eq(reservations.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  generateReservationCode(): string {
    const now = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `RES-${now}-${random}`;
  }

  async getCharges(reservationId: string): Promise<Charge[]> {
    return db.select().from(charges).where(
      and(eq(charges.reservationId, reservationId), or(isNull(charges.status), eq(charges.status, "active")))
    );
  }

  async getAllChargesIncludingAnulados(reservationId: string): Promise<Charge[]> {
    return db.select().from(charges).where(eq(charges.reservationId, reservationId));
  }

  async getCharge(id: string): Promise<Charge | undefined> {
    const [charge] = await db.select().from(charges).where(eq(charges.id, id));
    return charge;
  }

  async createCharge(charge: InsertCharge): Promise<Charge> {
    const [created] = await db.insert(charges).values(charge as any).returning();
    return created;
  }

  async updateCharge(id: string, charge: Partial<InsertCharge>): Promise<Charge | undefined> {
    const [updated] = await db.update(charges).set(charge as any).where(eq(charges.id, id)).returning();
    return updated;
  }

  async deleteCharge(id: string): Promise<boolean> {
    const result = await db.delete(charges).where(eq(charges.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getChargesTotal(reservationId: string): Promise<number> {
    const result = await db.select({ total: sql<string>`COALESCE(SUM(${charges.amount}::numeric), 0)` }).from(charges).where(
      and(eq(charges.reservationId, reservationId), or(isNull(charges.status), eq(charges.status, "active")))
    );
    return parseFloat(result[0]?.total || "0");
  }

  async getChargeTypes(): Promise<ChargeType[]> {
    return db.select().from(chargeTypes).where(eq(chargeTypes.active, true)).orderBy(chargeTypes.sortOrder);
  }

  async getChargeTypesAll(): Promise<ChargeType[]> {
    return db.select().from(chargeTypes).orderBy(chargeTypes.sortOrder, chargeTypes.label);
  }

  async createChargeType(ct: InsertChargeType): Promise<ChargeType> {
    const [created] = await db.insert(chargeTypes).values(ct as any).returning();
    return created;
  }

  async updateChargeType(id: string, ct: Partial<InsertChargeType>): Promise<ChargeType | undefined> {
    const [updated] = await db.update(chargeTypes).set(ct as any).where(eq(chargeTypes.id, id)).returning();
    return updated;
  }

  async deleteChargeType(id: string): Promise<boolean> {
    const result = await db.delete(chargeTypes).where(eq(chargeTypes.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getLoanItems(): Promise<LoanItem[]> {
    return db.select().from(loanItems).where(eq(loanItems.active, true)).orderBy(loanItems.sortOrder);
  }

  async createLoanItem(item: InsertLoanItem): Promise<LoanItem> {
    const [created] = await db.insert(loanItems).values(item as any).returning();
    return created;
  }

  async updateLoanItem(id: string, item: Partial<InsertLoanItem>): Promise<LoanItem | undefined> {
    const [updated] = await db.update(loanItems).set(item as any).where(eq(loanItems.id, id)).returning();
    return updated;
  }

  async deleteLoanItem(id: string): Promise<boolean> {
    const result = await db.delete(loanItems).where(eq(loanItems.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getActiveItemLoans(): Promise<ItemLoanWithItem[]> {
    const loans = await db.select().from(itemLoans)
      .where(isNull(itemLoans.returnedAt))
      .orderBy(desc(itemLoans.lentAt));
    const items = await db.select().from(loanItems);
    const itemsMap = new Map(items.map(i => [i.id, i]));
    return loans.map(l => ({ ...l, loanItem: itemsMap.get(l.loanItemId)! }));
  }

  async createItemLoan(loan: InsertItemLoan): Promise<ItemLoan> {
    const [created] = await db.insert(itemLoans).values(loan as any).returning();
    return created;
  }

  async returnItemLoan(id: string): Promise<ItemLoan | undefined> {
    const [updated] = await db.update(itemLoans)
      .set({ returnedAt: new Date() })
      .where(eq(itemLoans.id, id))
      .returning();
    return updated;
  }

  async getPayments(reservationId: string): Promise<Payment[]> {
    return db.select().from(payments).where(
      and(eq(payments.reservationId, reservationId), or(isNull(payments.status), eq(payments.status, "active")))
    );
  }

  async getAllPaymentsIncludingAnulados(reservationId: string): Promise<Payment[]> {
    return db.select().from(payments).where(eq(payments.reservationId, reservationId));
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [created] = await db.insert(payments).values(payment as any).returning();
    return created;
  }

  async updatePayment(id: string, payment: Partial<InsertPayment>): Promise<Payment | undefined> {
    const [updated] = await db.update(payments).set(payment as any).where(eq(payments.id, id)).returning();
    return updated;
  }

  async deletePayment(id: string): Promise<boolean> {
    const result = await db.delete(payments).where(eq(payments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getPaymentsTotal(reservationId: string): Promise<number> {
    const result = await db.select({ total: sql<string>`COALESCE(SUM(${payments.amount}::numeric), 0)` }).from(payments).where(
      and(eq(payments.reservationId, reservationId), or(isNull(payments.status), eq(payments.status, "active")))
    );
    return parseFloat(result[0]?.total || "0");
  }

  async getCancelledReservationLogs(): Promise<CancelledReservationLog[]> {
    return db.select().from(cancelledReservationLogs);
  }

  async createCancelledReservationLog(log: InsertCancelledReservationLog): Promise<CancelledReservationLog> {
    const [created] = await db.insert(cancelledReservationLogs).values(log as any).returning();
    return created;
  }

  async checkOverbooking(roomId: string, checkInDate: string, checkOutDate: string, excludeReservationId?: string): Promise<boolean> {
    const activeStatuses = ["tentative", "pending", "reserved", "confirmed", "web_checkin", "checked_in"] as const;
    let conditions = and(
      eq(reservations.roomId, roomId),
      inArray(reservations.status, activeStatuses as any),
      sql`${reservations.checkInDate} < ${checkOutDate}`,
      sql`${reservations.checkOutDate} > ${checkInDate}`
    );

    if (excludeReservationId) {
      conditions = and(conditions, ne(reservations.id, excludeReservationId));
    }

    const conflicts = await db.select({ cnt: count() }).from(reservations).where(conditions);
    return (conflicts[0]?.cnt ?? 0) > 0;
  }

  async getDashboardStats() {
    const allRooms = await db.select().from(rooms);
    const today = getArgentinaToday();

    // Excluir habitaciones virtuales e inactivas de todas las estadísticas
    const realRooms = allRooms.filter(r => !r.isVirtual && r.isActive !== false);
    const totalRooms = realRooms.length;

    // Estadísticas de habitaciones por status housekeeping (solo para referencia interna)
    const dirtyRooms = realRooms.filter(r => r.status === "dirty").length;
    const cleaningRooms = realRooms.filter(r => r.status === "cleaning").length;
    const oosRooms = realRooms.filter(r => r.status === "oos").length;

    // Ocupación basada en reservas: habitaciones con reserva activa hoy
    // (checkIn <= hoy AND checkOut > hoy AND status != cancelled/checked_out)
    const occupiedRoomsRows = await db.execute(sql`
      SELECT COUNT(DISTINCT r.room_id) AS cnt
      FROM reservations r
      JOIN rooms rm ON rm.id = r.room_id
      WHERE r.check_in_date <= ${today}
        AND r.check_out_date > ${today}
        AND r.status NOT IN ('cancelled', 'checked_out')
        AND (rm.is_virtual IS NULL OR rm.is_virtual = false)
    `);
    const occupiedRooms = Number((occupiedRoomsRows.rows[0] as any)?.cnt ?? 0);

    // Habitaciones en mantenimiento hoy (bloqueadas por maintenance_blocks)
    const maintenanceRoomsRows = await db.execute(sql`
      SELECT COUNT(DISTINCT mb.room_id) AS cnt
      FROM maintenance_blocks mb
      JOIN rooms rm ON rm.id = mb.room_id
      WHERE mb.block_from <= ${today}
        AND mb.block_to >= ${today}
        AND (rm.is_virtual IS NULL OR rm.is_virtual = false)
    `);
    const maintenanceRooms = Number((maintenanceRoomsRows.rows[0] as any)?.cnt ?? 0);

    // Detalles de bloques de mantenimiento activos hoy (para alertas)
    const maintenanceBlockDetailRows = await db.execute(sql`
      SELECT rm.room_number, mb.block_from, mb.block_to, mb.notes
      FROM maintenance_blocks mb
      JOIN rooms rm ON rm.id = mb.room_id
      WHERE mb.block_from <= ${today}
        AND mb.block_to >= ${today}
        AND (rm.is_virtual IS NULL OR rm.is_virtual = false)
      ORDER BY rm.room_number
    `);
    const maintenanceBlockDetails = maintenanceBlockDetailRows.rows.map((r: any) => ({
      roomNumber: r.room_number as string,
      blockFrom: r.block_from as string,
      blockTo: r.block_to as string,
      notes: (r.notes as string) || null,
    }));

    // Disponibles = total - ocupadas (por reserva) - en mantenimiento (por bloque)
    const availableRooms = Math.max(0, totalRooms - occupiedRooms - maintenanceRooms);

    // Check-ins hoy: todas las reservas con check-in = hoy, sin importar status excepto canceladas/checked_out
    const todayCheckInsResult = await db.execute(sql`
      SELECT COUNT(*) AS cnt
      FROM reservations r
      JOIN rooms rm ON rm.id = r.room_id
      WHERE r.check_in_date = ${today}
        AND r.status NOT IN ('cancelled', 'checked_out')
        AND (rm.is_virtual IS NULL OR rm.is_virtual = false)
    `);
    const todayCheckIns = Number((todayCheckInsResult.rows[0] as any)?.cnt ?? 0);

    const todayCheckOutsResult = await db.select({ cnt: count() }).from(reservations).where(
      and(eq(reservations.checkOutDate, today), eq(reservations.status, "checked_in"))
    );
    const todayCheckOuts = todayCheckOutsResult[0]?.cnt ?? 0;

    const occupancyRate = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;

    const totalGuestsResult = await db.select({ cnt: count() }).from(guests);
    const totalGuests = totalGuestsResult[0]?.cnt ?? 0;

    const pendingResult = await db.select({ cnt: count() }).from(reservations).where(
      inArray(reservations.status, ["pending", "tentative"] as any)
    );
    const pendingReservations = pendingResult[0]?.cnt ?? 0;

    // Desayunos mañana = pax en reservas checked_in que pasan la noche de hoy
    const tonightRows = await db.execute(sql`
      SELECT
        COALESCE(SUM(r.number_of_guests), 0) AS pax,
        COUNT(*) AS rooms_count
      FROM reservations r
      JOIN rooms rm ON rm.id = r.room_id
      WHERE r.check_in_date <= ${today}
        AND r.check_out_date > ${today}
        AND r.status = 'checked_in'
        AND (rm.is_virtual IS NULL OR rm.is_virtual = false)
    `);
    const breakfastsTomorrow = Number((tonightRows.rows[0] as any)?.pax ?? 0);
    const roomsTonight = Number((tonightRows.rows[0] as any)?.rooms_count ?? 0);

    // Personas in house = sum(numberOfGuests) de reservas checked_in activas hoy
    const inHouseRows = await db.execute(sql`
      SELECT COALESCE(SUM(r.number_of_guests), 0) AS pax
      FROM reservations r
      JOIN rooms rm ON rm.id = r.room_id
      WHERE r.check_in_date <= ${today}
        AND r.check_out_date > ${today}
        AND r.status = 'checked_in'
        AND (rm.is_virtual IS NULL OR rm.is_virtual = false)
    `);
    const inHouseGuests = Number((inHouseRows.rows[0] as any)?.pax ?? 0);

    return {
      totalRooms,
      availableRooms,
      occupiedRooms,
      inHouseGuests,
      dirtyRooms,
      cleaningRooms,
      maintenanceRooms,
      oosRooms,
      todayCheckIns,
      todayCheckOuts: Number(todayCheckOuts),
      occupancyRate,
      totalGuests: Number(totalGuests),
      pendingReservations: Number(pendingReservations),
      breakfastsTomorrow,
      roomsTonight,
      maintenanceBlockDetails,
    };
  }

  async getPlanningData(startDate: string, endDate: string): Promise<PlanningData> {
    const allRooms = await this.getRooms();
    const [allReservations, allBedTypes] = await Promise.all([
      db.select().from(reservations).where(
        and(
          ne(reservations.status, "cancelled"),
          sql`${reservations.checkInDate} <= ${endDate}`,
          sql`${reservations.checkOutDate} >= ${startDate}`
        )
      ),
      db.select().from(bedTypes),
    ]);
    const bedTypeMap = new Map(allBedTypes.map(bt => [bt.id, bt.name]));
    const allGroupLinks = await db.select().from(groupReservationLinks);
    const allGuests = await db.select().from(guests);
    const allGroups = await db.select().from(groups);

    const guestsMap = new Map(allGuests.map(g => [g.id, g]));
    const groupsMap = new Map(allGroups.map(g => [g.id, g]));
    const groupReservationIds = new Set(allGroupLinks.map(l => l.reservationId));

    const days: string[] = [];
    const start = new Date(startDate);
    const end = new Date(endDate);
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      days.push(d.toISOString().split("T")[0]);
    }

    const occupancy: Record<string, PlanningCellStatus[]> = {};
    const cellReservations: Record<string, Record<string, string>> = {};
    const cellGroupBlocks: Record<string, Record<string, string>> = {};
    const reservationsMap: Record<string, any> = {};
    const groupBlocksMap: Record<string, any> = {};

    const guestIdsWithRes = allReservations.map(r => r.guestId).filter(Boolean) as string[];
    const allActivePrefs = guestIdsWithRes.length > 0
      ? await db.select().from(guestPreferences).where(
          and(eq(guestPreferences.isActive, true), inArray(guestPreferences.guestId, guestIdsWithRes))
        )
      : [];
    const prefsByGuest = new Map<string, typeof allActivePrefs>();
    for (const p of allActivePrefs) {
      if (!prefsByGuest.has(p.guestId)) prefsByGuest.set(p.guestId, []);
      prefsByGuest.get(p.guestId)!.push(p);
    }

    for (const res of allReservations) {
      const guest = res.guestId ? guestsMap.get(res.guestId) : null;
      // Always add to reservationsMap, even without a guest (use fallback name)
      {
        const isGroupReservation = groupReservationIds.has(res.id);
        let groupName: string | undefined;
        let groupId: string | undefined;
        let groupColor: string | undefined;
        if (isGroupReservation) {
          const link = allGroupLinks.find(l => l.reservationId === res.id);
          if (link) {
            const group = groupsMap.get(link.groupId);
            if (group) {
              groupName = group.name;
              groupId = group.id;
              groupColor = group.color || "#6366f1";
            }
          }
        }
        const guestPrefs = prefsByGuest.get(res.guestId) || [];
        const prefSummary = guestPrefs.length > 0 ? {
          hasCritical: guestPrefs.some(p => p.priority === "critical"),
          hasHigh: guestPrefs.some(p => p.priority === "high"),
          hasSpecialDate: guestPrefs.some(p => p.category === "fecha_especial"),
          hasDiet: guestPrefs.some(p => p.category === "alimentacion"),
          count: guestPrefs.length,
        } : null;

        reservationsMap[res.id] = {
          id: res.id,
          guestName: guest ? `${guest.lastName} ${guest.firstName}`.trim() : "(Sin huésped)",
          checkIn: res.checkInDate,
          checkOut: res.checkOutDate,
          status: res.status as ReservationStatus,
          source: res.source as ReservationSource,
          isGroup: isGroupReservation,
          groupName,
          groupId,
          groupColor,
          earlyCheckIn: res.earlyCheckIn ?? false,
          earlyCheckInTime: res.earlyCheckInTime ?? null,
          lateCheckOut: res.lateCheckOut ?? false,
          lateCheckOutTime: res.lateCheckOutTime ?? null,
          prefSummary,
          isUpgrade: res.isUpgrade ?? false,
          movedFromRoomNumber: (res as any).movedFromRoomNumber ?? null,
          color: (res as any).color ?? null,
          numberOfGuests: res.numberOfGuests ?? null,
          bedTypeName: res.bedTypeId ? (bedTypeMap.get(res.bedTypeId) ?? null) : null,
        };
      }
    }

    // Load maintenance blocks for the period
    const allMaintenanceBlocks = await this.getMaintenanceBlocks({ from: startDate, to: endDate });
    // Index by roomId for fast lookup
    const maintenanceBlocksByRoom = new Map<string, Array<{ blockFrom: string; blockTo: string; id: string }>>();
    for (const blk of allMaintenanceBlocks) {
      if (!maintenanceBlocksByRoom.has(blk.roomId)) maintenanceBlocksByRoom.set(blk.roomId, []);
      maintenanceBlocksByRoom.get(blk.roomId)!.push({ blockFrom: blk.blockFrom, blockTo: blk.blockTo, id: blk.id });
    }

    for (const room of allRooms) {
      occupancy[room.id] = [];
      cellReservations[room.id] = {};
      cellGroupBlocks[room.id] = {};

      const todayStr = getArgentinaToday();
      const roomBlocks = maintenanceBlocksByRoom.get(room.id) || [];

      for (const day of days) {
        // Only block cells when there is a date-range maintenance block (created from Maintenance module)
        // Rooms with status "maintenance" from Housekeeping show the wrench icon but are NOT blocked
        const isBlockedForDay = roomBlocks.some(b => day >= b.blockFrom && day <= b.blockTo);
        if (isBlockedForDay) {
          occupancy[room.id].push("maintenance");
          continue;
        }
        // dirty, cleaning, inspected, maintenance: show status badge in room column but DON'T block cells

        const reservation = allReservations.find(r => {
          if (r.roomId !== room.id) return false;
          return day >= r.checkInDate && day < r.checkOutDate;
        });

        if (reservation) {
          cellReservations[room.id][day] = reservation.id;
          const isGroupRes = groupReservationIds.has(reservation.id);
          if (reservation.status === "checked_out") {
            occupancy[room.id].push("checked_out");
          } else if (isGroupRes) {
            occupancy[room.id].push("group_blocked");
          } else if (reservation.status === "checked_in") {
            if (reservation.checkOutDate === todayStr) {
              occupancy[room.id].push("checkout_today");
            } else {
              occupancy[room.id].push("checked_in");
            }
          } else if (day === reservation.checkInDate && day === todayStr) {
            occupancy[room.id].push("checkin_today");
          } else if (reservation.status === "web_checkin") {
            occupancy[room.id].push("web_checkin");
          } else {
            occupancy[room.id].push("booked");
          }
        } else {
          occupancy[room.id].push("available");
        }
      }

      for (let dayIndex = 0; dayIndex < days.length; dayIndex++) {
        const day = days[dayIndex];
        const currentStatus = occupancy[room.id][dayIndex];
        if (currentStatus !== "available") continue;

        const nextDay = days[dayIndex + 1];
        if (nextDay) {
          const earlyRes = allReservations.find(r =>
            r.roomId === room.id &&
            r.checkInDate === nextDay &&
            !!r.earlyCheckIn
          );
          if (earlyRes) {
            occupancy[room.id][dayIndex] = "early_blocked";
            cellReservations[room.id][day] = earlyRes.id;
            continue;
          }
        }

        const lateRes = allReservations.find(r =>
          r.roomId === room.id &&
          r.checkOutDate === day &&
          !!r.lateCheckOut
        );
        if (lateRes) {
          occupancy[room.id][dayIndex] = "late_blocked";
          cellReservations[room.id][day] = lateRes.id;
        }
      }
    }

    const allBlocks = await db.select().from(groupRoomBlocks);
    const allRoomTypes = await db.select().from(roomTypes);
    const roomTypesMap = new Map(allRoomTypes.map(rt => [rt.id, rt]));
    const allReservationsFull = await db.select().from(reservations).where(
      ne(reservations.status, "cancelled")
    );
    
    const unassignedGroupBlocks: NonNullable<PlanningData["unassignedGroupBlocks"]> = [];
    
    for (const group of allGroups) {
      if (group.status === "cancelled" || group.status === "finished") continue;
      const groupBlocks = allBlocks.filter(b => b.groupId === group.id);
      const groupLinks = allGroupLinks.filter(l => l.groupId === group.id);
      
      for (const block of groupBlocks) {
        const blockCheckIn = block.blockCheckInDate || group.checkInDate;
        const blockCheckOut = block.blockCheckOutDate || group.checkOutDate;
        
        if (blockCheckOut <= startDate || blockCheckIn >= endDate) continue;
        
        const assignedCount = groupLinks.filter(l => {
          const res = allReservationsFull.find(r => r.id === l.reservationId);
          return res && res.roomTypeId === block.roomTypeId;
        }).length;
        
        if (assignedCount < block.quantity) {
          const rt = roomTypesMap.get(block.roomTypeId);
          unassignedGroupBlocks.push({
            blockId: block.id,
            groupId: group.id,
            groupName: group.name,
            groupCode: group.groupCode,
            groupColor: group.color || "#6366f1",
            roomTypeId: block.roomTypeId,
            roomTypeName: rt?.name || "Desconocido",
            quantity: block.quantity,
            assigned: assignedCount,
            checkIn: blockCheckIn,
            checkOut: blockCheckOut,
          });
        }
      }
    }

    return {
      rooms: allRooms,
      days,
      occupancy,
      groupBlocks: groupBlocksMap,
      cellGroupBlocks,
      reservations: reservationsMap,
      cellReservations,
      unassignedGroupBlocks,
    };
  }

  async getOTAChannels(): Promise<OTAChannelWithStats[]> {
    const channels = await db.select().from(otaChannels);
    const logs = await db.select().from(otaReservationLogs);

    return channels.map(channel => {
      const channelLogs = logs.filter(l => l.channelId === channel.id);
      return {
        ...channel,
        totalReservations: channelLogs.length,
        pendingSync: channelLogs.filter(l => l.status === "pending").length,
        totalRevenue: channelLogs.reduce((sum, l) => sum + parseFloat(l.totalAmount || "0"), 0),
        totalCommission: channelLogs.reduce((sum, l) => sum + parseFloat(l.commission || "0"), 0),
      };
    });
  }

  async getOTAChannel(id: string): Promise<OTAChannel | undefined> {
    const [channel] = await db.select().from(otaChannels).where(eq(otaChannels.id, id));
    return channel;
  }

  async createOTAChannel(channel: InsertOTAChannel): Promise<OTAChannel> {
    const [created] = await db.insert(otaChannels).values(channel as any).returning();
    return created;
  }

  async updateOTAChannel(id: string, channel: Partial<InsertOTAChannel>): Promise<OTAChannel | undefined> {
    const [updated] = await db.update(otaChannels).set(channel as any).where(eq(otaChannels.id, id)).returning();
    return updated;
  }

  async deleteOTAChannel(id: string): Promise<boolean> {
    const result = await db.delete(otaChannels).where(eq(otaChannels.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getOTAReservationLogs(channelId?: string): Promise<OTAReservationLogWithChannel[]> {
    let logs: OTAReservationLog[];
    if (channelId) {
      logs = await db.select().from(otaReservationLogs).where(eq(otaReservationLogs.channelId, channelId)).orderBy(desc(otaReservationLogs.createdAt));
    } else {
      logs = await db.select().from(otaReservationLogs).orderBy(desc(otaReservationLogs.createdAt));
    }
    const channels = await db.select().from(otaChannels);
    const channelsMap = new Map(channels.map(c => [c.id, c]));
    return logs.map(log => ({ ...log, channel: channelsMap.get(log.channelId)! }));
  }

  async getOTAReservationLog(id: string): Promise<OTAReservationLogWithChannel | undefined> {
    const [log] = await db.select().from(otaReservationLogs).where(eq(otaReservationLogs.id, id));
    if (!log) return undefined;
    const [channel] = await db.select().from(otaChannels).where(eq(otaChannels.id, log.channelId));
    return { ...log, channel };
  }

  async createOTAReservationLog(log: InsertOTAReservationLog): Promise<OTAReservationLog> {
    const [created] = await db.insert(otaReservationLogs).values(log as any).returning();
    return created;
  }

  async updateOTAReservationLog(id: string, log: Partial<InsertOTAReservationLog>): Promise<OTAReservationLog | undefined> {
    const [updated] = await db.update(otaReservationLogs).set(log as any).where(eq(otaReservationLogs.id, id)).returning();
    return updated;
  }

  async syncOTAReservation(logId: string): Promise<Reservation | undefined> {
    const [log] = await db.select().from(otaReservationLogs).where(eq(otaReservationLogs.id, logId));
    if (!log || log.status === "synced") return undefined;

    const [channel] = await db.select().from(otaChannels).where(eq(otaChannels.id, log.channelId));
    if (!channel) return undefined;

    const nameParts = log.guestName.split(" ");
    const firstName = nameParts[0] || "OTA";
    const lastName = nameParts.slice(1).join(" ") || "Guest";

    let [guest] = await db.select().from(guests).where(
      and(eq(guests.firstName, firstName), eq(guests.lastName, lastName))
    );
    if (!guest) {
      guest = await this.createGuest({ firstName, lastName });
    }

    let roomType: RoomType | undefined;
    if (log.roomTypeName) {
      [roomType] = await db.select().from(roomTypes).where(eq(roomTypes.name, log.roomTypeName));
    }
    if (!roomType) {
      [roomType] = await db.select().from(roomTypes).limit(1);
    }
    if (!roomType) return undefined;

    const [availableRoom] = await db.select().from(rooms).where(
      and(eq(rooms.roomTypeId, roomType.id), eq(rooms.status, "available"))
    ).limit(1);
    if (!availableRoom) return undefined;

    const checkIn = new Date(log.checkInDate);
    const checkOut = new Date(log.checkOutDate);
    const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));

    const reservation = await this.createReservation({
      reservationCode: this.generateReservationCode(),
      guestId: guest.id,
      roomTypeId: roomType.id,
      roomId: availableRoom.id,
      ratePlanId: null,
      checkInDate: log.checkInDate,
      checkOutDate: log.checkOutDate,
      nights,
      baseRatePerNight: log.netAmount ? (parseFloat(log.netAmount) / nights).toFixed(2) : null,
      discountType: "none",
      discountValue: "0",
      finalRatePerNight: log.netAmount ? (parseFloat(log.netAmount) / nights).toFixed(2) : null,
      totalRoomAmount: log.netAmount,
      status: "confirmed",
      source: channel.channelType as any,
      otaChannelId: channel.id,
      externalReservationId: log.externalReservationId,
      numberOfGuests: 1,
      notes: `Reserva importada de ${channel.name}`,
      createdAt: new Date(),
      lastModifiedBy: null,
    });

    await this.updateOTAReservationLog(logId, {
      status: "synced",
      internalReservationId: reservation.id,
      syncedAt: new Date(),
    });

    return reservation;
  }

  async getGroups(): Promise<GroupWithDetails[]> {
    const allGroups = await db.select().from(groups).orderBy(desc(groups.createdAt));
    if (allGroups.length === 0) return [];

    const allGroupIds = allGroups.map(g => g.id);

    // Bulk-fetch all blocks and links in 2 queries (instead of 2×N)
    const [allBlocks, allLinks, allRoomTypesList, allRatePlansList] = await Promise.all([
      db.select().from(groupRoomBlocks).where(inArray(groupRoomBlocks.groupId, allGroupIds)),
      db.select().from(groupReservationLinks).where(inArray(groupReservationLinks.groupId, allGroupIds)),
      db.select().from(roomTypes),
      db.select().from(ratePlans),
    ]);

    const roomTypeMap = new Map(allRoomTypesList.map(t => [t.id, t]));
    const ratePlanMap = new Map(allRatePlansList.map(p => [p.id, p]));

    // Bulk-fetch all linked reservations by status in 1 query (for assigned count + delete confirm)
    const allResIds = [...new Set(allLinks.map(l => l.reservationId))];
    const allResRows = allResIds.length > 0
      ? await db.select({ id: reservations.id, status: reservations.status, groupId: groupReservationLinks.groupId })
          .from(reservations)
          .innerJoin(groupReservationLinks, eq(groupReservationLinks.reservationId, reservations.id))
          .where(inArray(reservations.id, allResIds))
      : [];

    // Group-level maps
    const blocksByGroup = new Map<string, any[]>();
    const resByGroup = new Map<string, any[]>();
    for (const b of allBlocks) {
      if (!blocksByGroup.has(b.groupId)) blocksByGroup.set(b.groupId, []);
      blocksByGroup.get(b.groupId)!.push({
        ...b,
        roomType: roomTypeMap.get(b.roomTypeId),
        ratePlan: b.ratePlanId ? ratePlanMap.get(b.ratePlanId) : undefined,
      });
    }
    for (const r of allResRows) {
      if (!resByGroup.has(r.groupId)) resByGroup.set(r.groupId, []);
      resByGroup.get(r.groupId)!.push(r);
    }

    return allGroups.map(group => {
      const blocks = blocksByGroup.get(group.id) || [];
      const resRows = resByGroup.get(group.id) || [];
      const totalRooms = blocks.reduce((sum: number, b: any) => sum + b.quantity, 0);
      const assignedRooms = resRows.filter((r: any) => r.status !== "cancelled" && r.status !== "checked_out").length;
      // reservations array in list view only needs status (for delete confirm count)
      return { ...group, blocks, reservations: resRows as any[], totalRooms, assignedRooms };
    });
  }

  async getGroup(id: string): Promise<GroupWithDetails | undefined> {
    const [group] = await db.select().from(groups).where(eq(groups.id, id));
    if (!group) return undefined;
    return this.buildGroupWithDetails(group);
  }

  private async buildGroupWithDetails(group: Group): Promise<GroupWithDetails> {
    // Parallel: fetch blocks and reservation links
    const [blocks, links] = await Promise.all([
      this.getGroupBlocks(group.id),
      this.getGroupReservationLinks(group.id),
    ]);

    // Batch-fetch all linked reservations in one call (uses enrichReservations internally)
    // Deduplicate resIds to guard against duplicate groupReservationLinks entries
    const resIds = [...new Set(links.map(l => l.reservationId))];
    let reservationsList: ReservationWithDetails[] = [];
    if (resIds.length > 0) {
      const rawReservations = await db.select().from(reservations).where(inArray(reservations.id, resIds));
      reservationsList = await this.enrichReservations(rawReservations);
    }

    const totalRooms = blocks.reduce((sum, b) => sum + b.quantity, 0);
    const assignedRooms = reservationsList.filter(r => r.status !== "cancelled" && r.status !== "checked_out").length;
    return { ...group, blocks, reservations: reservationsList, totalRooms, assignedRooms };
  }

  async createGroup(group: InsertGroup): Promise<Group> {
    const [created] = await db.insert(groups).values(group as any).returning();
    return created;
  }

  async updateGroup(id: string, group: Partial<InsertGroup>): Promise<Group | undefined> {
    const safeData: Record<string, any> = {};
    for (const [key, value] of Object.entries(group)) {
      if (["id", "createdAt", "groupCode"].includes(key) || value === undefined) continue;
      safeData[key] = value;
    }
    if (Object.keys(safeData).length === 0) return undefined;
    const [updated] = await db.update(groups).set(safeData).where(eq(groups.id, id)).returning();
    return updated;
  }

  async deleteGroup(id: string): Promise<boolean> {
    // 1. Get all linked reservations
    const links = await db.select().from(groupReservationLinks).where(eq(groupReservationLinks.groupId, id));

    // 2. Cancel each linked reservation and free its room
    for (const link of links) {
      const [res] = await db.select().from(reservations).where(eq(reservations.id, link.reservationId));
      if (res) {
        // Only cancel if not already checked_out
        if (res.status !== "checked_out") {
          await db.update(reservations)
            .set({ status: "cancelled" })
            .where(eq(reservations.id, res.id));
        }
        // Free the room (set to available) if it was held/occupied by this reservation
        if (res.roomId) {
          await db.update(rooms)
            .set({ status: "available" })
            .where(eq(rooms.id, res.roomId));
        }
      }
    }

    // 3. Delete group sub-records (charges, payments, blocks, links)
    await db.delete(groupCharges).where(eq(groupCharges.groupId, id));
    await db.delete(groupPayments).where(eq(groupPayments.groupId, id));
    await db.delete(groupRoomBlocks).where(eq(groupRoomBlocks.groupId, id));
    await db.delete(groupReservationLinks).where(eq(groupReservationLinks.groupId, id));

    // 4. Delete the group itself
    const result = await db.delete(groups).where(eq(groups.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  generateGroupCode(): string {
    const now = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `GRP-${now}-${random}`;
  }

  async getGroupBlocks(groupId: string): Promise<GroupRoomBlockWithDetails[]> {
    const blocks = await db.select().from(groupRoomBlocks).where(eq(groupRoomBlocks.groupId, groupId));
    const types = await db.select().from(roomTypes);
    const plans = await db.select().from(ratePlans);
    const typesMap = new Map(types.map(t => [t.id, t]));
    const plansMap = new Map(plans.map(p => [p.id, p]));
    return blocks.map(b => ({
      ...b,
      roomType: typesMap.get(b.roomTypeId)!,
      ratePlan: b.ratePlanId ? plansMap.get(b.ratePlanId) : undefined,
    }));
  }

  async createGroupBlock(block: InsertGroupRoomBlock): Promise<GroupRoomBlock> {
    const [created] = await db.insert(groupRoomBlocks).values(block as any).returning();
    return created;
  }

  async updateGroupBlock(id: string, block: Partial<InsertGroupRoomBlock>): Promise<GroupRoomBlock | undefined> {
    const [updated] = await db.update(groupRoomBlocks).set(block as any).where(eq(groupRoomBlocks.id, id)).returning();
    return updated;
  }

  async deleteGroupBlock(id: string): Promise<boolean> {
    const result = await db.delete(groupRoomBlocks).where(eq(groupRoomBlocks.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getGroupReservationLinks(groupId: string): Promise<GroupReservationLink[]> {
    return db.select().from(groupReservationLinks).where(eq(groupReservationLinks.groupId, groupId));
  }

  async createGroupReservationLink(link: InsertGroupReservationLink): Promise<GroupReservationLink> {
    const [created] = await db.insert(groupReservationLinks).values(link as any).returning();
    return created;
  }

  async assignRoomToGroup(
    groupId: string,
    roomId: string,
    guestFirstName: string,
    guestLastName: string,
    options?: {
      checkInDate?: string;
      checkOutDate?: string;
      agreedRate?: string;
      ratePlanId?: string | null;
    }
  ): Promise<Reservation | undefined> {
    const [group] = await db.select().from(groups).where(eq(groups.id, groupId));
    if (!group) return undefined;

    const [room] = await db.select().from(rooms).where(eq(rooms.id, roomId));
    if (!room) return undefined;

    // Always create a fresh guest per reservation — never reuse by name.
    // Reusing a guest by name-match means two rooms share the same guestId;
    // subsequent edits to one room appear to "replicate" to the other.
    const guest = await this.createGuest({ firstName: guestFirstName, lastName: guestLastName });

    const blocks = await this.getGroupBlocks(groupId);
    const matchingBlock = blocks.find(b => b.roomTypeId === room.roomTypeId);

    const checkInDate = options?.checkInDate || matchingBlock?.blockCheckInDate || group.checkInDate;
    const checkOutDate = options?.checkOutDate || matchingBlock?.blockCheckOutDate || group.checkOutDate;
    const agreedRate = options?.agreedRate || matchingBlock?.agreedRate || "0";
    const ratePlanId = options?.ratePlanId !== undefined ? options.ratePlanId : (matchingBlock?.ratePlanId || null);

    const checkIn = new Date(checkInDate);
    const checkOut = new Date(checkOutDate);
    const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));

    // Verify no overbooking conflict before creating reservation
    const hasConflict = await this.checkOverbooking(roomId, checkInDate, checkOutDate, undefined);
    if (hasConflict) {
      throw new Error(`La habitación ${room.roomNumber} ya tiene una reserva en esas fechas`);
    }

    const reservation = await this.createReservation({
      reservationCode: `G${group.groupCode}-${room.roomNumber}`,
      guestId: guest.id,
      roomTypeId: room.roomTypeId,
      roomId: room.id,
      ratePlanId,
      checkInDate,
      checkOutDate,
      nights,
      baseRatePerNight: agreedRate,
      discountType: "none",
      discountValue: "0",
      finalRatePerNight: agreedRate,
      totalRoomAmount: (parseFloat(agreedRate) * nights).toFixed(2),
      status: "confirmed",
      source: "empresa",
      otaChannelId: null,
      externalReservationId: null,
      numberOfGuests: 1,
      notes: `Grupo: ${group.name}`,
      createdAt: new Date(),
      lastModifiedBy: null,
    });

    await this.createGroupReservationLink({
      groupId,
      reservationId: reservation.id,
    });

    return reservation;
  }

  // ─── Group Folio (Cargos y Pagos Grupales) ───────────────────────────────

  async createGroupCharge(charge: InsertGroupCharge): Promise<GroupCharge> {
    const [created] = await db.insert(groupCharges).values(charge as any).returning();
    return created;
  }

  async getGroupCharges(groupId: string): Promise<GroupCharge[]> {
    return db.select().from(groupCharges).where(eq(groupCharges.groupId, groupId)).orderBy(desc(groupCharges.createdAt));
  }

  async deleteGroupCharge(id: string): Promise<boolean> {
    const result = await db.delete(groupCharges).where(eq(groupCharges.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async createGroupPayment(payment: InsertGroupPayment): Promise<GroupPayment> {
    const [created] = await db.insert(groupPayments).values(payment as any).returning();
    return created;
  }

  async getGroupPayments(groupId: string): Promise<GroupPayment[]> {
    return db.select().from(groupPayments).where(eq(groupPayments.groupId, groupId)).orderBy(desc(groupPayments.createdAt));
  }

  async transferChargeToGroup(chargeId: string, groupId: string): Promise<GroupCharge> {
    const [srcCharge] = await db.select().from(charges).where(eq(charges.id, chargeId));
    if (!srcCharge) throw new Error("Cargo no encontrado");
    const [created] = await db.insert(groupCharges).values({
      groupId,
      description: `[Transferido] ${srcCharge.description}`,
      amount: srcCharge.amount,
      date: srcCharge.date,
      category: srcCharge.category,
      billingTarget: "group",
      reservationId: srcCharge.reservationId,
      createdBy: srcCharge.createdBy,
    } as any).returning();
    return created;
  }

  async getGroupFolio(groupId: string): Promise<GroupFolioData> {
    const group = await this.getGroup(groupId);
    if (!group) throw new Error("Grupo no encontrado");

    const activeReservations = group.reservations.filter((r: any) => r.status !== "cancelled");
    const resIds = activeReservations.map((r: any) => r.id).filter(Boolean);

    // Batch-fetch everything in parallel — no per-reservation queries
    const [gCharges, gPayments, allResCharges, allResPayments] = await Promise.all([
      this.getGroupCharges(groupId),
      this.getGroupPayments(groupId),
      resIds.length > 0
        ? db.select().from(charges).where(inArray(charges.reservationId, resIds))
        : Promise.resolve([]),
      resIds.length > 0
        ? db.select().from(payments).where(inArray(payments.reservationId, resIds))
        : Promise.resolve([]),
    ]);

    // Build lookup maps
    const chargesMap = new Map<string, Charge[]>();
    for (const c of allResCharges) {
      if (!chargesMap.has(c.reservationId!)) chargesMap.set(c.reservationId!, []);
      chargesMap.get(c.reservationId!)!.push(c);
    }
    const paymentsMap = new Map<string, Payment[]>();
    for (const p of allResPayments) {
      if (!paymentsMap.has(p.reservationId!)) paymentsMap.set(p.reservationId!, []);
      paymentsMap.get(p.reservationId!)!.push(p);
    }

    // Fetch void folio_movements for all reservation folios in this group
    let voidMovementsWithContext: GroupFolioData["voidMovements"] = [];
    if (resIds.length > 0) {
      const resFolioRows = await db.select({ id: folios.id, entityId: folios.entityId })
        .from(folios)
        .where(and(eq(folios.entityType, "reservation"), inArray(folios.entityId, resIds)));
      const resFolioIds = resFolioRows.map((r) => r.id);
      if (resFolioIds.length > 0) {
        const voidRows = await db.select().from(folioMovements).where(
          and(
            inArray(folioMovements.folioId, resFolioIds),
            eq(folioMovements.type, "void")
          )
        );
        // Build folio → reservationId map for context lookup
        const folioToResId = new Map<string, string>(
          resFolioRows.map((r) => [r.id, r.entityId])
        );
        // Build reservationId → context map
        const resContextMap = new Map<string, { guestName: string; roomNumber: string }>(
          activeReservations.map((r: any) => [
            r.id,
            {
              guestName: `${r.guest?.lastName || ""} ${r.guest?.firstName || ""}`.trim(),
              roomNumber: r.room?.roomNumber || "-",
            },
          ])
        );
        voidMovementsWithContext = voidRows.map((vm) => {
          const resId = folioToResId.get(vm.folioId) ?? "";
          const ctx = resContextMap.get(resId) ?? { guestName: "", roomNumber: "-" };
          return {
            id: vm.id,
            amount: vm.amount,
            description: vm.description,
            voidReason: vm.voidReason,
            registeredBy: vm.registeredBy,
            createdAt: vm.createdAt,
            reservationId: resId,
            guestName: ctx.guestName,
            roomNumber: ctx.roomNumber,
          };
        });
      }
    }
    const voidMovementsTotal = voidMovementsWithContext.reduce((s, vm) => s + parseFloat(vm.amount), 0);

    const groupChargesTotal = gCharges.reduce((s, c) => s + parseFloat(c.amount), 0);
    const groupPaymentsTotal = gPayments.reduce((s, p) => s + parseFloat(p.amount), 0);

    let accommodationTotal = 0;
    let extrasTotal = 0;
    let indivPaymentsTotal = 0;

    const resRows = activeReservations.map((res: any) => {
      const resCharges = chargesMap.get(res.id) || [];
      const resPayments = paymentsMap.get(res.id) || [];
      const accTotal = parseFloat(res.totalRoomAmount || "0");
      const extTotal = resCharges.filter((c: any) => c.status !== "anulado").reduce((s: number, c: any) => s + parseFloat(c.amount), 0);
      // Exclude voided (anulado) payments from the balance so voids restore the owed amount
      const activeResPayments = resPayments.filter((p: any) => p.status !== "anulado");
      const payTotal = activeResPayments.reduce((s: number, p: any) => s + parseFloat(p.amount), 0);
      const nights = res.nights || 0;

      accommodationTotal += accTotal;
      extrasTotal += extTotal;
      indivPaymentsTotal += payTotal;

      return {
        reservationId: res.id,
        guestName: `${res.guest?.lastName || ""} ${res.guest?.firstName || ""}`.trim(),
        roomNumber: res.room?.roomNumber || "-",
        nights,
        accommodationTotal: accTotal,
        extrasTotal: extTotal,
        paymentsTotal: payTotal,
        balance: accTotal + extTotal - payTotal,
      };
    });

    // IMPORTANT: individual payments already carry the distributed amounts per room.
    // groupPaymentsTotal is an audit record of the received total and must NOT be added
    // again — doing so would duplicate the full payment amount.
    const totalPayments = indivPaymentsTotal;
    const balance = accommodationTotal + extrasTotal + groupChargesTotal - totalPayments;

    return {
      group,
      groupCharges: gCharges,
      groupChargesTotal,
      reservations: resRows,
      groupPayments: gPayments,
      groupPaymentsTotal,
      voidMovements: voidMovementsWithContext,
      voidMovementsTotal,
      totals: {
        accommodation: accommodationTotal,
        groupCharges: groupChargesTotal,
        extras: extrasTotal,
        payments: totalPayments,
        voids: voidMovementsTotal,
        balance,
      },
    };
  }

  async distributeGroupPayment(
    groupId: string,
    totalAmount: number,
    distribution: string,
    manualDetail?: Record<string, number>
  ): Promise<Record<string, number>> {
    const group = await this.getGroup(groupId);
    if (!group) return {};
    const activeRes = group.reservations.filter(r =>
      r.status === "confirmed" || r.status === "checked_in"
    );
    if (activeRes.length === 0) return {};

    if (distribution === "equal") {
      const perRoom = totalAmount / activeRes.length;
      return Object.fromEntries(activeRes.map(r => [r.id, perRoom]));
    }
    if (distribution === "proportional_nights") {
      const totalNights = activeRes.reduce((s, r) => s + (r.nights || 1), 0);
      return Object.fromEntries(activeRes.map(r => [r.id, totalAmount * ((r.nights || 1) / totalNights)]));
    }
    if (distribution === "proportional_rate") {
      const totalCost = activeRes.reduce((s, r) => s + parseFloat(r.totalRoomAmount || "0"), 0);
      return Object.fromEntries(activeRes.map(r => [r.id, totalAmount * (parseFloat(r.totalRoomAmount || "0") / (totalCost || 1))]));
    }
    if (distribution === "manual" && manualDetail) {
      return manualDetail;
    }
    const perRoom = totalAmount / activeRes.length;
    return Object.fromEntries(activeRes.map(r => [r.id, perRoom]));
  }

  async getGuestReviews(): Promise<GuestReviewWithDetails[]> {
    const reviews = await db.select().from(guestReviews).orderBy(desc(guestReviews.reviewDate));
    const allGuests = await db.select().from(guests);
    const allRooms = await db.select().from(rooms);
    const allRes = await db.select().from(reservations);
    const guestsMap = new Map(allGuests.map(g => [g.id, g]));
    const roomsMap = new Map(allRooms.map(r => [r.id, r]));
    const resMap = new Map(allRes.map(r => [r.id, r]));

    return reviews.map(r => ({
      ...r,
      guest: guestsMap.get(r.guestId)!,
      room: r.roomId ? roomsMap.get(r.roomId) : undefined,
      reservation: r.reservationId ? resMap.get(r.reservationId) : undefined,
    }));
  }

  async getGuestReview(id: string): Promise<GuestReviewWithDetails | undefined> {
    const [review] = await db.select().from(guestReviews).where(eq(guestReviews.id, id));
    if (!review) return undefined;
    const [guest] = await db.select().from(guests).where(eq(guests.id, review.guestId));
    const room = review.roomId ? (await db.select().from(rooms).where(eq(rooms.id, review.roomId)))[0] : undefined;
    const reservation = review.reservationId ? (await db.select().from(reservations).where(eq(reservations.id, review.reservationId)))[0] : undefined;
    return { ...review, guest, room, reservation };
  }

  async getGuestReviewsByGuest(guestId: string): Promise<GuestReviewWithDetails[]> {
    const reviews = await db.select().from(guestReviews).where(eq(guestReviews.guestId, guestId)).orderBy(desc(guestReviews.reviewDate));
    const [guest] = await db.select().from(guests).where(eq(guests.id, guestId));
    const allRooms = await db.select().from(rooms);
    const allRes = await db.select().from(reservations);
    const roomsMap = new Map(allRooms.map(r => [r.id, r]));
    const resMap = new Map(allRes.map(r => [r.id, r]));

    return reviews.map(r => ({
      ...r,
      guest,
      room: r.roomId ? roomsMap.get(r.roomId) : undefined,
      reservation: r.reservationId ? resMap.get(r.reservationId) : undefined,
    }));
  }

  async createGuestReview(review: InsertGuestReview): Promise<GuestReview> {
    const [created] = await db.insert(guestReviews).values(review as any).returning();
    return created;
  }

  async updateGuestReview(id: string, review: Partial<InsertGuestReview>): Promise<GuestReview | undefined> {
    const [updated] = await db.update(guestReviews).set(review as any).where(eq(guestReviews.id, id)).returning();
    return updated;
  }

  async deleteGuestReview(id: string): Promise<boolean> {
    const result = await db.delete(guestReviews).where(eq(guestReviews.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getReviewAnalyticsSummary() {
    const reviews = await db.select().from(guestReviews);
    const totalReviews = reviews.length;
    const averageRating = totalReviews > 0
      ? reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews
      : 0;

    const sentimentBreakdown = {
      positive: reviews.filter(r => r.sentiment === "positive").length,
      neutral: reviews.filter(r => r.sentiment === "neutral").length,
      negative: reviews.filter(r => r.sentiment === "negative").length,
    };

    const categoryMap = new Map<string, { count: number; totalScore: number }>();
    reviews.forEach(r => {
      if (r.categories) {
        r.categories.forEach(cat => {
          const existing = categoryMap.get(cat) || { count: 0, totalScore: 0 };
          const score = r.sentimentScore ? parseFloat(r.sentimentScore) : 0.5;
          categoryMap.set(cat, { count: existing.count + 1, totalScore: existing.totalScore + score });
        });
      }
    });

    const topCategories = Array.from(categoryMap.entries())
      .map(([category, data]) => ({
        category,
        count: data.count,
        avgSentiment: data.totalScore / data.count,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    const dateMap = new Map<string, { total: number; count: number }>();
    reviews.forEach(r => {
      const date = r.reviewDate.split("T")[0];
      const existing = dateMap.get(date) || { total: 0, count: 0 };
      dateMap.set(date, { total: existing.total + r.rating, count: existing.count + 1 });
    });

    const recentTrend = Array.from(dateMap.entries())
      .map(([date, data]) => ({
        date,
        avgRating: data.total / data.count,
        count: data.count,
      }))
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-7);

    const improvementAreas: string[] = [];
    reviews
      .filter(r => r.sentiment === "negative" && r.improvementSuggestions)
      .forEach(r => {
        if (r.improvementSuggestions) {
          improvementAreas.push(...r.improvementSuggestions);
        }
      });

    return {
      totalReviews,
      averageRating: Math.round(averageRating * 10) / 10,
      sentimentBreakdown,
      topCategories,
      recentTrend,
      improvementAreas: Array.from(new Set(improvementAreas)).slice(0, 10),
    };
  }

  async getHousekeepingTasks(date?: string, assignedTo?: string): Promise<HousekeepingTaskWithRoom[]> {
    let tasks: HousekeepingTask[];
    if (date && assignedTo) {
      tasks = await db.select().from(housekeepingTasks).where(
        and(eq(housekeepingTasks.scheduledDate, date), eq(housekeepingTasks.assignedTo, assignedTo))
      );
    } else if (date) {
      tasks = await db.select().from(housekeepingTasks).where(eq(housekeepingTasks.scheduledDate, date));
    } else {
      tasks = await db.select().from(housekeepingTasks);
    }

    const allRooms = await db.select().from(rooms);
    const allRoomTypes = await db.select().from(roomTypes);
    const roomsMap = new Map(allRooms.map(r => [r.id, r]));
    const typesMap = new Map(allRoomTypes.map(t => [t.id, t]));

    return tasks.map(task => {
      const room = roomsMap.get(task.roomId);
      const roomType = room ? typesMap.get(room.roomTypeId) : undefined;
      return { ...task, room: { ...room!, roomType } };
    }).sort((a, b) => {
      const priorityOrder: Record<string, number> = { urgent: 0, high: 1, normal: 2, low: 3 };
      return (priorityOrder[a.priority] ?? 2) - (priorityOrder[b.priority] ?? 2);
    });
  }

  async getHousekeepingTask(id: string): Promise<HousekeepingTaskWithRoom | undefined> {
    const [task] = await db.select().from(housekeepingTasks).where(eq(housekeepingTasks.id, id));
    if (!task) return undefined;
    const [room] = await db.select().from(rooms).where(eq(rooms.id, task.roomId));
    const roomType = room ? (await db.select().from(roomTypes).where(eq(roomTypes.id, room.roomTypeId)))[0] : undefined;
    return { ...task, room: { ...room!, roomType } };
  }

  async getHousekeepingTasksByRoom(roomId: string): Promise<HousekeepingTask[]> {
    return db.select().from(housekeepingTasks).where(eq(housekeepingTasks.roomId, roomId));
  }

  async createHousekeepingTask(task: InsertHousekeepingTask): Promise<HousekeepingTask> {
    const [created] = await db.insert(housekeepingTasks).values(task as any).returning();
    return created;
  }

  async updateHousekeepingTask(id: string, task: Partial<InsertHousekeepingTask>): Promise<HousekeepingTask | undefined> {
    const [updated] = await db.update(housekeepingTasks).set(task as any).where(eq(housekeepingTasks.id, id)).returning();
    return updated;
  }

  async deleteHousekeepingTask(id: string): Promise<boolean> {
    const result = await db.delete(housekeepingTasks).where(eq(housekeepingTasks.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async createCheckoutCleaningTask(roomId: string): Promise<HousekeepingTask> {
    const today = getArgentinaToday();
    return this.createHousekeepingTask({
      roomId,
      taskType: "checkout_clean",
      status: "pending",
      priority: "high",
      scheduledDate: today,
      createdAt: new Date(),
    });
  }

  async getRestaurantAreas(): Promise<RestaurantArea[]> {
    return db.select().from(restaurantAreas).where(eq(restaurantAreas.isActive, "true"));
  }

  async getRestaurantArea(id: string): Promise<RestaurantArea | undefined> {
    const [area] = await db.select().from(restaurantAreas).where(eq(restaurantAreas.id, id));
    return area;
  }

  async createRestaurantArea(area: InsertRestaurantArea): Promise<RestaurantArea> {
    const [created] = await db.insert(restaurantAreas).values(area as any).returning();
    return created;
  }

  async updateRestaurantArea(id: string, area: Partial<InsertRestaurantArea>): Promise<RestaurantArea | undefined> {
    const [updated] = await db.update(restaurantAreas).set(area as any).where(eq(restaurantAreas.id, id)).returning();
    return updated;
  }

  async deleteRestaurantArea(id: string): Promise<boolean> {
    const result = await db.delete(restaurantAreas).where(eq(restaurantAreas.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getRestaurantTables(): Promise<RestaurantTableWithArea[]> {
    const tables = await db.select().from(restaurantTables).where(eq(restaurantTables.isActive, "true"));
    const areas = await db.select().from(restaurantAreas);
    const areasMap = new Map(areas.map(a => [a.id, a]));
    return tables.map(t => ({ ...t, area: areasMap.get(t.areaId)! }));
  }

  async getRestaurantTable(id: string): Promise<RestaurantTableWithArea | undefined> {
    const [table] = await db.select().from(restaurantTables).where(eq(restaurantTables.id, id));
    if (!table) return undefined;
    const [area] = await db.select().from(restaurantAreas).where(eq(restaurantAreas.id, table.areaId));
    return { ...table, area };
  }

  async getTablesByArea(areaId: string): Promise<RestaurantTable[]> {
    return db.select().from(restaurantTables).where(eq(restaurantTables.areaId, areaId));
  }

  async createRestaurantTable(table: InsertRestaurantTable): Promise<RestaurantTable> {
    const [created] = await db.insert(restaurantTables).values(table as any).returning();
    return created;
  }

  async updateRestaurantTable(id: string, table: Partial<InsertRestaurantTable>): Promise<RestaurantTable | undefined> {
    const [updated] = await db.update(restaurantTables).set(table as any).where(eq(restaurantTables.id, id)).returning();
    return updated;
  }

  async deleteRestaurantTable(id: string): Promise<boolean> {
    const result = await db.delete(restaurantTables).where(eq(restaurantTables.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getMenuCategories(): Promise<MenuCategory[]> {
    return db.select().from(menuCategories);
  }

  async getMenuCategory(id: string): Promise<MenuCategory | undefined> {
    const [cat] = await db.select().from(menuCategories).where(eq(menuCategories.id, id));
    return cat;
  }

  async createMenuCategory(category: InsertMenuCategory): Promise<MenuCategory> {
    const [created] = await db.insert(menuCategories).values(category as any).returning();
    return created;
  }

  async updateMenuCategory(id: string, category: Partial<InsertMenuCategory>): Promise<MenuCategory | undefined> {
    const [updated] = await db.update(menuCategories).set(category as any).where(eq(menuCategories.id, id)).returning();
    return updated;
  }

  async deleteMenuCategory(id: string): Promise<boolean> {
    const result = await db.delete(menuCategories).where(eq(menuCategories.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getMenuItems(): Promise<MenuItemWithCategory[]> {
    const items = await db.select().from(menuItems);
    const cats = await db.select().from(menuCategories);
    const catsMap = new Map(cats.map(c => [c.id, c]));
    return items.map(i => ({ ...i, category: catsMap.get(i.categoryId)! }));
  }

  async getMenuItem(id: string): Promise<MenuItemWithCategory | undefined> {
    const [item] = await db.select().from(menuItems).where(eq(menuItems.id, id));
    if (!item) return undefined;
    const [cat] = await db.select().from(menuCategories).where(eq(menuCategories.id, item.categoryId));
    return { ...item, category: cat };
  }

  async getMenuItemsByCategory(categoryId: string): Promise<MenuItem[]> {
    return db.select().from(menuItems).where(eq(menuItems.categoryId, categoryId));
  }

  // Platos e Inventario están unificados: todo plato tiene un artículo espejo en
  // inventory_items (item_kind = "plato", area Restaurant) para que sea visible desde
  // Inventario, aunque solo se pueda vender desde el módulo Restaurant.
  private async ensurePlatoCategory(): Promise<string> {
    const [existing] = await db.select().from(itemCategories).where(
      and(eq(itemCategories.area, "restaurant" as any), eq(itemCategories.name, "Platos"))
    );
    if (existing) return existing.id;
    const [created] = await db.insert(itemCategories).values({
      name: "Platos",
      description: "Platos del restaurante (generado automáticamente)",
      area: "restaurant" as any,
      isActive: "true",
    } as any).returning();
    return created.id;
  }

  private async syncMenuItemInventoryMirror(item: MenuItem): Promise<MenuItem> {
    if (item.inventoryItemId) {
      await db.update(inventoryItems).set({
        name: item.name,
        isActive: item.isActive,
      } as any).where(eq(inventoryItems.id, item.inventoryItemId));
      return item;
    }
    const categoryId = await this.ensurePlatoCategory();
    const [mirror] = await db.insert(inventoryItems).values({
      name: item.name,
      categoryId,
      unit: "unidad",
      itemKind: "plato",
      isActive: item.isActive ?? "true",
    } as any).returning();
    const [updated] = await db.update(menuItems).set({ inventoryItemId: mirror.id } as any)
      .where(eq(menuItems.id, item.id)).returning();
    return updated;
  }

  async createMenuItem(item: InsertMenuItem): Promise<MenuItem> {
    const [created] = await db.insert(menuItems).values(item as any).returning();
    return this.syncMenuItemInventoryMirror(created);
  }

  async updateMenuItem(id: string, item: Partial<InsertMenuItem>): Promise<MenuItem | undefined> {
    const [updated] = await db.update(menuItems).set(item as any).where(eq(menuItems.id, id)).returning();
    if (!updated) return undefined;
    return this.syncMenuItemInventoryMirror(updated);
  }

  async menuItemHasMovement(id: string): Promise<boolean> {
    const [row] = await db.select({ id: orderItems.id }).from(orderItems).where(eq(orderItems.menuItemId, id)).limit(1);
    return !!row;
  }

  async deleteMenuItem(id: string): Promise<{ deleted: boolean; deactivated: boolean }> {
    const [item] = await db.select().from(menuItems).where(eq(menuItems.id, id));
    if (!item) return { deleted: false, deactivated: false };

    const hasMovement = await this.menuItemHasMovement(id);
    if (hasMovement) {
      await db.update(menuItems).set({ isActive: "false", isAvailable: "false" } as any).where(eq(menuItems.id, id));
      if (item.inventoryItemId) {
        await db.update(inventoryItems).set({ isActive: "false" } as any).where(eq(inventoryItems.id, item.inventoryItemId));
      }
      return { deleted: false, deactivated: true };
    }

    if (item.inventoryItemId) {
      await db.delete(inventoryItems).where(eq(inventoryItems.id, item.inventoryItemId));
    }
    const result = await db.delete(menuItems).where(eq(menuItems.id, id));
    return { deleted: (result.rowCount ?? 0) > 0, deactivated: false };
  }

  async closeStaleOrders(): Promise<number> {
    // 1. Cierra órdenes activas de días anteriores (Argentina) y libera sus mesas.
    const staleOrders = await db.select({ id: restaurantOrders.id, tableId: restaurantOrders.tableId })
      .from(restaurantOrders)
      .where(
        and(
          not(inArray(restaurantOrders.status, ["closed", "cancelled"])),
          sql`DATE(${restaurantOrders.openedAt} AT TIME ZONE 'America/Argentina/Buenos_Aires') < (NOW() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date`
        )
      );

    if (staleOrders.length > 0) {
      const staleIds = staleOrders.map(o => o.id);
      await db.update(restaurantOrders)
        .set({ status: "closed" as any })
        .where(inArray(restaurantOrders.id, staleIds));

      // Liberar mesas cuyo único pedido activo era el stale
      const staleTableIds = [...new Set(staleOrders.filter(o => o.tableId).map(o => o.tableId!))];
      for (const tableId of staleTableIds) {
        const remaining = await db.select({ id: restaurantOrders.id })
          .from(restaurantOrders)
          .where(
            and(
              eq(restaurantOrders.tableId, tableId),
              not(inArray(restaurantOrders.status, ["closed", "cancelled"]))
            )
          )
          .limit(1);
        if (remaining.length === 0) {
          await db.update(restaurantTables)
            .set({ status: "available" as any })
            .where(eq(restaurantTables.id, tableId));
        }
      }
      console.log(`[closeStaleOrders] Cerradas ${staleOrders.length} órdenes viejas, ${staleTableIds.length} mesas liberadas.`);
    }

    // 2. Reparar mesas "occupied" que NO tienen ninguna orden activa (dejadas por bug anterior).
    //    Esto es idempotente y safe — solo libera mesas genuinamente huérfanas.
    const occupiedTables = await db.select({ id: restaurantTables.id })
      .from(restaurantTables)
      .where(eq(restaurantTables.status, "occupied" as any));

    let repairedCount = 0;
    for (const table of occupiedTables) {
      const activeOrder = await db.select({ id: restaurantOrders.id })
        .from(restaurantOrders)
        .where(
          and(
            eq(restaurantOrders.tableId, table.id),
            not(inArray(restaurantOrders.status, ["closed", "cancelled"]))
          )
        )
        .limit(1);
      if (activeOrder.length === 0) {
        await db.update(restaurantTables)
          .set({ status: "available" as any })
          .where(eq(restaurantTables.id, table.id));
        repairedCount++;
      }
    }
    if (repairedCount > 0) {
      console.log(`[closeStaleOrders] Reparadas ${repairedCount} mesas "occupied" sin orden activa.`);
    }

    return staleOrders.length;
  }

  // Single round-trip: correlated subquery aggregates order items (with menu item details)
  // as a JSON array; table + table area, direct area, and guest are resolved via LEFT JOINs.
  private async enrichRestaurantOrder(order: RestaurantOrder): Promise<RestaurantOrderWithDetails> {
    const result = await db.execute(sql`
      SELECT
        (
          SELECT COALESCE(json_agg(jsonb_build_object(
            'id',         oi.id,
            'orderId',    oi.order_id,
            'menuItemId', oi.menu_item_id,
            'quantity',   oi.quantity,
            'unitPrice',  oi.unit_price,
            'subtotal',   oi.subtotal,
            'status',     oi.status,
            'course',     oi.course,
            'notes',      oi.notes,
            'sentAt',     oi.sent_at,
            'paid',       oi.paid,
            'menuItem', jsonb_build_object(
              'id',              mi.id,
              'categoryId',      mi.category_id,
              'name',            mi.name,
              'description',     mi.description,
              'price',           mi.price,
              'preparationTime', mi.preparation_time,
              'isAvailable',     mi.is_available,
              'isActive',        mi.is_active,
              'isEditable',      mi.is_editable,
              'allergens',       mi.allergens,
              'displayOrder',    mi.display_order,
              'defaultCourse',   mi.default_course,
              'inventoryItemId', mi.inventory_item_id
            )
          )), '[]'::json)
          FROM order_items oi
          JOIN menu_items mi ON mi.id = oi.menu_item_id
          WHERE oi.order_id = ${order.id}
        ) AS items,
        CASE WHEN rt.id IS NOT NULL
          THEN jsonb_build_object(
            'id',                 rt.id,
            'tableNumber',        rt.table_number,
            'areaId',             rt.area_id,
            'capacity',           rt.capacity,
            'shape',              rt.shape,
            'status',             rt.status,
            'positionX',          rt.position_x,
            'positionY',          rt.position_y,
            'hasWindow',          rt.has_window,
            'isActive',           rt.is_active,
            'eventClientName',    rt.event_client_name,
            'eventClientPhone',   rt.event_client_phone,
            'eventClientEmail',   rt.event_client_email,
            'eventSeats',         rt.event_seats,
            'eventNotes',         rt.event_notes,
            'eventAdvanceAmount', rt.event_advance_amount,
            'eventAdvanceMethod', rt.event_advance_method,
            'eventAdvanceDate',   rt.event_advance_date,
            'area', jsonb_build_object(
              'id',        ta.id,
              'name',      ta.name,
              'areaType',  ta.area_type,
              'capacity',  ta.capacity,
              'hasTables', ta.has_tables,
              'isActive',  ta.is_active,
              'notes',     ta.notes
            )
          )
          ELSE NULL
        END AS "table",
        CASE
          WHEN oa.id IS NOT NULL THEN jsonb_build_object(
            'id',        oa.id,
            'name',      oa.name,
            'areaType',  oa.area_type,
            'capacity',  oa.capacity,
            'hasTables', oa.has_tables,
            'isActive',  oa.is_active,
            'notes',     oa.notes
          )
          WHEN ta.id IS NOT NULL THEN jsonb_build_object(
            'id',        ta.id,
            'name',      ta.name,
            'areaType',  ta.area_type,
            'capacity',  ta.capacity,
            'hasTables', ta.has_tables,
            'isActive',  ta.is_active,
            'notes',     ta.notes
          )
          ELSE NULL
        END AS area,
        CASE WHEN g.id IS NOT NULL
          THEN jsonb_build_object(
            'id',                          g.id,
            'codigo',                      g.codigo,
            'firstName',                   g.first_name,
            'lastName',                    g.last_name,
            'email',                       g.email,
            'phone',                       g.phone,
            'documentType',                g.document_type,
            'documentNumber',              g.document_number,
            'nationality',                 g.nationality,
            'direccion',                   g.direccion,
            'localidad',                   g.localidad,
            'codigoPostal',                g.codigo_postal,
            'fechaNacimiento',             g.fecha_nacimiento,
            'sexo',                        g.sexo,
            'segment',                     g.segment,
            'cuilCuit',                    g.cuil_cuit,
            'companyId',                   g.company_id,
            'agencyId',                    g.agency_id,
            'fechaAlta',                   g.fecha_alta,
            'vehiculoPatente',             g.vehiculo_patente,
            'vehiculoMarca',               g.vehiculo_marca,
            'vehiculoModelo',              g.vehiculo_modelo,
            'vehiculoColor',               g.vehiculo_color,
            'active',                      g.active,
            'vatCondition',                g.vat_condition,
            'provincia',                   g.provincia,
            'estadoCivil',                 g.estado_civil,
            'procedencia',                 g.procedencia,
            'nationalityCode',             g.nationality_code,
            'fechaIngresoArgentina',       g.fecha_ingreso_argentina,
            'fechaSalidaArgentina',        g.fecha_salida_argentina,
            'esEmpresaGrande',             g.es_empresa_grande,
            'montoBaseFce',                g.monto_base_fce,
            'tipoPersona',                 g.tipo_persona,
            'condicionVentaPredeterminada',g.condicion_venta_predeterminada
          )
          ELSE NULL
        END AS guest
      FROM restaurant_orders ro
      LEFT JOIN restaurant_tables rt ON rt.id = ro.table_id
      LEFT JOIN restaurant_areas  ta ON ta.id = rt.area_id
      LEFT JOIN restaurant_areas  oa ON oa.id = ro.area_id
      LEFT JOIN guests             g  ON g.id  = ro.guest_id
      WHERE ro.id = ${order.id}
    `);
    const row = result.rows[0] as any;
    return {
      ...order,
      items:  (row?.items  as any[]) ?? [],
      table:  (row?.table  as any)   ?? undefined,
      area:   (row?.area   as any)   ?? undefined,
      guest:  (row?.guest  as any)   ?? undefined,
    };
  }

  // Bulk enrichment — a single SQL query that aggregates all orders with their items,
  // tables, areas and guests at once using json_agg + GROUP BY, regardless of order count.
  private async enrichRestaurantOrdersBulk(orders: RestaurantOrder[]): Promise<RestaurantOrderWithDetails[]> {
    if (orders.length === 0) return [];

    const orderIds = orders.map(o => o.id);
    const idsSql = sql.join(orderIds.map(id => sql`${id}`), sql`, `);

    const result = await db.execute(sql`
      SELECT
        ro.id AS "orderId",
        COALESCE(
          json_agg(
            jsonb_build_object(
              'id',         oi.id,
              'orderId',    oi.order_id,
              'menuItemId', oi.menu_item_id,
              'quantity',   oi.quantity,
              'unitPrice',  oi.unit_price,
              'subtotal',   oi.subtotal,
              'status',     oi.status,
              'course',     oi.course,
              'notes',      oi.notes,
              'sentAt',     oi.sent_at,
              'paid',       oi.paid,
              'menuItem', jsonb_build_object(
                'id',              mi.id,
                'categoryId',      mi.category_id,
                'name',            mi.name,
                'description',     mi.description,
                'price',           mi.price,
                'preparationTime', mi.preparation_time,
                'isAvailable',     mi.is_available,
                'isActive',        mi.is_active,
                'isEditable',      mi.is_editable,
                'allergens',       mi.allergens,
                'displayOrder',    mi.display_order,
                'defaultCourse',   mi.default_course,
                'inventoryItemId', mi.inventory_item_id
              )
            ) ORDER BY oi.id
          ) FILTER (WHERE oi.id IS NOT NULL),
          '[]'::json
        ) AS items,
        -- MAX(jsonb) no existe en PostgreSQL; se castea a text para el agregado y se vuelve a jsonb.
        -- Cada orden tiene como máximo 1 mesa, 1 área y 1 huésped, así que MAX sobre text es correcto.
        MAX(CASE WHEN rt.id IS NOT NULL THEN jsonb_build_object(
          'id',                 rt.id,
          'tableNumber',        rt.table_number,
          'areaId',             rt.area_id,
          'capacity',           rt.capacity,
          'shape',              rt.shape,
          'status',             rt.status,
          'positionX',          rt.position_x,
          'positionY',          rt.position_y,
          'hasWindow',          rt.has_window,
          'isActive',           rt.is_active,
          'eventClientName',    rt.event_client_name,
          'eventClientPhone',   rt.event_client_phone,
          'eventClientEmail',   rt.event_client_email,
          'eventSeats',         rt.event_seats,
          'eventNotes',         rt.event_notes,
          'eventAdvanceAmount', rt.event_advance_amount,
          'eventAdvanceMethod', rt.event_advance_method,
          'eventAdvanceDate',   rt.event_advance_date,
          'area', jsonb_build_object(
            'id',        ta.id,
            'name',      ta.name,
            'areaType',  ta.area_type,
            'capacity',  ta.capacity,
            'hasTables', ta.has_tables,
            'isActive',  ta.is_active,
            'notes',     ta.notes
          )
        )::text END)::jsonb AS "table",
        MAX(CASE
          WHEN oa.id IS NOT NULL THEN jsonb_build_object(
            'id',        oa.id,
            'name',      oa.name,
            'areaType',  oa.area_type,
            'capacity',  oa.capacity,
            'hasTables', oa.has_tables,
            'isActive',  oa.is_active,
            'notes',     oa.notes
          )::text
          WHEN ta.id IS NOT NULL THEN jsonb_build_object(
            'id',        ta.id,
            'name',      ta.name,
            'areaType',  ta.area_type,
            'capacity',  ta.capacity,
            'hasTables', ta.has_tables,
            'isActive',  ta.is_active,
            'notes',     ta.notes
          )::text
          ELSE NULL
        END)::jsonb AS area,
        MAX(CASE WHEN g.id IS NOT NULL THEN jsonb_build_object(
          'id',                          g.id,
          'codigo',                      g.codigo,
          'firstName',                   g.first_name,
          'lastName',                    g.last_name,
          'email',                       g.email,
          'phone',                       g.phone,
          'documentType',                g.document_type,
          'documentNumber',              g.document_number,
          'nationality',                 g.nationality,
          'direccion',                   g.direccion,
          'localidad',                   g.localidad,
          'codigoPostal',                g.codigo_postal,
          'fechaNacimiento',             g.fecha_nacimiento,
          'sexo',                        g.sexo,
          'segment',                     g.segment,
          'cuilCuit',                    g.cuil_cuit,
          'companyId',                   g.company_id,
          'agencyId',                    g.agency_id,
          'fechaAlta',                   g.fecha_alta,
          'vehiculoPatente',             g.vehiculo_patente,
          'vehiculoMarca',               g.vehiculo_marca,
          'vehiculoModelo',              g.vehiculo_modelo,
          'vehiculoColor',               g.vehiculo_color,
          'active',                      g.active,
          'vatCondition',                g.vat_condition,
          'provincia',                   g.provincia,
          'estadoCivil',                 g.estado_civil,
          'procedencia',                 g.procedencia,
          'nationalityCode',             g.nationality_code,
          'fechaIngresoArgentina',       g.fecha_ingreso_argentina,
          'fechaSalidaArgentina',        g.fecha_salida_argentina,
          'esEmpresaGrande',             g.es_empresa_grande,
          'montoBaseFce',                g.monto_base_fce,
          'tipoPersona',                 g.tipo_persona,
          'condicionVentaPredeterminada',g.condicion_venta_predeterminada
        )::text END)::jsonb AS guest
      FROM restaurant_orders ro
      LEFT JOIN restaurant_tables rt ON rt.id = ro.table_id
      LEFT JOIN restaurant_areas  ta ON ta.id = rt.area_id
      LEFT JOIN restaurant_areas  oa ON oa.id = ro.area_id
      LEFT JOIN guests             g  ON g.id  = ro.guest_id
      LEFT JOIN order_items        oi ON oi.order_id = ro.id
      LEFT JOIN menu_items         mi ON mi.id = oi.menu_item_id
      WHERE ro.id IN (${idsSql})
      GROUP BY ro.id
    `);

    const rowMap = new Map((result.rows as any[]).map(r => [r.orderId, r]));

    return orders.map(order => {
      const row = rowMap.get(order.id) as any;
      return {
        ...order,
        items:  (row?.items  as any[]) ?? [],
        table:  (row?.table  as any)   ?? undefined,
        area:   (row?.area   as any)   ?? undefined,
        guest:  (row?.guest  as any)   ?? undefined,
      };
    });
  }

  async getRestaurantOrders(status?: OrderStatus, from?: string, to?: string): Promise<RestaurantOrderWithDetails[]> {
    const conditions = [];
    if (status) {
      conditions.push(eq(restaurantOrders.status, status));
    } else if (!from && !to) {
      // Sin filtros explícitos: solo pedidos activos de HOY (Argentina).
      // Usa SQL nativo para evitar problemas de timezone entre Node y PostgreSQL.
      conditions.push(not(inArray(restaurantOrders.status, ["closed", "cancelled"])));
      conditions.push(
        sql`DATE(${restaurantOrders.openedAt} AT TIME ZONE 'America/Argentina/Buenos_Aires') >= (NOW() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date`
      );
    }
    if (from) conditions.push(gte(restaurantOrders.openedAt, new Date(from)));
    if (to) conditions.push(lte(restaurantOrders.openedAt, new Date(to)));

    let orderList: RestaurantOrder[];
    if (conditions.length > 0) {
      orderList = await db.select().from(restaurantOrders).where(and(...conditions));
    } else {
      orderList = await db.select().from(restaurantOrders);
    }

    let enriched: RestaurantOrderWithDetails[];
    try {
      enriched = await this.enrichRestaurantOrdersBulk(orderList);
    } catch (enrichErr: any) {
      // Si el enriquecimiento falla (p.ej. columnas aún en migración), devolvemos
      // los pedidos básicos sin items/table/area/guest para que el endpoint NUNCA haga 500.
      console.warn("[getRestaurantOrders] enrichment failed, returning basic orders:", enrichErr?.message);
      enriched = orderList.map(o => ({ ...o, items: [], table: undefined, area: undefined, guest: undefined }));
    }
    return enriched.sort((a, b) => new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime());
  }

  async getRestaurantOrder(id: string): Promise<RestaurantOrderWithDetails | undefined> {
    const [order] = await db.select().from(restaurantOrders).where(eq(restaurantOrders.id, id));
    if (!order) return undefined;
    try {
      return await this.enrichRestaurantOrder(order);
    } catch (e: any) {
      console.warn("[getRestaurantOrder] enrichment failed:", e?.message);
      return { ...order, items: [], table: undefined, area: undefined, guest: undefined };
    }
  }

  async getOrdersByTable(tableId: string): Promise<RestaurantOrder[]> {
    return db.select().from(restaurantOrders).where(eq(restaurantOrders.tableId, tableId));
  }

  async createRestaurantOrder(order: InsertRestaurantOrder): Promise<RestaurantOrder> {
    const [created] = await db.insert(restaurantOrders).values(order as any).returning();
    return created;
  }

  async updateRestaurantOrder(id: string, order: Partial<InsertRestaurantOrder>): Promise<RestaurantOrder | undefined> {
    const [updated] = await db.update(restaurantOrders).set(order as any).where(eq(restaurantOrders.id, id)).returning();
    return updated;
  }

  async deleteRestaurantOrder(id: string): Promise<boolean> {
    const result = await db.delete(restaurantOrders).where(eq(restaurantOrders.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  generateOrderNumber(): string {
    const today = new Date();
    const dateStr = `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, "0")}${String(today.getDate()).padStart(2, "0")}`;
    const random = Math.floor(Math.random() * 10000);
    return `ORD-${dateStr}-${random}`;
  }

  async getOrderItems(orderId: string): Promise<OrderItem[]> {
    return db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(item: InsertOrderItem): Promise<OrderItem> {
    const [created] = await db.insert(orderItems).values(item as any).returning();
    return created;
  }

  async updateOrderItem(id: string, item: Partial<InsertOrderItem>): Promise<OrderItem | undefined> {
    const [updated] = await db.update(orderItems).set(item as any).where(eq(orderItems.id, id)).returning();
    return updated;
  }

  async deleteOrderItem(id: string): Promise<boolean> {
    const result = await db.delete(orderItems).where(eq(orderItems.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async moveOrderItems(itemIds: string[], targetOrderId: string): Promise<void> {
    if (itemIds.length === 0) return;
    await db.update(orderItems).set({ orderId: targetOrderId }).where(inArray(orderItems.id, itemIds));
  }

  private async _enrichReservationsWithAdvances(res: any[]): Promise<any[]> {
    if (res.length === 0) return res;
    const ids = res.map(r => r.id);
    const advances = await db.select().from(restaurantReservationAdvances)
      .where(inArray(restaurantReservationAdvances.reservationId, ids));
    const totals = new Map<string, number>();
    for (const a of advances) {
      totals.set(a.reservationId, (totals.get(a.reservationId) || 0) + parseFloat(String(a.amount || "0")));
    }
    return res.map(r => ({
      ...r,
      advanceAmount: totals.has(r.id) ? String(totals.get(r.id)) : (r.advanceAmount ?? "0"),
    }));
  }

  async getTableReservations(): Promise<TableReservationWithTable[]> {
    const res = await db.select().from(tableReservations);
    const tables = await db.select().from(restaurantTables);
    const tablesMap = new Map(tables.map(t => [t.id, t]));
    const enriched = await this._enrichReservationsWithAdvances(res);
    return enriched.map(r => ({ ...r, table: r.tableId ? (tablesMap.get(r.tableId) ?? null) : null }));
  }

  async getTableReservation(id: string): Promise<TableReservationWithTable | undefined> {
    const [res] = await db.select().from(tableReservations).where(eq(tableReservations.id, id));
    if (!res) return undefined;
    let table = null;
    if (res.tableId) {
      const [t] = await db.select().from(restaurantTables).where(eq(restaurantTables.id, res.tableId));
      table = t ?? null;
    }
    const [enriched] = await this._enrichReservationsWithAdvances([res]);
    return { ...enriched, table };
  }

  async getTableReservationsByDate(date: string): Promise<TableReservationWithTable[]> {
    const res = await db.select().from(tableReservations).where(eq(tableReservations.reservationDate, date));
    const tables = await db.select().from(restaurantTables);
    const tablesMap = new Map(tables.map(t => [t.id, t]));
    const enriched = await this._enrichReservationsWithAdvances(res);
    return enriched.map(r => ({ ...r, table: r.tableId ? (tablesMap.get(r.tableId) ?? null) : null }));
  }

  async getTableReservationsByTable(tableId: string): Promise<TableReservation[]> {
    return db.select().from(tableReservations).where(eq(tableReservations.tableId, tableId));
  }

  async createTableReservation(reservation: InsertTableReservation): Promise<TableReservation> {
    const [created] = await db.insert(tableReservations).values(reservation as any).returning();
    return created;
  }

  async updateTableReservation(id: string, reservation: Partial<InsertTableReservation>): Promise<TableReservation | undefined> {
    const [updated] = await db.update(tableReservations).set(reservation as any).where(eq(tableReservations.id, id)).returning();
    return updated;
  }

  async deleteTableReservation(id: string): Promise<boolean> {
    const result = await db.delete(tableReservations).where(eq(tableReservations.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Reservation Advances
  async getReservationAdvances(reservationId: string): Promise<RestaurantReservationAdvance[]> {
    return db.select().from(restaurantReservationAdvances)
      .where(eq(restaurantReservationAdvances.reservationId, reservationId))
      .orderBy(restaurantReservationAdvances.createdAt);
  }

  async getReservationAdvancesByTable(tableId: string, date: string): Promise<RestaurantReservationAdvance[]> {
    const reservs = await db.select().from(tableReservations).where(
      and(eq(tableReservations.tableId, tableId), eq(tableReservations.reservationDate, date))
    );
    if (reservs.length === 0) return [];
    const ids = reservs.map(r => r.id);
    return db.select().from(restaurantReservationAdvances).where(
      inArray(restaurantReservationAdvances.reservationId, ids)
    );
  }

  async createReservationAdvance(data: InsertRestaurantReservationAdvance): Promise<RestaurantReservationAdvance> {
    const [created] = await db.insert(restaurantReservationAdvances).values(data as any).returning();
    // Recalculate total advance amount on the reservation
    if (data.reservationId) {
      const all = await db.select().from(restaurantReservationAdvances)
        .where(eq(restaurantReservationAdvances.reservationId, data.reservationId));
      const total = all.reduce((sum, a) => sum + parseFloat(String(a.amount || "0")), 0);
      await db.update(tableReservations)
        .set({ advanceAmount: String(total) })
        .where(eq(tableReservations.id, data.reservationId));
    }
    return created;
  }

  async deleteReservationAdvance(id: string): Promise<boolean> {
    // Fetch the advance first to know which reservation to recalculate
    const [advance] = await db.select().from(restaurantReservationAdvances)
      .where(eq(restaurantReservationAdvances.id, id));
    const result = await db.delete(restaurantReservationAdvances).where(eq(restaurantReservationAdvances.id, id));
    // Recalculate total advance amount on the reservation
    if (advance?.reservationId) {
      const all = await db.select().from(restaurantReservationAdvances)
        .where(eq(restaurantReservationAdvances.reservationId, advance.reservationId));
      const total = all.reduce((sum, a) => sum + parseFloat(String(a.amount || "0")), 0);
      await db.update(tableReservations)
        .set({ advanceAmount: String(total) })
        .where(eq(tableReservations.id, advance.reservationId));
    }
    return (result.rowCount ?? 0) > 0;
  }

  async applyReservationAdvancesToOrder(reservationId: string, orderId: string): Promise<void> {
    await db.update(restaurantReservationAdvances)
      .set({ appliedToOrderId: orderId })
      .where(
        and(
          eq(restaurantReservationAdvances.reservationId, reservationId),
          isNull(restaurantReservationAdvances.appliedToOrderId)
        )
      );
  }

  async getRestaurantTimeSlots(): Promise<RestaurantTimeSlot[]> {
    return db.select().from(restaurantTimeSlots);
  }

  async createRestaurantTimeSlot(slot: InsertRestaurantTimeSlot): Promise<RestaurantTimeSlot> {
    const [created] = await db.insert(restaurantTimeSlots).values(slot as any).returning();
    return created;
  }

  async updateRestaurantTimeSlot(id: string, slot: Partial<InsertRestaurantTimeSlot>): Promise<RestaurantTimeSlot | undefined> {
    const [updated] = await db.update(restaurantTimeSlots).set(slot as any).where(eq(restaurantTimeSlots.id, id)).returning();
    return updated;
  }

  async deleteRestaurantTimeSlot(id: string): Promise<boolean> {
    const result = await db.delete(restaurantTimeSlots).where(eq(restaurantTimeSlots.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getRecipes(): Promise<RecipeWithIngredients[]> {
    const allRecipes = await db.select().from(recipes);
    const allIngredients = await db.select().from(recipeIngredients);
    const allMenuItemsList = await db.select().from(menuItems);
    const menuItemsMap = new Map(allMenuItemsList.map(m => [m.id, m]));

    return allRecipes.map(recipe => ({
      ...recipe,
      menuItem: recipe.menuItemId ? menuItemsMap.get(recipe.menuItemId) : undefined,
      ingredients: allIngredients.filter(i => i.recipeId === recipe.id),
    }));
  }

  async getRecipe(id: string): Promise<RecipeWithIngredients | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    if (!recipe) return undefined;
    const ingredients = await db.select().from(recipeIngredients).where(eq(recipeIngredients.recipeId, id));
    const menuItem = recipe.menuItemId
      ? (await db.select().from(menuItems).where(eq(menuItems.id, recipe.menuItemId)))[0]
      : undefined;
    return { ...recipe, menuItem, ingredients };
  }

  async getRecipeByMenuItem(menuItemId: string): Promise<RecipeWithIngredients | undefined> {
    const [recipe] = await db.select().from(recipes).where(
      and(eq(recipes.menuItemId, menuItemId), eq(recipes.isBase as any, false))
    );
    if (!recipe) return undefined;
    const ingredients = await db.select().from(recipeIngredients).where(eq(recipeIngredients.recipeId, recipe.id));
    const menuItem = recipe.menuItemId
      ? (await db.select().from(menuItems).where(eq(menuItems.id, recipe.menuItemId)))[0]
      : undefined;
    return { ...recipe, menuItem, ingredients };
  }

  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const [created] = await db.insert(recipes).values(recipe as any).returning();
    return created;
  }

  async updateRecipe(id: string, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined> {
    const [updated] = await db.update(recipes).set(recipe as any).where(eq(recipes.id, id)).returning();
    return updated;
  }

  async deleteRecipe(id: string): Promise<boolean> {
    await db.delete(recipeIngredients).where(eq(recipeIngredients.recipeId, id));
    const result = await db.delete(recipes).where(eq(recipes.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getRecipeIngredients(recipeId: string): Promise<RecipeIngredient[]> {
    return db.select().from(recipeIngredients).where(eq(recipeIngredients.recipeId, recipeId));
  }

  async createRecipeIngredient(ingredient: InsertRecipeIngredient): Promise<RecipeIngredient> {
    const [created] = await db.insert(recipeIngredients).values(ingredient as any).returning();
    return created;
  }

  async updateRecipeIngredient(id: string, ingredient: Partial<InsertRecipeIngredient>): Promise<RecipeIngredient | undefined> {
    const [updated] = await db.update(recipeIngredients).set(ingredient as any).where(eq(recipeIngredients.id, id)).returning();
    return updated;
  }

  async deleteRecipeIngredient(id: string): Promise<boolean> {
    const result = await db.delete(recipeIngredients).where(eq(recipeIngredients.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getOrderSplits(orderId: string): Promise<OrderSplit[]> {
    return db.select().from(orderSplits).where(eq(orderSplits.orderId, orderId));
  }

  async createOrderSplit(split: InsertOrderSplit): Promise<OrderSplit> {
    const [created] = await db.insert(orderSplits).values(split as any).returning();
    return created;
  }

  async updateOrderSplit(id: string, split: Partial<InsertOrderSplit>): Promise<OrderSplit | undefined> {
    const [updated] = await db.update(orderSplits).set(split as any).where(eq(orderSplits.id, id)).returning();
    return updated;
  }

  async deleteOrderSplitsByOrder(orderId: string): Promise<boolean> {
    const result = await db.delete(orderSplits).where(eq(orderSplits.orderId, orderId));
    return (result.rowCount ?? 0) >= 0;
  }

  async getItemCategories(): Promise<ItemCategory[]> {
    return db.select().from(itemCategories);
  }

  async getItemCategory(id: string): Promise<ItemCategory | undefined> {
    const [cat] = await db.select().from(itemCategories).where(eq(itemCategories.id, id));
    return cat;
  }

  async createItemCategory(category: InsertItemCategory): Promise<ItemCategory> {
    const [created] = await db.insert(itemCategories).values(category as any).returning();
    return created;
  }

  async updateItemCategory(id: string, category: Partial<InsertItemCategory>): Promise<ItemCategory | undefined> {
    const [updated] = await db.update(itemCategories).set(category as any).where(eq(itemCategories.id, id)).returning();
    return updated;
  }

  async deleteItemCategory(id: string): Promise<boolean> {
    const result = await db.delete(itemCategories).where(eq(itemCategories.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getSuppliers(): Promise<Supplier[]> {
    return db.select().from(suppliers);
  }

  async getSupplier(id: string): Promise<Supplier | undefined> {
    const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    return supplier;
  }

  async createSupplier(supplier: InsertSupplier): Promise<Supplier> {
    const [created] = await db.insert(suppliers).values(supplier as any).returning();
    return created;
  }

  async updateSupplier(id: string, supplier: Partial<InsertSupplier>): Promise<Supplier | undefined> {
    const [updated] = await db.update(suppliers).set(supplier as any).where(eq(suppliers.id, id)).returning();
    return updated;
  }

  async deleteSupplier(id: string): Promise<boolean> {
    const result = await db.delete(suppliers).where(eq(suppliers.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getInventoryItems(): Promise<InventoryItemWithDetails[]> {
    const items = await db.select().from(inventoryItems);
    const cats = await db.select().from(itemCategories);
    const sups = await db.select().from(suppliers);
    const catsMap = new Map(cats.map(c => [c.id, c]));
    const supsMap = new Map(sups.map(s => [s.id, s]));
    return items.map(i => ({
      ...i,
      category: i.categoryId ? catsMap.get(i.categoryId) : undefined,
      supplier: i.supplierId ? supsMap.get(i.supplierId) : undefined,
    }));
  }

  async getInventoryItem(id: string): Promise<InventoryItemWithDetails | undefined> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    if (!item) return undefined;
    const category = item.categoryId ? (await db.select().from(itemCategories).where(eq(itemCategories.id, item.categoryId)))[0] : undefined;
    const supplier = item.supplierId ? (await db.select().from(suppliers).where(eq(suppliers.id, item.supplierId)))[0] : undefined;
    return { ...item, category, supplier };
  }

  async getInventoryItemsBelowMinStock(): Promise<InventoryItem[]> {
    return db.select().from(inventoryItems).where(
      sql`${inventoryItems.currentStock} < ${inventoryItems.minStock}`
    );
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const [created] = await db.insert(inventoryItems).values(item as any).returning();
    return created;
  }

  async updateInventoryItem(id: string, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const [updated] = await db.update(inventoryItems).set(item as any).where(eq(inventoryItems.id, id)).returning();
    return updated;
  }

  async inventoryItemHasMovement(id: string): Promise<boolean> {
    const [mv] = await db.select({ id: stockMovements.id }).from(stockMovements).where(eq(stockMovements.itemId, id)).limit(1);
    if (mv) return true;
    const [ing] = await db.select({ id: recipeIngredients.id }).from(recipeIngredients).where(eq(recipeIngredients.inventoryItemId, id)).limit(1);
    if (ing) return true;
    const [ws] = await db.select({ id: warehouseStock.id }).from(warehouseStock).where(
      and(eq(warehouseStock.itemId, id), sql`${warehouseStock.currentStock} <> 0`)
    ).limit(1);
    if (ws) return true;
    const [item] = await db.select({ currentStock: inventoryItems.currentStock }).from(inventoryItems).where(eq(inventoryItems.id, id));
    return !!item && parseFloat(item.currentStock ?? "0") !== 0;
  }

  async deleteInventoryItem(id: string): Promise<{ deleted: boolean; deactivated: boolean }> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    if (!item) return { deleted: false, deactivated: false };

    const hasMovement = await this.inventoryItemHasMovement(id);
    if (hasMovement) {
      await db.update(inventoryItems).set({ isActive: "false" } as any).where(eq(inventoryItems.id, id));
      return { deleted: false, deactivated: true };
    }

    const result = await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
    return { deleted: (result.rowCount ?? 0) > 0, deactivated: false };
  }

  async getStockMovements(itemId?: string): Promise<StockMovementWithItem[]> {
    let movements: StockMovement[];
    if (itemId) {
      movements = await db.select().from(stockMovements).where(eq(stockMovements.itemId, itemId)).orderBy(desc(stockMovements.createdAt));
    } else {
      movements = await db.select().from(stockMovements).orderBy(desc(stockMovements.createdAt));
    }
    const items = await db.select().from(inventoryItems);
    const itemsMap = new Map(items.map(i => [i.id, i]));
    return movements.map(m => ({ ...m, item: itemsMap.get(m.itemId)! }));
  }

  async createStockMovement(movement: InsertStockMovement): Promise<StockMovement> {
    const [created] = await db.insert(stockMovements).values(movement as any).returning();
    return created;
  }

  async deductStockFromOrder(orderId: string, orderItems: Array<{ menuItemId: string; quantity: number }>) {
    const deducted: Array<{ itemName: string; quantity: number; unit: string }> = [];
    const warnings: Array<{ itemName: string; required: number; available: number }> = [];
    const skipped: Array<{ ingredientName: string; reason: string }> = [];

    // Recursive helper: deduct raw materials for a list of ingredients at a given multiplier.
    // Supports sub-recipes (elaboraciones): when an ingredient has subRecipeId, its ingredients
    // are expanded recursively in proportion to quantity/productionYield.
    const deductIngredients = async (
      ingredients: RecipeIngredient[],
      multiplier: number,
      depth: number = 0
    ): Promise<void> => {
      if (depth > 6) return; // safety guard against infinite recursion

      for (const ingredient of ingredients) {
        const subRecipeId = (ingredient as any).subRecipeId as string | null;

        if (subRecipeId) {
          // ── Sub-recipe / elaboración ─────────────────────────────────────
          const subRecipe = await this.getRecipe(subRecipeId);
          if (!subRecipe) {
            skipped.push({ ingredientName: ingredient.ingredientName, reason: "Sub-receta no encontrada" });
            continue;
          }
          const subYield = parseFloat(String((subRecipe as any).productionYield || "0"));
          if (subYield <= 0) {
            skipped.push({ ingredientName: ingredient.ingredientName, reason: "Sub-receta sin rendimiento (productionYield) definido" });
            continue;
          }
          const merma = ingredient.merma ? parseFloat(String(ingredient.merma)) : 0;
          const grossQty = merma > 0
            ? parseFloat(String(ingredient.quantity)) / (1 - merma / 100)
            : parseFloat(String(ingredient.quantity));
          // How much of the sub-recipe batch is needed for this usage
          const ratio = (grossQty / subYield) * multiplier;
          await deductIngredients(subRecipe.ingredients, ratio, depth + 1);
          continue;
        }

        // ── Raw material from inventory ───────────────────────────────────
        if (!ingredient.inventoryItemId) {
          skipped.push({ ingredientName: ingredient.ingredientName, reason: "Sin vínculo con inventario" });
          continue;
        }

        const [invItem] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, ingredient.inventoryItemId));
        if (!invItem) {
          skipped.push({ ingredientName: ingredient.ingredientName, reason: "Ítem de inventario no encontrado" });
          continue;
        }

        // Si hay merma, la cantidad bruta real = neta / (1 - merma/100)
        const merma = ingredient.merma ? parseFloat(String(ingredient.merma)) : 0;
        const grossQty = merma > 0
          ? parseFloat(String(ingredient.quantity)) / (1 - merma / 100)
          : parseFloat(String(ingredient.quantity));
        const totalToDeduct = grossQty * multiplier;
        const currentStock = parseFloat(String(invItem.currentStock ?? 0));

        if (currentStock < totalToDeduct) {
          warnings.push({ itemName: invItem.name, required: totalToDeduct, available: currentStock });
        }

        const actualDeduct = Math.min(totalToDeduct, currentStock);
        if (actualDeduct <= 0) continue;

        const newStock = Math.max(0, currentStock - actualDeduct);

        await db.insert(stockMovements).values({
          id: randomUUID(),
          itemId: ingredient.inventoryItemId,
          movementType: "consumo",
          quantity: String(actualDeduct),
          previousStock: String(currentStock),
          newStock: String(newStock),
          notes: `Consumo automático — Orden ${orderId}`,
          sourceType: "restaurant_order",
          sourceId: orderId,
          createdAt: new Date(),
        } as any);

        await db.update(inventoryItems)
          .set({ currentStock: String(newStock) as any })
          .where(eq(inventoryItems.id, ingredient.inventoryItemId));

        deducted.push({ itemName: invItem.name, quantity: actualDeduct, unit: invItem.unit });
      }
    };

    for (const orderItem of orderItems) {
      const recipe = await this.getRecipeByMenuItem(orderItem.menuItemId);
      if (!recipe || recipe.ingredients.length === 0) {
        skipped.push({ ingredientName: orderItem.menuItemId, reason: "Sin receta configurada" });
        continue;
      }
      await deductIngredients(recipe.ingredients, orderItem.quantity);
    }

    return { deducted, warnings, skipped };
  }

  async getSpaCabins(): Promise<SpaCabin[]> {
    return db.select().from(spaCabins);
  }

  async getSpaCabin(id: string): Promise<SpaCabin | undefined> {
    const [cabin] = await db.select().from(spaCabins).where(eq(spaCabins.id, id));
    return cabin;
  }

  async createSpaCabin(cabin: InsertSpaCabin): Promise<SpaCabin> {
    const [created] = await db.insert(spaCabins).values(cabin as any).returning();
    return created;
  }

  async updateSpaCabin(id: string, cabin: Partial<InsertSpaCabin>): Promise<SpaCabin | undefined> {
    const [updated] = await db.update(spaCabins).set(cabin as any).where(eq(spaCabins.id, id)).returning();
    return updated;
  }

  async deleteSpaCabin(id: string): Promise<boolean> {
    const result = await db.delete(spaCabins).where(eq(spaCabins.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getSpaTreatmentCategories(): Promise<SpaTreatmentCategory[]> {
    return db.select().from(spaTreatmentCategories);
  }

  async getSpaTreatmentCategory(id: string): Promise<SpaTreatmentCategory | undefined> {
    const [cat] = await db.select().from(spaTreatmentCategories).where(eq(spaTreatmentCategories.id, id));
    return cat;
  }

  async createSpaTreatmentCategory(category: InsertSpaTreatmentCategory): Promise<SpaTreatmentCategory> {
    const [created] = await db.insert(spaTreatmentCategories).values(category as any).returning();
    return created;
  }

  async updateSpaTreatmentCategory(id: string, category: Partial<InsertSpaTreatmentCategory>): Promise<SpaTreatmentCategory | undefined> {
    const [updated] = await db.update(spaTreatmentCategories).set(category as any).where(eq(spaTreatmentCategories.id, id)).returning();
    return updated;
  }

  async deleteSpaTreatmentCategory(id: string): Promise<boolean> {
    const result = await db.delete(spaTreatmentCategories).where(eq(spaTreatmentCategories.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getSpaTreatments(): Promise<SpaTreatment[]> {
    return db.select().from(spaTreatments).where(eq(spaTreatments.isActive, "true"));
  }

  async getSpaTreatment(id: string): Promise<SpaTreatment | undefined> {
    const [treatment] = await db.select().from(spaTreatments).where(eq(spaTreatments.id, id));
    return treatment;
  }

  async getSpaTreatmentsByCategory(categoryId: string): Promise<SpaTreatment[]> {
    return db.select().from(spaTreatments).where(
      and(eq(spaTreatments.categoryId, categoryId), eq(spaTreatments.isActive, "true"))
    );
  }

  async createSpaTreatment(treatment: InsertSpaTreatment): Promise<SpaTreatment> {
    const [created] = await db.insert(spaTreatments).values(treatment as any).returning();
    return created;
  }

  async updateSpaTreatment(id: string, treatment: Partial<InsertSpaTreatment>): Promise<SpaTreatment | undefined> {
    const [updated] = await db.update(spaTreatments).set(treatment as any).where(eq(spaTreatments.id, id)).returning();
    return updated;
  }

  async deleteSpaTreatment(id: string): Promise<boolean> {
    const result = await db.delete(spaTreatments).where(eq(spaTreatments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  private async enrichSpaAppointmentsBulk(appointments: SpaAppointment[]): Promise<SpaAppointmentWithDetails[]> {
    if (appointments.length === 0) return [];

    const apptIds = appointments.map(a => a.id);
    const idsSql = sql.join(apptIds.map(id => sql`${id}`), sql`, `);

    const result = await db.execute(sql`
      SELECT
        sa.id AS "appointmentId",
        -- MAX(jsonb) no existe en PostgreSQL; castear a text para el agregado y volver a jsonb.
        MAX(CASE WHEN sc.id IS NOT NULL THEN jsonb_build_object(
          'id',          sc.id,
          'name',        sc.name,
          'description', sc.description,
          'isActive',    sc.is_active
        )::text END)::jsonb AS cabin,
        MAX(CASE WHEN st.id IS NOT NULL THEN jsonb_build_object(
          'id',              st.id,
          'categoryId',      st.category_id,
          'name',            st.name,
          'description',     st.description,
          'durationMinutes', st.duration_minutes,
          'price',           st.price,
          'isActive',        st.is_active
        )::text END)::jsonb AS treatment
      FROM spa_appointments sa
      LEFT JOIN spa_cabins     sc ON sc.id = sa.cabin_id
      LEFT JOIN spa_treatments st ON st.id = sa.treatment_id
      WHERE sa.id IN (${idsSql})
      GROUP BY sa.id
    `);

    const rowMap = new Map((result.rows as any[]).map(r => [r.appointmentId, r]));

    return appointments.map(a => {
      const row = rowMap.get(a.id) as any;
      return {
        ...a,
        cabin:     (row?.cabin     as any) ?? undefined,
        treatment: (row?.treatment as any) ?? undefined,
      };
    });
  }

  async getSpaAppointments(date?: string): Promise<SpaAppointmentWithDetails[]> {
    let appointments: SpaAppointment[];
    if (date) {
      appointments = await db.select().from(spaAppointments).where(eq(spaAppointments.appointmentDate, date));
    } else {
      appointments = await db.select().from(spaAppointments);
    }

    const enriched = await this.enrichSpaAppointmentsBulk(appointments);
    return enriched.sort((a, b) => a.startTime.localeCompare(b.startTime));
  }

  async getSpaAppointment(id: string): Promise<SpaAppointmentWithDetails | undefined> {
    const [appt] = await db.select().from(spaAppointments).where(eq(spaAppointments.id, id));
    if (!appt) return undefined;
    const [cabin] = await db.select().from(spaCabins).where(eq(spaCabins.id, appt.cabinId));
    const [treatment] = await db.select().from(spaTreatments).where(eq(spaTreatments.id, appt.treatmentId));
    return { ...appt, cabin, treatment };
  }

  async getSpaAppointmentsByCabin(cabinId: string, date: string): Promise<SpaAppointment[]> {
    return db.select().from(spaAppointments).where(
      and(eq(spaAppointments.cabinId, cabinId), eq(spaAppointments.appointmentDate, date))
    );
  }

  async getSpaAppointmentsByDateRange(startDate: string, endDate: string): Promise<SpaAppointmentWithDetails[]> {
    const appointments = await db.select().from(spaAppointments).where(
      and(
        sql`${spaAppointments.appointmentDate} >= ${startDate}`,
        sql`${spaAppointments.appointmentDate} <= ${endDate}`
      )
    );

    const enriched = await this.enrichSpaAppointmentsBulk(appointments);
    return enriched.sort((a, b) => {
      if (a.appointmentDate !== b.appointmentDate) {
        return a.appointmentDate.localeCompare(b.appointmentDate);
      }
      return a.startTime.localeCompare(b.startTime);
    });
  }

  async createSpaAppointment(appointment: InsertSpaAppointment): Promise<SpaAppointment> {
    const [created] = await db.insert(spaAppointments).values(appointment as any).returning();
    return created;
  }

  async updateSpaAppointment(id: string, appointment: Partial<InsertSpaAppointment>): Promise<SpaAppointment | undefined> {
    const [updated] = await db.update(spaAppointments).set(appointment as any).where(eq(spaAppointments.id, id)).returning();
    return updated;
  }

  async deleteSpaAppointment(id: string): Promise<boolean> {
    const result = await db.delete(spaAppointments).where(eq(spaAppointments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getSpaAccounts(status?: SpaAccountStatus): Promise<SpaAccountWithItems[]> {
    const accounts = await (status
      ? db.select().from(spaAccounts).where(eq(spaAccounts.status, status))
      : db.select().from(spaAccounts));

    if (accounts.length === 0) return [];

    const accountIds = accounts.map(a => a.id);
    const appointmentIds = [...new Set(accounts.map(a => a.appointmentId).filter(Boolean))];

    // Three parallel queries instead of five sequential full-table scans
    const [allItems, allPayments, appointmentRows] = await Promise.all([
      db.select().from(spaAccountItems).where(inArray(spaAccountItems.accountId, accountIds)),
      db.select().from(spaPayments).where(inArray(spaPayments.accountId, accountIds)),
      appointmentIds.length
        ? db.select({
            id: spaAppointments.id,
            cabinId: spaAppointments.cabinId,
            treatmentId: spaAppointments.treatmentId,
            professionalId: spaAppointments.professionalId,
            guestId: spaAppointments.guestId,
            guestName: spaAppointments.guestName,
            guestLastName: spaAppointments.guestLastName,
            guestPhone: spaAppointments.guestPhone,
            guestEmail: spaAppointments.guestEmail,
            reservationId: spaAppointments.reservationId,
            appointmentDate: spaAppointments.appointmentDate,
            startTime: spaAppointments.startTime,
            endTime: spaAppointments.endTime,
            status: spaAppointments.status,
            notes: spaAppointments.notes,
            createdAt: spaAppointments.createdAt,
            cabinName: spaCabins.name,
            cabinDescription: spaCabins.description,
            cabinIsActive: spaCabins.isActive,
            treatmentCategoryId: spaTreatments.categoryId,
            treatmentName: spaTreatments.name,
            treatmentDescription: spaTreatments.description,
            treatmentDurationMinutes: spaTreatments.durationMinutes,
            treatmentPrice: spaTreatments.price,
            treatmentIsActive: spaTreatments.isActive,
          })
          .from(spaAppointments)
          .leftJoin(spaCabins, eq(spaCabins.id, spaAppointments.cabinId))
          .leftJoin(spaTreatments, eq(spaTreatments.id, spaAppointments.treatmentId))
          .where(inArray(spaAppointments.id, appointmentIds))
        : Promise.resolve([]),
    ]);

    const itemsMap = new Map<string, typeof allItems>();
    for (const item of allItems) {
      if (!itemsMap.has(item.accountId)) itemsMap.set(item.accountId, []);
      itemsMap.get(item.accountId)!.push(item);
    }
    const paymentsMap = new Map<string, typeof allPayments>();
    for (const pmt of allPayments) {
      if (!paymentsMap.has(pmt.accountId)) paymentsMap.set(pmt.accountId, []);
      paymentsMap.get(pmt.accountId)!.push(pmt);
    }
    const appointmentMap = new Map(
      appointmentRows.map(row => [
        row.id,
        {
          id: row.id,
          cabinId: row.cabinId,
          treatmentId: row.treatmentId,
          professionalId: row.professionalId,
          guestId: row.guestId,
          guestName: row.guestName,
          guestLastName: row.guestLastName,
          guestPhone: row.guestPhone,
          guestEmail: row.guestEmail,
          reservationId: row.reservationId,
          appointmentDate: row.appointmentDate,
          startTime: row.startTime,
          endTime: row.endTime,
          status: row.status,
          notes: row.notes,
          createdAt: row.createdAt,
          cabin: {
            id: row.cabinId,
            name: row.cabinName!,
            description: row.cabinDescription ?? null,
            isActive: row.cabinIsActive ?? null,
          } as SpaCabin,
          treatment: {
            id: row.treatmentId,
            categoryId: row.treatmentCategoryId ?? null,
            name: row.treatmentName!,
            description: row.treatmentDescription ?? null,
            durationMinutes: row.treatmentDurationMinutes!,
            price: row.treatmentPrice!,
            isActive: row.treatmentIsActive ?? null,
          } as SpaTreatment,
        } as SpaAppointmentWithDetails,
      ])
    );

    return accounts.map(account => ({
      ...account,
      items: itemsMap.get(account.id) ?? [],
      payments: paymentsMap.get(account.id) ?? [],
      appointment: appointmentMap.get(account.appointmentId),
    }));
  }

  async getSpaAccount(id: string): Promise<SpaAccountWithItems | undefined> {
    const [account] = await db.select().from(spaAccounts).where(eq(spaAccounts.id, id));
    if (!account) return undefined;
    return this.enrichSpaAccount(account);
  }

  private async enrichSpaAccount(account: SpaAccount): Promise<SpaAccountWithItems> {
    // Single round-trip: correlated subqueries aggregate items and payments as JSON arrays;
    // appointment with cabin and treatment details resolved via LEFT JOINs.
    const result = await db.execute(sql`
      SELECT
        (
          SELECT COALESCE(json_agg(jsonb_build_object(
            'id',          i.id,
            'accountId',   i.account_id,
            'description', i.description,
            'quantity',    i.quantity,
            'unitPrice',   i.unit_price,
            'subtotal',    i.subtotal,
            'itemType',    i.item_type,
            'notes',       i.notes,
            'createdAt',   i.created_at
          )), '[]'::json)
          FROM spa_account_items i
          WHERE i.account_id = ${account.id}
        ) AS items,
        (
          SELECT COALESCE(json_agg(jsonb_build_object(
            'id',              p.id,
            'accountId',       p.account_id,
            'amount',          p.amount,
            'method',          p.method,
            'isAdvance',       p.is_advance,
            'appointmentId',   p.appointment_id,
            'reservationId',   p.reservation_id,
            'notes',           p.notes,
            'createdAt',       p.created_at,
            'status',          p.status,
            'motivoAnulacion', p.motivo_anulacion,
            'anuladoAt',       p.anulado_at
          )), '[]'::json)
          FROM spa_payments p
          WHERE p.account_id = ${account.id}
        ) AS payments,
        CASE WHEN appt.id IS NOT NULL
          THEN jsonb_build_object(
            'id',              appt.id,
            'cabinId',         appt.cabin_id,
            'treatmentId',     appt.treatment_id,
            'professionalId',  appt.professional_id,
            'guestId',         appt.guest_id,
            'guestName',       appt.guest_name,
            'guestLastName',   appt.guest_last_name,
            'guestPhone',      appt.guest_phone,
            'guestEmail',      appt.guest_email,
            'reservationId',   appt.reservation_id,
            'appointmentDate', appt.appointment_date,
            'startTime',       appt.start_time,
            'endTime',         appt.end_time,
            'status',          appt.status,
            'notes',           appt.notes,
            'createdAt',       appt.created_at,
            'cabin', jsonb_build_object(
              'id',          cab.id,
              'name',        cab.name,
              'description', cab.description,
              'isActive',    cab.is_active
            ),
            'treatment', jsonb_build_object(
              'id',              tr.id,
              'categoryId',      tr.category_id,
              'name',            tr.name,
              'description',     tr.description,
              'durationMinutes', tr.duration_minutes,
              'price',           tr.price,
              'isActive',        tr.is_active
            )
          )
          ELSE NULL
        END AS appointment
      FROM spa_accounts a
      LEFT JOIN spa_appointments appt ON appt.id = a.appointment_id
      LEFT JOIN spa_cabins cab ON cab.id = appt.cabin_id
      LEFT JOIN spa_treatments tr ON tr.id = appt.treatment_id
      WHERE a.id = ${account.id}
    `);
    const row = result.rows[0] as any;
    return {
      ...account,
      items: (row?.items as SpaAccountItem[]) ?? [],
      payments: (row?.payments as SpaPayment[]) ?? [],
      appointment: (row?.appointment as SpaAppointmentWithDetails | null) ?? undefined,
    };
  }

  async getSpaAccountByAppointment(appointmentId: string): Promise<SpaAccountWithItems | undefined> {
    const [account] = await db.select().from(spaAccounts).where(eq(spaAccounts.appointmentId, appointmentId));
    if (!account) return undefined;
    return this.enrichSpaAccount(account);
  }

  async createSpaAccount(account: InsertSpaAccount): Promise<SpaAccount> {
    const [created] = await db.insert(spaAccounts).values(account as any).returning();
    return created;
  }

  async updateSpaAccount(id: string, account: Partial<InsertSpaAccount>): Promise<SpaAccount | undefined> {
    const [updated] = await db.update(spaAccounts).set(account as any).where(eq(spaAccounts.id, id)).returning();
    return updated;
  }

  async closeSpaAccount(id: string, chargedTo: string, receiptType?: string): Promise<SpaAccount | undefined> {
    const [account] = await db.select().from(spaAccounts).where(eq(spaAccounts.id, id));
    if (!account) return undefined;

    const items = await db.select().from(spaAccountItems).where(eq(spaAccountItems.accountId, id));
    const total = items.reduce((sum, item) => sum + parseFloat(item.subtotal), 0);
    const pmts = await db.select().from(spaPayments).where(eq(spaPayments.accountId, id));
    const totalPaid = pmts.reduce((sum, p) => sum + parseFloat(p.amount), 0);

    const [updated] = await db.update(spaAccounts).set({
      status: "closed",
      subtotal: total.toFixed(2),
      total: total.toFixed(2),
      totalPaid: totalPaid.toFixed(2),
      receiptType: receiptType ?? null,
      closedAt: new Date(),
      chargedTo,
    }).where(eq(spaAccounts.id, id)).returning();

    if (chargedTo.startsWith("room:")) {
      const reservationId = chargedTo.replace("room:", "");
      const [reservation] = await db.select().from(reservations).where(eq(reservations.id, reservationId));
      if (reservation) {
        await db.insert(charges).values({
          reservationId,
          category: "spa",
          description: "Servicios SPA",
          amount: total.toFixed(2),
          date: new Date().toISOString().split("T")[0],
          createdBy: null,
        } as any);
      }
    }

    return updated;
  }

  async getSpaAccountItems(accountId: string): Promise<SpaAccountItem[]> {
    return db.select().from(spaAccountItems).where(eq(spaAccountItems.accountId, accountId));
  }

  async createSpaAccountItem(item: InsertSpaAccountItem): Promise<SpaAccountItem> {
    const [created] = await db.insert(spaAccountItems).values(item as any).returning();
    return created;
  }

  async updateSpaAccountItem(id: string, item: Partial<InsertSpaAccountItem>): Promise<SpaAccountItem | undefined> {
    const [updated] = await db.update(spaAccountItems).set(item as any).where(eq(spaAccountItems.id, id)).returning();
    return updated;
  }

  async deleteSpaAccountItem(id: string): Promise<boolean> {
    const result = await db.delete(spaAccountItems).where(eq(spaAccountItems.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getSpaPayments(accountId: string): Promise<SpaPayment[]> {
    return db.select().from(spaPayments).where(eq(spaPayments.accountId, accountId));
  }

  async createSpaPayment(payment: InsertSpaPayment): Promise<SpaPayment> {
    const [created] = await db.insert(spaPayments).values(payment as any).returning();
    return created;
  }

  async deleteSpaPayment(id: string): Promise<boolean> {
    const result = await db.delete(spaPayments).where(eq(spaPayments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Treatment Supplies
  async getTreatmentSupplies(treatmentId: string): Promise<TreatmentSupply[]> {
    return db.select().from(treatmentSupplies).where(eq(treatmentSupplies.treatmentId, treatmentId));
  }

  async createTreatmentSupply(supply: InsertTreatmentSupply): Promise<TreatmentSupply> {
    const [created] = await db.insert(treatmentSupplies).values(supply as any).returning();
    return created;
  }

  async deleteTreatmentSupply(id: string): Promise<boolean> {
    const result = await db.delete(treatmentSupplies).where(eq(treatmentSupplies.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async deductStockFromSpaAccount(accountId: string): Promise<void> {
    try {
      const accountData = await this.getSpaAccount(accountId);
      if (!accountData || !accountData.appointmentId) return;

      const [appointment] = await db.select().from(spaAppointments).where(eq(spaAppointments.id, accountData.appointmentId));
      if (!appointment || !appointment.treatmentId) return;

      const supplies = await this.getTreatmentSupplies(appointment.treatmentId);
      if (!supplies.length) return;

      for (const supply of supplies) {
        try {
          const [invItem] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, supply.inventoryItemId));
          if (!invItem) continue;

          const prev = parseFloat(invItem.currentStock ?? "0");
          const qty = parseFloat(supply.quantity);
          const newStock = Math.max(0, prev - qty);

          await db.update(inventoryItems)
            .set({ currentStock: String(newStock) })
            .where(eq(inventoryItems.id, supply.inventoryItemId));

          await db.insert(stockMovements).values({
            itemId: supply.inventoryItemId,
            type: "salida",
            quantity: String(qty),
            previousStock: String(prev),
            newStock: String(newStock),
            reason: "Consumo SPA",
            sourceType: "spa_account",
            sourceId: accountId,
            createdAt: new Date(),
          } as any);
        } catch (err) {
          console.warn(`[SPA] Error descounting stock for item ${supply.inventoryItemId}:`, err);
        }
      }
    } catch (err) {
      console.warn(`[SPA] Error in deductStockFromSpaAccount:`, err);
    }
  }

  async getEventRooms(): Promise<EventRoom[]> {
    return db.select().from(eventRooms);
  }

  async getEventRoom(id: string): Promise<EventRoom | undefined> {
    const [room] = await db.select().from(eventRooms).where(eq(eventRooms.id, id));
    return room;
  }

  async createEventRoom(room: InsertEventRoom): Promise<EventRoom> {
    const [created] = await db.insert(eventRooms).values(room as any).returning();
    return created;
  }

  async updateEventRoom(id: string, room: Partial<InsertEventRoom>): Promise<EventRoom | undefined> {
    const [updated] = await db.update(eventRooms).set(room as any).where(eq(eventRooms.id, id)).returning();
    return updated;
  }

  async deleteEventRoom(id: string): Promise<boolean> {
    const result = await db.delete(eventRooms).where(eq(eventRooms.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  private async enrichEvent(event: HotelEvent): Promise<EventWithDetails> {
    const [eventRoom] = await db.select().from(eventRooms).where(eq(eventRooms.id, event.eventRoomId));
    const company = event.companyId ? (await db.select().from(companies).where(eq(companies.id, event.companyId)))[0] : undefined;
    const chargesList = await db.select().from(eventCharges).where(eq(eventCharges.eventId, event.id));
    const allChargeTypes = await db.select().from(eventChargeTypes);
    const chargeTypesMap = new Map(allChargeTypes.map(ct => [ct.id, ct]));
    const chargesWithType: EventChargeWithType[] = chargesList.map(c => ({
      ...c,
      chargeType: c.chargeTypeId ? chargeTypesMap.get(c.chargeTypeId) : undefined,
    }));
    const paymentsList = await db.select().from(eventPayments).where(eq(eventPayments.eventId, event.id));
    return { ...event, eventRoom, company, charges: chargesWithType, payments: paymentsList };
  }

  async getEvents(): Promise<EventWithDetails[]> {
    const allEvents = await db.select().from(events);
    const results: EventWithDetails[] = [];
    for (const event of allEvents) {
      results.push(await this.enrichEvent(event));
    }
    return results;
  }

  async getEvent(id: string): Promise<EventWithDetails | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    if (!event) return undefined;
    return this.enrichEvent(event);
  }

  async getEventsByDateRange(startDate: string, endDate: string): Promise<EventWithDetails[]> {
    const eventsInRange = await db.select().from(events).where(
      and(
        sql`${events.startDate} <= ${endDate}`,
        sql`${events.endDate} >= ${startDate}`
      )
    );
    const results: EventWithDetails[] = [];
    for (const event of eventsInRange) {
      results.push(await this.enrichEvent(event));
    }
    return results;
  }

  async createEvent(event: InsertEvent): Promise<HotelEvent> {
    const [created] = await db.insert(events).values(event as any).returning();
    return created;
  }

  async updateEvent(id: string, event: Partial<InsertEvent>): Promise<HotelEvent | undefined> {
    const [updated] = await db.update(events).set(event as any).where(eq(events.id, id)).returning();
    return updated;
  }

  async deleteEvent(id: string): Promise<boolean> {
    // Must delete in FK order: table sub-records → tables → charges/payments → event
    const tables = await db.select({ id: eventTables.id }).from(eventTables).where(eq(eventTables.eventId, id));
    if (tables.length > 0) {
      const tableIds = tables.map(t => t.id);
      await db.delete(eventTableCharges).where(inArray(eventTableCharges.eventTableId, tableIds));
      await db.delete(eventTablePayments).where(inArray(eventTablePayments.eventTableId, tableIds));
      await db.delete(eventTables).where(eq(eventTables.eventId, id));
    }
    await db.delete(eventCharges).where(eq(eventCharges.eventId, id));
    await db.delete(eventPayments).where(eq(eventPayments.eventId, id));
    const result = await db.delete(events).where(eq(events.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  generateEventCode(): string {
    const year = new Date().getFullYear();
    const random = Math.floor(Math.random() * 10000);
    return `EVT-${year}-${random.toString().padStart(4, "0")}`;
  }

  async getEventChargeTypes(): Promise<EventChargeType[]> {
    return db.select().from(eventChargeTypes);
  }

  async getEventChargeType(id: string): Promise<EventChargeType | undefined> {
    const [ct] = await db.select().from(eventChargeTypes).where(eq(eventChargeTypes.id, id));
    return ct;
  }

  async createEventChargeType(chargeType: InsertEventChargeType): Promise<EventChargeType> {
    const [created] = await db.insert(eventChargeTypes).values(chargeType as any).returning();
    return created;
  }

  async updateEventChargeType(id: string, chargeType: Partial<InsertEventChargeType>): Promise<EventChargeType | undefined> {
    const [updated] = await db.update(eventChargeTypes).set(chargeType as any).where(eq(eventChargeTypes.id, id)).returning();
    return updated;
  }

  async deleteEventChargeType(id: string): Promise<boolean> {
    const result = await db.delete(eventChargeTypes).where(eq(eventChargeTypes.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getEventCharges(eventId: string): Promise<EventChargeWithType[]> {
    const chargesList = await db.select().from(eventCharges).where(eq(eventCharges.eventId, eventId));
    const allChargeTypes = await db.select().from(eventChargeTypes);
    const chargeTypesMap = new Map(allChargeTypes.map(ct => [ct.id, ct]));
    return chargesList.map(c => ({
      ...c,
      chargeType: c.chargeTypeId ? chargeTypesMap.get(c.chargeTypeId) : undefined,
    }));
  }

  async createEventCharge(charge: InsertEventCharge): Promise<EventCharge> {
    const [created] = await db.insert(eventCharges).values(charge as any).returning();
    return created;
  }

  async updateEventCharge(id: string, charge: Partial<InsertEventCharge>): Promise<EventCharge | undefined> {
    const [updated] = await db.update(eventCharges).set(charge as any).where(eq(eventCharges.id, id)).returning();
    return updated;
  }

  async deleteEventCharge(id: string): Promise<boolean> {
    const result = await db.delete(eventCharges).where(eq(eventCharges.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getEventPayments(eventId: string): Promise<EventPayment[]> {
    return db.select().from(eventPayments).where(eq(eventPayments.eventId, eventId));
  }

  async createEventPayment(payment: InsertEventPayment): Promise<EventPayment> {
    const [created] = await db.insert(eventPayments).values(payment as any).returning();
    return created;
  }

  async deleteEventPayment(id: string): Promise<boolean> {
    const result = await db.delete(eventPayments).where(eq(eventPayments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getEventTables(eventId: string): Promise<EventTableWithDetails[]> {
    const tables = await db.select().from(eventTables).where(eq(eventTables.eventId, eventId));
    if (tables.length === 0) return [];

    const tableIds = tables.map(t => t.id);
    const invoiceIds = [...new Set(tables.map(t => t.invoiceId).filter((id): id is number => id !== null))];

    const [allCharges, allPayments, allInvoices] = await Promise.all([
      db.select().from(eventTableCharges).where(inArray(eventTableCharges.eventTableId, tableIds)),
      db.select().from(eventTablePayments).where(inArray(eventTablePayments.eventTableId, tableIds)),
      invoiceIds.length
        ? db.select({ id: salesInvoices.id, puntoVenta: salesInvoices.puntoVenta, numero: salesInvoices.numero })
            .from(salesInvoices)
            .where(inArray(salesInvoices.id, invoiceIds))
        : Promise.resolve([]),
    ]);

    const chargesMap = new Map<string, typeof allCharges>();
    for (const c of allCharges) {
      if (!chargesMap.has(c.eventTableId)) chargesMap.set(c.eventTableId, []);
      chargesMap.get(c.eventTableId)!.push(c);
    }
    const paymentsMap = new Map<string, typeof allPayments>();
    for (const p of allPayments) {
      if (!paymentsMap.has(p.eventTableId)) paymentsMap.set(p.eventTableId, []);
      paymentsMap.get(p.eventTableId)!.push(p);
    }
    const invoiceMap = new Map(
      allInvoices.map(inv => [
        inv.id,
        String(inv.puntoVenta).padStart(4, "0") + "-" + String(inv.numero).padStart(8, "0"),
      ])
    );

    return tables.map(table => ({
      ...table,
      charges: chargesMap.get(table.id) ?? [],
      payments: paymentsMap.get(table.id) ?? [],
      invoiceRef: table.invoiceId ? (invoiceMap.get(table.invoiceId) ?? null) : null,
    }));
  }

  async getEventTable(id: string): Promise<EventTableWithDetails | undefined> {
    const [table] = await db.select().from(eventTables).where(eq(eventTables.id, id));
    if (!table) return undefined;
    return this.enrichEventTable(table);
  }

  private async enrichEventTable(table: EventTable): Promise<EventTableWithDetails> {
    // Single round-trip: correlated subqueries aggregate charges and payments as JSON arrays;
    // the invoice is resolved via a LEFT JOIN on the same query.
    const result = await db.execute(sql`
      SELECT
        (
          SELECT COALESCE(json_agg(jsonb_build_object(
            'id',           c.id,
            'eventTableId', c.event_table_id,
            'description',  c.description,
            'quantity',     c.quantity,
            'unitPrice',    c.unit_price,
            'total',        c.total,
            'createdAt',    c.created_at
          )), '[]'::json)
          FROM event_table_charges c
          WHERE c.event_table_id = ${table.id}
        ) AS charges,
        (
          SELECT COALESCE(json_agg(jsonb_build_object(
            'id',            p.id,
            'eventTableId',  p.event_table_id,
            'amount',        p.amount,
            'method',        p.method,
            'isAdvance',     p.is_advance,
            'reservationId', p.reservation_id,
            'receiptType',   p.receipt_type,
            'paidAt',        p.paid_at,
            'createdAt',     p.created_at
          )), '[]'::json)
          FROM event_table_payments p
          WHERE p.event_table_id = ${table.id}
        ) AS payments,
        CASE WHEN inv.id IS NOT NULL
          THEN lpad(inv.punto_venta::text, 4, '0') || '-' || lpad(inv.numero::text, 8, '0')
          ELSE NULL
        END AS invoice_ref
      FROM event_tables t
      LEFT JOIN sales_invoices inv ON inv.id = t.invoice_id
      WHERE t.id = ${table.id}
    `);
    const row = result.rows[0] as any;
    return {
      ...table,
      charges: (row?.charges as EventTableCharge[]) ?? [],
      payments: (row?.payments as EventTablePayment[]) ?? [],
      invoiceRef: (row?.invoice_ref as string | null) ?? null,
    };
  }

  async createEventTable(table: InsertEventTable): Promise<EventTable> {
    const [created] = await db.insert(eventTables).values(table as any).returning();
    return created;
  }

  async updateEventTable(id: string, table: Partial<InsertEventTable>): Promise<EventTable | undefined> {
    const [updated] = await db.update(eventTables).set(table as any).where(eq(eventTables.id, id)).returning();
    return updated;
  }

  async deleteEventTable(id: string): Promise<boolean> {
    await db.delete(eventTableCharges).where(eq(eventTableCharges.eventTableId, id));
    await db.delete(eventTablePayments).where(eq(eventTablePayments.eventTableId, id));
    const result = await db.delete(eventTables).where(eq(eventTables.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getEventTableCharges(tableId: string): Promise<EventTableCharge[]> {
    return db.select().from(eventTableCharges).where(eq(eventTableCharges.eventTableId, tableId));
  }

  async createEventTableCharge(charge: InsertEventTableCharge): Promise<EventTableCharge> {
    const [created] = await db.insert(eventTableCharges).values(charge as any).returning();
    return created;
  }

  async deleteEventTableCharge(id: string): Promise<boolean> {
    const result = await db.delete(eventTableCharges).where(eq(eventTableCharges.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getEventTablePayments(tableId: string): Promise<EventTablePayment[]> {
    return db.select().from(eventTablePayments).where(eq(eventTablePayments.eventTableId, tableId));
  }

  async createEventTablePayment(payment: InsertEventTablePayment): Promise<EventTablePayment> {
    const [created] = await db.insert(eventTablePayments).values(payment as any).returning();
    return created;
  }

  async deleteEventTablePayment(id: string): Promise<boolean> {
    const result = await db.delete(eventTablePayments).where(eq(eventTablePayments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getEventPlanningData(startDate: string, endDate: string): Promise<EventPlanningData> {
    const allEventRooms = await db.select().from(eventRooms).where(eq(eventRooms.isActive, "true"));
    const days: string[] = [];
    const currentDate = new Date(startDate);
    const end = new Date(endDate);
    while (currentDate <= end) {
      days.push(currentDate.toISOString().split("T")[0]);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    const eventsInRange = await db.select().from(events).where(
      and(
        sql`${events.startDate} <= ${endDate}`,
        sql`${events.endDate} >= ${startDate}`,
        ne(events.status, "cancelled")
      )
    );

    const occupancy: Record<string, EventPlanningCellStatus[]> = {};
    const eventsMap: Record<string, any> = {};
    const cellEvents: Record<string, Record<string, string[]>> = {};

    allEventRooms.forEach(room => {
      occupancy[room.id] = [];
      cellEvents[room.id] = {};

      days.forEach(day => {
        const dayEvents = eventsInRange.filter(e => e.eventRoomId === room.id && e.startDate <= day && e.endDate >= day);
        if (dayEvents.length > 0) {
          occupancy[room.id].push("event");
          cellEvents[room.id][day] = dayEvents.map(e => e.id);
          dayEvents.forEach(event => {
            if (!eventsMap[event.id]) {
              eventsMap[event.id] = {
                id: event.id,
                name: event.name,
                contactName: event.contactName,
                startDate: event.startDate,
                endDate: event.endDate,
                status: event.status as EventStatus,
                eventType: event.eventType as EventType,
                ncId: (event as any).ncId ?? null,
              };
            }
          });
        } else if (room.status === "maintenance") {
          occupancy[room.id].push("maintenance");
        } else {
          occupancy[room.id].push("available");
        }
      });
    });

    return { rooms: allEventRooms, days, occupancy, events: eventsMap, cellEvents };
  }

  async getMaintenanceStaff(): Promise<MaintenanceStaff[]> {
    return db.select().from(maintenanceStaff);
  }

  async getMaintenanceStaffMember(id: string): Promise<MaintenanceStaff | undefined> {
    const [staff] = await db.select().from(maintenanceStaff).where(eq(maintenanceStaff.id, id));
    return staff;
  }

  async createMaintenanceStaff(staff: InsertMaintenanceStaff): Promise<MaintenanceStaff> {
    const [created] = await db.insert(maintenanceStaff).values(staff as any).returning();
    return created;
  }

  async updateMaintenanceStaff(id: string, staff: Partial<InsertMaintenanceStaff>): Promise<MaintenanceStaff | undefined> {
    const [updated] = await db.update(maintenanceStaff).set(staff as any).where(eq(maintenanceStaff.id, id)).returning();
    return updated;
  }

  async deleteMaintenanceStaff(id: string): Promise<boolean> {
    const result = await db.delete(maintenanceStaff).where(eq(maintenanceStaff.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  private async enrichWorkOrder(wo: WorkOrder): Promise<WorkOrderWithDetails> {
    const room = wo.roomId ? (await db.select().from(rooms).where(eq(rooms.id, wo.roomId)))[0] : undefined;
    let assignedTo: { id: string; name: string } | undefined;
    if (wo.assignedToId && wo.assignedToId !== "externo") {
      // Try system users first (maintenance role), then legacy maintenance_staff
      const sysUser = (await db.select().from(systemUsers).where(eq(systemUsers.id, wo.assignedToId)))[0];
      if (sysUser) {
        assignedTo = {
          id: sysUser.id,
          name: sysUser.fullName || sysUser.username,
        };
      } else {
        const staffMember = (await db.select().from(maintenanceStaff).where(eq(maintenanceStaff.id, wo.assignedToId)))[0];
        if (staffMember) assignedTo = { id: staffMember.id, name: staffMember.name };
      }
    }
    return { ...wo, room, assignedTo };
  }

  async getWorkOrders(): Promise<WorkOrderWithDetails[]> {
    const allOrders = await db.select().from(workOrders);
    const results: WorkOrderWithDetails[] = [];
    for (const wo of allOrders) {
      results.push(await this.enrichWorkOrder(wo));
    }
    return results;
  }

  async getWorkOrder(id: string): Promise<WorkOrderWithDetails | undefined> {
    const [wo] = await db.select().from(workOrders).where(eq(workOrders.id, id));
    if (!wo) return undefined;
    return this.enrichWorkOrder(wo);
  }

  async getWorkOrdersByRoom(roomId: string): Promise<WorkOrderWithDetails[]> {
    const allOrders = await db.select().from(workOrders).where(eq(workOrders.roomId, roomId));
    const results: WorkOrderWithDetails[] = [];
    for (const wo of allOrders) {
      results.push(await this.enrichWorkOrder(wo));
    }
    return results;
  }

  async getWorkOrdersByStatus(status: WorkOrderStatus): Promise<WorkOrderWithDetails[]> {
    const allOrders = await db.select().from(workOrders).where(eq(workOrders.status, status));
    const results: WorkOrderWithDetails[] = [];
    for (const wo of allOrders) {
      results.push(await this.enrichWorkOrder(wo));
    }
    return results;
  }

  async createWorkOrder(order: InsertWorkOrder): Promise<WorkOrder> {
    const [created] = await db.insert(workOrders).values(order as any).returning();
    return created;
  }

  async updateWorkOrder(id: string, order: Partial<InsertWorkOrder>): Promise<WorkOrder | undefined> {
    const [updated] = await db.update(workOrders).set(order as any).where(eq(workOrders.id, id)).returning();
    return updated;
  }

  async deleteWorkOrder(id: string): Promise<boolean> {
    const result = await db.delete(workOrders).where(eq(workOrders.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Maintenance Blocks
  async getMaintenanceBlocks(filters?: { roomId?: string; from?: string; to?: string }): Promise<MaintenanceBlock[]> {
    let q = db.select().from(maintenanceBlocks).$dynamic();
    if (filters?.roomId) q = q.where(eq(maintenanceBlocks.roomId, filters.roomId)) as any;
    const blocks = await q.orderBy(asc(maintenanceBlocks.blockFrom));
    if (!filters?.from && !filters?.to) return blocks;
    return blocks.filter(b => {
      if (filters?.to && b.blockFrom > filters.to) return false;
      if (filters?.from && b.blockTo < filters.from) return false;
      return true;
    });
  }

  async checkMaintenanceBlockConflicts(roomId: string, blockFrom: string, blockTo: string) {
    return db.select({
      id: reservations.id,
      guestName: sql<string>`CONCAT(COALESCE(${guests.firstName}, ''), ' ', COALESCE(${guests.lastName}, ''))`,
      checkInDate: reservations.checkInDate,
      checkOutDate: reservations.checkOutDate,
      status: reservations.status,
    }).from(reservations).leftJoin(guests, eq(reservations.guestId, guests.id)).where(
      and(
        eq(reservations.roomId, roomId),
        lt(reservations.checkInDate, blockTo),
        gt(reservations.checkOutDate, blockFrom),
        not(inArray(reservations.status, ["cancelled", "checked_out"] as any))
      )
    );
  }

  async createMaintenanceBlock(block: InsertMaintenanceBlock): Promise<MaintenanceBlock> {
    const [created] = await db.insert(maintenanceBlocks).values(block as any).returning();
    return created;
  }

  async deleteMaintenanceBlock(id: string): Promise<boolean> {
    const result = await db.delete(maintenanceBlocks).where(eq(maintenanceBlocks.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async deleteMaintenanceBlockByWorkOrder(workOrderId: string): Promise<void> {
    await db.delete(maintenanceBlocks).where(eq(maintenanceBlocks.workOrderId, workOrderId));
  }

  generateWorkOrderCode(): string {
    const random = Math.floor(Math.random() * 10000);
    return `OT-${random}`;
  }

  async getSystemUsers(): Promise<SystemUser[]> {
    return db.select().from(systemUsers);
  }

  async getSystemUser(id: string): Promise<SystemUser | undefined> {
    const [user] = await db.select().from(systemUsers).where(eq(systemUsers.id, id));
    return user;
  }

  async getSystemUserByUsername(username: string): Promise<SystemUser | undefined> {
    const [user] = await db.select().from(systemUsers).where(eq(systemUsers.username, username));
    return user;
  }

  async createSystemUser(user: InsertSystemUser): Promise<SystemUser> {
    const [created] = await db.insert(systemUsers).values(user as any).returning();
    return created;
  }

  async updateSystemUser(id: string, user: Partial<InsertSystemUser>): Promise<SystemUser | undefined> {
    const [updated] = await db.update(systemUsers).set(user as any).where(eq(systemUsers.id, id)).returning();
    return updated;
  }

  async deleteSystemUser(id: string): Promise<boolean> {
    const result = await db.delete(systemUsers).where(eq(systemUsers.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getSystemSettings(): Promise<SystemSetting[]> {
    return db.select().from(systemSettings);
  }

  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    const [setting] = await db.select().from(systemSettings).where(eq(systemSettings.key, key));
    return setting;
  }

  async getSystemSettingsByCategory(category: string): Promise<SystemSetting[]> {
    return db.select().from(systemSettings).where(eq(systemSettings.category, category));
  }

  async upsertSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting> {
    const existing = await this.getSystemSetting(setting.key);
    if (existing) {
      const [updated] = await db.update(systemSettings).set(setting as any).where(eq(systemSettings.key, setting.key)).returning();
      return updated;
    }
    const [created] = await db.insert(systemSettings).values(setting as any).returning();
    return created;
  }

  async deleteSystemSetting(key: string): Promise<boolean> {
    const result = await db.delete(systemSettings).where(eq(systemSettings.key, key));
    return (result.rowCount ?? 0) > 0;
  }

  async getAuditLogs(): Promise<AuditLog[]> {
    return db.select().from(auditLogs).orderBy(desc(auditLogs.timestamp));
  }

  async getAuditLogsByModule(module: string): Promise<AuditLog[]> {
    return db.select().from(auditLogs).where(eq(auditLogs.module, module)).orderBy(desc(auditLogs.timestamp));
  }

  async getAuditLogsByUser(userId: string): Promise<AuditLog[]> {
    return db.select().from(auditLogs).where(eq(auditLogs.userId, userId)).orderBy(desc(auditLogs.timestamp));
  }

  async createAuditLog(log: InsertAuditLog): Promise<AuditLog> {
    const [created] = await db.insert(auditLogs).values(log as any).returning();
    return created;
  }

  async getAdminDashboardStats(): Promise<{
    totalUsers: number;
    activeUsers: number;
    recentLogins: number;
    totalSettings: number;
    recentAuditLogs: AuditLog[];
  }> {
    const allUsers = await db.select().from(systemUsers);
    const today = getArgentinaToday();

    const recentLogins = allUsers.filter(u => {
      if (!u.lastLogin) return false;
      return u.lastLogin.toISOString().startsWith(today);
    }).length;

    const settingsCount = await db.select({ cnt: count() }).from(systemSettings);
    const recentLogs = await db.select().from(auditLogs).orderBy(desc(auditLogs.timestamp)).limit(10);

    return {
      totalUsers: allUsers.length,
      activeUsers: allUsers.filter(u => u.isActive === "true").length,
      recentLogins,
      totalSettings: Number(settingsCount[0]?.cnt ?? 0),
      recentAuditLogs: recentLogs,
    };
  }

  private async enrichPackage(pkg: Package): Promise<PackageWithDetails> {
    const roomType = pkg.roomTypeId ? (await db.select().from(roomTypes).where(eq(roomTypes.id, pkg.roomTypeId)))[0] : undefined;
    const items = await db.select().from(packageItems).where(eq(packageItems.packageId, pkg.id));
    const priceRows = await db.select().from(packageRoomPrices).where(eq(packageRoomPrices.packageId, pkg.id));
    const roomPrices: PackageRoomPriceWithType[] = await Promise.all(
      priceRows.map(async (p) => {
        const [rt] = await db.select().from(roomTypes).where(eq(roomTypes.id, p.roomTypeId));
        return { ...p, roomType: rt };
      })
    );
    return { ...pkg, roomType, items, roomPrices };
  }

  async getPackages(): Promise<PackageWithDetails[]> {
    const allPkgs = await db.select().from(packages);
    const results: PackageWithDetails[] = [];
    for (const pkg of allPkgs) {
      results.push(await this.enrichPackage(pkg));
    }
    return results;
  }

  async getPackage(id: string): Promise<PackageWithDetails | undefined> {
    const [pkg] = await db.select().from(packages).where(eq(packages.id, id));
    if (!pkg) return undefined;
    return this.enrichPackage(pkg);
  }

  async getActivePackages(): Promise<PackageWithDetails[]> {
    const today = getArgentinaToday();
    const allPkgs = await db.select().from(packages).where(eq(packages.status, "active"));
    const filtered = allPkgs.filter(p => {
      if (p.validFrom && p.validFrom > today) return false;
      if (p.validUntil && p.validUntil < today) return false;
      return true;
    });
    const results: PackageWithDetails[] = [];
    for (const pkg of filtered) {
      results.push(await this.enrichPackage(pkg));
    }
    return results;
  }

  async createPackage(pkg: InsertPackage): Promise<Package> {
    const [created] = await db.insert(packages).values(pkg as any).returning();
    return created;
  }

  async updatePackage(id: string, pkg: Partial<InsertPackage>): Promise<Package | undefined> {
    const [updated] = await db.update(packages).set(pkg as any).where(eq(packages.id, id)).returning();
    return updated;
  }

  async deletePackage(id: string): Promise<boolean> {
    await db.delete(packageItems).where(eq(packageItems.packageId, id));
    await db.delete(packageRoomPrices).where(eq(packageRoomPrices.packageId, id));
    const result = await db.delete(packages).where(eq(packages.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getPackageRoomPrices(packageId: string): Promise<PackageRoomPriceWithType[]> {
    const rows = await db.select().from(packageRoomPrices).where(eq(packageRoomPrices.packageId, packageId));
    return Promise.all(rows.map(async (p) => {
      const [rt] = await db.select().from(roomTypes).where(eq(roomTypes.id, p.roomTypeId));
      return { ...p, roomType: rt };
    }));
  }

  async createPackageRoomPrice(data: InsertPackageRoomPrice): Promise<PackageRoomPrice> {
    const [created] = await db.insert(packageRoomPrices).values(data as any).returning();
    return created;
  }

  async updatePackageRoomPrice(id: string, data: Partial<InsertPackageRoomPrice>): Promise<PackageRoomPrice | undefined> {
    const [updated] = await db.update(packageRoomPrices).set(data as any).where(eq(packageRoomPrices.id, id)).returning();
    return updated;
  }

  async deletePackageRoomPrice(id: string): Promise<boolean> {
    const result = await db.delete(packageRoomPrices).where(eq(packageRoomPrices.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async deletePackageRoomPricesByPackage(packageId: string): Promise<void> {
    await db.delete(packageRoomPrices).where(eq(packageRoomPrices.packageId, packageId));
  }

  generatePackageCode(): string {
    const random = Math.floor(Math.random() * 10000);
    return `PKG-${random.toString().padStart(4, "0")}`;
  }

  async getPackageItems(packageId: string): Promise<PackageItem[]> {
    return db.select().from(packageItems).where(eq(packageItems.packageId, packageId));
  }

  async createPackageItem(item: InsertPackageItem): Promise<PackageItem> {
    const [created] = await db.insert(packageItems).values(item as any).returning();
    return created;
  }

  async updatePackageItem(id: string, item: Partial<InsertPackageItem>): Promise<PackageItem | undefined> {
    const [updated] = await db.update(packageItems).set(item as any).where(eq(packageItems.id, id)).returning();
    return updated;
  }

  async deletePackageItem(id: string): Promise<boolean> {
    const result = await db.delete(packageItems).where(eq(packageItems.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getNotifications(area?: NotificationArea, limit?: number): Promise<SystemNotification[]> {
    let query;
    if (area) {
      query = db.select().from(systemNotifications).where(
        or(eq(systemNotifications.targetArea, area), eq(systemNotifications.targetArea, "all"))
      ).orderBy(asc(systemNotifications.isRead), desc(systemNotifications.createdAt));
    } else {
      query = db.select().from(systemNotifications).orderBy(asc(systemNotifications.isRead), desc(systemNotifications.createdAt));
    }

    if (limit) {
      return (query as any).limit(limit);
    }
    return query;
  }

  async createNotification(notification: InsertSystemNotification): Promise<SystemNotification> {
    const [created] = await db.insert(systemNotifications).values(notification as any).returning();
    return created;
  }

  async markNotificationRead(id: string): Promise<SystemNotification | undefined> {
    const [updated] = await db.update(systemNotifications).set({ isRead: true, readAt: new Date() }).where(eq(systemNotifications.id, id)).returning();
    return updated;
  }

  async updateNotificationStatus(id: string, status: string, staffNote?: string, resolvedBy?: string): Promise<SystemNotification | undefined> {
    const isResolved = status === "completado" || status === "rechazado";
    const [updated] = await db.update(systemNotifications).set({
      status: status as any,
      isRead: true,
      readAt: new Date(),
      ...(staffNote !== undefined ? { staffNote } : {}),
      ...(isResolved ? { resolvedAt: new Date(), resolvedBy: resolvedBy ?? null } : {}),
    }).where(eq(systemNotifications.id, id)).returning();
    return updated;
  }

  async markAllNotificationsRead(area?: NotificationArea): Promise<number> {
    let condition;
    if (area) {
      condition = and(
        eq(systemNotifications.isRead, false),
        or(eq(systemNotifications.targetArea, area), eq(systemNotifications.targetArea, "all"))
      );
    } else {
      condition = eq(systemNotifications.isRead, false);
    }
    const result = await db.update(systemNotifications).set({ isRead: true, readAt: new Date() }).where(condition!);
    return result.rowCount ?? 0;
  }

  async getUnreadNotificationCount(area?: NotificationArea): Promise<number> {
    let condition;
    if (area) {
      condition = and(
        eq(systemNotifications.isRead, false),
        or(eq(systemNotifications.targetArea, area), eq(systemNotifications.targetArea, "all"))
      );
    } else {
      condition = eq(systemNotifications.isRead, false);
    }
    const result = await db.select({ cnt: count() }).from(systemNotifications).where(condition!);
    return Number(result[0]?.cnt ?? 0);
  }

  async createWebCheckin(data: InsertWebCheckin): Promise<WebCheckin> {
    const [created] = await db.insert(webCheckins).values(data as any).returning();
    return created;
  }

  async getWebCheckinByToken(token: string): Promise<WebCheckin | undefined> {
    const [checkin] = await db.select().from(webCheckins).where(eq(webCheckins.token, token));
    return checkin;
  }

  async getWebCheckinByReservation(reservationId: string): Promise<WebCheckin | undefined> {
    const [checkin] = await db.select().from(webCheckins).where(eq(webCheckins.reservationId, reservationId));
    return checkin;
  }

  async updateWebCheckin(id: string, data: Partial<InsertWebCheckin>): Promise<WebCheckin | undefined> {
    const [updated] = await db.update(webCheckins).set(data as any).where(eq(webCheckins.id, id)).returning();
    return updated;
  }

  async listWebCheckins(): Promise<WebCheckin[]> {
    return db.select().from(webCheckins).orderBy(desc(webCheckins.createdAt));
  }

  async getGuestPreferences(guestId: string): Promise<GuestPreference[]> {
    return db.select().from(guestPreferences).where(eq(guestPreferences.guestId, guestId)).orderBy(desc(guestPreferences.createdAt));
  }

  async getActiveGuestPreferences(guestId: string): Promise<GuestPreference[]> {
    return db.select().from(guestPreferences).where(
      and(eq(guestPreferences.guestId, guestId), eq(guestPreferences.isActive, true))
    ).orderBy(asc(guestPreferences.priority));
  }

  async getGuestPreference(id: string): Promise<GuestPreference | undefined> {
    const [pref] = await db.select().from(guestPreferences).where(eq(guestPreferences.id, id));
    return pref;
  }

  async createGuestPreference(pref: InsertGuestPreference): Promise<GuestPreference> {
    const [created] = await db.insert(guestPreferences).values(pref as any).returning();
    return created;
  }

  async updateGuestPreference(id: string, pref: Partial<InsertGuestPreference>): Promise<GuestPreference | undefined> {
    const [updated] = await db.update(guestPreferences).set({ ...pref as any, updatedAt: new Date() }).where(eq(guestPreferences.id, id)).returning();
    return updated;
  }

  async toggleGuestPreference(id: string): Promise<GuestPreference | undefined> {
    const [existing] = await db.select().from(guestPreferences).where(eq(guestPreferences.id, id));
    if (!existing) return undefined;
    const [updated] = await db.update(guestPreferences).set({ isActive: !existing.isActive, updatedAt: new Date() }).where(eq(guestPreferences.id, id)).returning();
    return updated;
  }

  async deleteGuestPreference(id: string): Promise<boolean> {
    const result = await db.delete(guestPreferences).where(eq(guestPreferences.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getStayNotes(reservationId: string): Promise<StayNote[]> {
    return db.select().from(stayNotes).where(eq(stayNotes.reservationId, reservationId)).orderBy(desc(stayNotes.createdAt));
  }

  async getActiveStayNotes(): Promise<StayNote[]> {
    return db.select().from(stayNotes).where(eq(stayNotes.isResolved, false)).orderBy(desc(stayNotes.createdAt));
  }

  async createStayNote(note: InsertStayNote): Promise<StayNote> {
    const [created] = await db.insert(stayNotes).values(note as any).returning();
    return created;
  }

  async updateStayNote(id: string, note: Partial<InsertStayNote>): Promise<StayNote | undefined> {
    const [updated] = await db.update(stayNotes).set(note as any).where(eq(stayNotes.id, id)).returning();
    return updated;
  }

  async resolveStayNote(id: string, resolvedBy: string): Promise<StayNote | undefined> {
    const [updated] = await db.update(stayNotes).set({ isResolved: true, resolvedAt: new Date(), resolvedBy }).where(eq(stayNotes.id, id)).returning();
    return updated;
  }

  async deleteStayNote(id: string): Promise<boolean> {
    const result = await db.delete(stayNotes).where(eq(stayNotes.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getHospitalityAlerts(area?: string): Promise<HospitalityAlert[]> {
    if (area && area !== "all") {
      return db.select().from(hospitalityAlerts).where(
        or(eq(hospitalityAlerts.targetArea, area), eq(hospitalityAlerts.targetArea, "all"))
      ).orderBy(desc(hospitalityAlerts.createdAt));
    }
    return db.select().from(hospitalityAlerts).orderBy(desc(hospitalityAlerts.createdAt));
  }

  async getHospitalityAlertsByReservation(reservationId: string): Promise<HospitalityAlert[]> {
    return db.select().from(hospitalityAlerts).where(eq(hospitalityAlerts.reservationId, reservationId)).orderBy(desc(hospitalityAlerts.createdAt));
  }

  async createHospitalityAlert(alert: InsertHospitalityAlert): Promise<HospitalityAlert> {
    const [created] = await db.insert(hospitalityAlerts).values(alert as any).returning();
    return created;
  }

  async acknowledgeHospitalityAlert(id: string, acknowledgedBy: string): Promise<HospitalityAlert | undefined> {
    const [updated] = await db.update(hospitalityAlerts).set({
      isAcknowledged: true,
      acknowledgedAt: new Date(),
      acknowledgedBy,
      status: "in_progress",
    }).where(eq(hospitalityAlerts.id, id)).returning();
    return updated;
  }

  async getExecutiveStats(from: string, to: string): Promise<any> {
    const allRooms = await db.select().from(rooms);
    const realRooms = allRooms.filter(r => !r.isVirtual && r.isActive !== false);
    const totalRooms = realRooms.length;

    const roomsByStatus: Record<string, number> = { available: 0, occupied: 0, dirty: 0, cleaning: 0, maintenance: 0, oos: 0 };
    for (const r of realRooms) {
      const s = r.status || "available";
      if (s in roomsByStatus) roomsByStatus[s]++;
      else roomsByStatus[s] = (roomsByStatus[s] || 0) + 1;
    }

    const periodReservations = await db.select().from(reservations)
      .where(and(lte(reservations.checkInDate, to), gte(reservations.checkOutDate, from)));

    let totalNightsSold = 0;
    for (const r of periodReservations) {
      const ci = new Date(Math.max(new Date(r.checkInDate).getTime(), new Date(from).getTime()));
      const co = new Date(Math.min(new Date(r.checkOutDate).getTime(), new Date(to).getTime()));
      const nights = Math.max(0, Math.ceil((co.getTime() - ci.getTime()) / 86400000));
      totalNightsSold += nights;
    }

    const periodPayments = await db.select().from(payments)
      .where(and(gte(payments.date, from), lte(payments.date, to)));
    const totalRevenue = periodPayments.reduce((s, p) => s + parseFloat(p.amount || "0"), 0);

    const periodCharges = await db.select().from(charges)
      .where(and(gte(charges.date, from), lte(charges.date, to)));
    const accommodationCharges = periodCharges.filter(c => (c.category || "").toLowerCase().includes("aloj"));
    const accommodationRevenue = accommodationCharges.reduce((s, c) => s + parseFloat(c.amount || "0"), 0);
    const extrasRevenue = totalRevenue - accommodationRevenue;

    const daysInPeriod = Math.max(1, Math.ceil((new Date(to).getTime() - new Date(from).getTime()) / 86400000));
    const occupiedRooms = roomsByStatus.occupied || 0;
    const availableRooms = roomsByStatus.available || 0;
    const occupancyRate = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;

    const adr = totalNightsSold > 0 ? Math.round(totalRevenue / totalNightsSold) : 0;
    const revpar = Math.round(adr * occupancyRate / 100);

    const byChannelMap = new Map<string, { reservations: number; revenue: number }>();
    for (const r of periodReservations) {
      const src = r.source || "directo";
      if (!byChannelMap.has(src)) byChannelMap.set(src, { reservations: 0, revenue: 0 });
      const entry = byChannelMap.get(src)!;
      entry.reservations++;
      entry.revenue += parseFloat(r.totalRoomAmount || "0");
    }
    const totalChannelRevenue = Array.from(byChannelMap.values()).reduce((s, v) => s + v.revenue, 0);
    const byChannel = Array.from(byChannelMap.entries()).map(([source, data]) => ({
      source,
      reservations: data.reservations,
      revenue: Math.round(data.revenue),
      percentage: totalChannelRevenue > 0 ? Math.round((data.revenue / totalChannelRevenue) * 100) : 0,
    })).sort((a, b) => b.revenue - a.revenue);

    const prevFrom = new Date(new Date(from).getTime() - 365 * 86400000).toISOString().split("T")[0];
    const prevTo = new Date(new Date(to).getTime() - 365 * 86400000).toISOString().split("T")[0];
    const prevReservations = await db.select().from(reservations)
      .where(and(lte(reservations.checkInDate, prevTo), gte(reservations.checkOutDate, prevFrom)));
    const prevPayments = await db.select().from(payments)
      .where(and(gte(payments.date, prevFrom), lte(payments.date, prevTo)));
    const prevTotalRevenue = prevPayments.reduce((s, p) => s + parseFloat(p.amount || "0"), 0);
    let prevNightsSold = 0;
    for (const r of prevReservations) {
      const ci = new Date(Math.max(new Date(r.checkInDate).getTime(), new Date(prevFrom).getTime()));
      const co = new Date(Math.min(new Date(r.checkOutDate).getTime(), new Date(prevTo).getTime()));
      prevNightsSold += Math.max(0, Math.ceil((co.getTime() - ci.getTime()) / 86400000));
    }
    const prevAdr = prevNightsSold > 0 ? Math.round(prevTotalRevenue / prevNightsSold) : 0;
    const prevOccupancyRate = totalRooms > 0 ? Math.round((prevReservations.length / totalRooms) * 100) : 0;
    const prevRevpar = Math.round(prevAdr * prevOccupancyRate / 100);

    const today = getArgentinaToday();
    const todayReservations = await db.select().from(reservations)
      .where(eq(reservations.checkInDate, today));
    const todayCheckIns = todayReservations.filter(r => r.status === "confirmed" || r.status === "checked_in").length;
    const todayCheckOutReservations = await db.select().from(reservations)
      .where(eq(reservations.checkOutDate, today));
    const todayCheckOuts = todayCheckOutReservations.filter(r => r.status === "checked_in").length;
    const pendingCheckIns = todayReservations.filter(r => r.status === "confirmed").length;

    return {
      occupancyRate, occupiedRooms, availableRooms, totalRooms,
      totalRevenue: Math.round(totalRevenue), accommodationRevenue: Math.round(accommodationRevenue), extrasRevenue: Math.round(extrasRevenue),
      adr, revpar, byChannel,
      previousYear: { occupancyRate: prevOccupancyRate, totalRevenue: Math.round(prevTotalRevenue), adr: prevAdr, revpar: prevRevpar },
      todayCheckIns, todayCheckOuts, pendingCheckIns,
      roomsByStatus,
    };
  }

  async getReportOccupancy(from: string, to: string): Promise<any[]> {
    const result: any[] = [];
    const allRooms = await db.select().from(rooms);
    const totalRooms = allRooms.filter(r => !r.isVirtual).length;
    const start = new Date(from);
    const end = new Date(to);
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dateStr = d.toISOString().split("T")[0];
      const dayReservations = await db.select().from(reservations)
        .where(and(lte(reservations.checkInDate, dateStr), gt(reservations.checkOutDate, dateStr),
          inArray(reservations.status, ["checked_in", "checked_out", "confirmed"])));
      const occupied = dayReservations.length;
      const available = totalRooms - occupied;
      const occupancy = totalRooms > 0 ? Math.round((occupied / totalRooms) * 100) : 0;
      result.push({ date: dateStr, available, occupied, occupancy, totalRooms });
    }
    return result;
  }

  async getReportRevenueByRoomType(from: string, to: string): Promise<any[]> {
    const types = await db.select().from(roomTypes);
    const periodRes = await db.select().from(reservations)
      .where(and(lte(reservations.checkInDate, to), gte(reservations.checkOutDate, from)));

    const result: any[] = [];
    let grandTotal = 0;
    for (const t of types) {
      const typeRes = periodRes.filter(r => r.roomTypeId === t.id);
      let nightsSold = 0;
      let revenue = 0;
      for (const r of typeRes) {
        nightsSold += r.nights || 0;
        revenue += parseFloat(r.totalRoomAmount || "0");
      }
      grandTotal += revenue;
      const typeRooms = (await db.select().from(rooms).where(eq(rooms.roomTypeId, t.id))).length;
      result.push({ type: t.name, rooms: typeRooms, nightsSold, revenue: Math.round(revenue), adr: nightsSold > 0 ? Math.round(revenue / nightsSold) : 0 });
    }
    return result.map(r => ({ ...r, percentage: grandTotal > 0 ? Math.round((r.revenue / grandTotal) * 100) : 0 }));
  }

  async getReportByChannel(from: string, to: string): Promise<any[]> {
    const periodRes = await db.select().from(reservations)
      .where(and(lte(reservations.checkInDate, to), gte(reservations.checkOutDate, from)));

    const map = new Map<string, { reservations: number; nights: number; revenue: number }>();
    for (const r of periodRes) {
      const src = r.source || "directo";
      if (!map.has(src)) map.set(src, { reservations: 0, nights: 0, revenue: 0 });
      const e = map.get(src)!;
      e.reservations++;
      e.nights += r.nights || 0;
      e.revenue += parseFloat(r.totalRoomAmount || "0");
    }
    const total = Array.from(map.values()).reduce((s, v) => s + v.revenue, 0);
    const commissionRates: Record<string, number> = { booking: 15, airbnb: 14, expedia: 18, despegar: 17 };
    return Array.from(map.entries()).map(([source, d]) => {
      const commRate = commissionRates[source] || 0;
      const commission = Math.round(d.revenue * commRate / 100);
      return { source, reservations: d.reservations, nights: d.nights, revenue: Math.round(d.revenue), commission, net: Math.round(d.revenue - commission), percentage: total > 0 ? Math.round((d.revenue / total) * 100) : 0 };
    }).sort((a, b) => b.revenue - a.revenue);
  }

  async getReportReservations(from: string, to: string, status?: string): Promise<any[]> {
    let query = db.select().from(reservations)
      .where(and(lte(reservations.checkInDate, to), gte(reservations.checkOutDate, from)));

    let allRes = await query;
    if (status && status !== "all") {
      allRes = allRes.filter(r => r.status === status);
    }

    const result: any[] = [];
    for (const r of allRes) {
      const guest = r.guestId ? await db.select().from(guests).where(eq(guests.id, r.guestId)).then(g => g[0]) : null;
      const room = r.roomId ? await db.select().from(rooms).where(eq(rooms.id, r.roomId)).then(rm => rm[0]) : null;
      const type = r.roomTypeId ? await db.select().from(roomTypes).where(eq(roomTypes.id, r.roomTypeId)).then(t => t[0]) : null;
      const company = r.companyId ? await db.select().from(companies).where(eq(companies.id, r.companyId)).then(c => c[0]) : null;
      const resPay = await db.select().from(payments).where(eq(payments.reservationId, r.id));
      const totalPaid = resPay.reduce((s, p) => s + parseFloat(p.amount || "0"), 0);
      const total = parseFloat(r.totalRoomAmount || "0");
      result.push({
        code: r.reservationCode, guest: guest ? `${guest.lastName} ${guest.firstName}` : "-",
        company: company?.razonSocial || "-", room: room?.roomNumber || "-", type: type?.name || "-",
        checkIn: r.checkInDate, checkOut: r.checkOutDate, nights: r.nights,
        source: r.source, status: r.status, total: Math.round(total), paid: Math.round(totalPaid), balance: Math.round(total - totalPaid),
      });
    }
    return result;
  }

  async getReportPayments(from: string, to: string): Promise<any> {
    const allPayments = await db.select().from(payments)
      .where(and(gte(payments.date, from), lte(payments.date, to)));

    const methodMap = new Map<string, { count: number; total: number }>();
    for (const p of allPayments) {
      const m = p.method || "efectivo";
      if (!methodMap.has(m)) methodMap.set(m, { count: 0, total: 0 });
      const e = methodMap.get(m)!;
      e.count++;
      e.total += parseFloat(p.amount || "0");
    }
    const grandTotal = Array.from(methodMap.values()).reduce((s, v) => s + v.total, 0);
    const byMethod = Array.from(methodMap.entries()).map(([method, d]) => ({
      method, count: d.count, total: Math.round(d.total),
      percentage: grandTotal > 0 ? Math.round((d.total / grandTotal) * 100) : 0,
    })).sort((a, b) => b.total - a.total);

    return { byMethod, grandTotal: Math.round(grandTotal) };
  }

  async getReportTopGuests(from: string, to: string, limit: number = 50): Promise<any[]> {
    const periodRes = await db.select().from(reservations)
      .where(and(lte(reservations.checkInDate, to), gte(reservations.checkOutDate, from)));

    const guestMap = new Map<string, { stays: number; nights: number; revenue: number; lastVisit: string }>();
    for (const r of periodRes) {
      if (!r.guestId) continue;
      if (!guestMap.has(r.guestId)) guestMap.set(r.guestId, { stays: 0, nights: 0, revenue: 0, lastVisit: "" });
      const e = guestMap.get(r.guestId)!;
      e.stays++;
      e.nights += r.nights || 0;
      e.revenue += parseFloat(r.totalRoomAmount || "0");
      if (r.checkOutDate > e.lastVisit) e.lastVisit = r.checkOutDate as string;
    }

    const entries = Array.from(guestMap.entries()).sort((a, b) => b[1].revenue - a[1].revenue).slice(0, limit);
    const result: any[] = [];
    let rank = 0;
    for (const [guestId, data] of entries) {
      rank++;
      const guest = await db.select().from(guests).where(eq(guests.id, guestId)).then(g => g[0]);
      result.push({
        rank, guest: guest ? `${guest.lastName} ${guest.firstName}` : "-",
        code: guest?.codigo || "-", stays: data.stays, nights: data.nights,
        revenue: Math.round(data.revenue), lastVisit: data.lastVisit, segment: guest?.segment || "-",
      });
    }
    return result;
  }

  async getReportHousekeeping(from: string, to: string): Promise<any> {
    const tasks = await db.select().from(housekeepingTasks)
      .where(and(gte(housekeepingTasks.scheduledDate, from), lte(housekeepingTasks.scheduledDate, to)));

    const allTasks = tasks.length > 0 ? tasks : await db.select().from(housekeepingTasks);

    const byDate = new Map<string, { completed: number; pending: number; urgent: number }>();
    const byType = new Map<string, number>();

    for (const t of allTasks) {
      const dateStr = t.scheduledDate || new Date().toISOString().split("T")[0];
      if (!byDate.has(dateStr as string)) byDate.set(dateStr as string, { completed: 0, pending: 0, urgent: 0 });
      const e = byDate.get(dateStr as string)!;
      if (t.status === "completed" || t.status === "inspected") e.completed++;
      else e.pending++;
      if (t.priority === "urgent" || t.priority === "high") e.urgent++;

      const type = t.taskType || "other";
      byType.set(type, (byType.get(type) || 0) + 1);
    }

    return {
      daily: Array.from(byDate.entries()).map(([date, d]) => ({ date, ...d })).sort((a, b) => a.date.localeCompare(b.date)),
      byType: Array.from(byType.entries()).map(([type, count]) => ({ type, count })),
      totalCompleted: allTasks.filter(t => t.status === "completed" || t.status === "inspected").length,
      totalPending: allTasks.filter(t => t.status === "pending" || (t.status as string) === "assigned").length,
    };
  }

  async getReportRestaurant(from: string, to: string): Promise<any> {
    const orders = await db.select().from(restaurantOrders)
      .where(and(
        eq(restaurantOrders.status, "closed"),
        sql`DATE(${restaurantOrders.closedAt}) >= ${from}`,
        sql`DATE(${restaurantOrders.closedAt}) <= ${to}`
      ));
    const orderIds = orders.map(o => o.id);
    const items = orderIds.length > 0
      ? await db.select().from(orderItems).where(inArray(orderItems.orderId, orderIds))
      : [];
    const menuItemsList = await db.select().from(menuItems);
    const areas = await db.select().from(restaurantAreas);

    const menuMap = new Map(menuItemsList.map(m => [m.id, m]));
    const areaMap = new Map(areas.map(a => [a.id, a]));

    let totalRevenue = 0;
    let totalCovers = 0;
    const itemSales = new Map<string, { name: string; count: number; revenue: number }>();
    const areaRevenue = new Map<string, { name: string; orders: number; revenue: number; covers: number }>();

    for (const o of orders) {
      const orderTotal = items.filter(i => i.orderId === o.id).reduce((s, i) => s + parseFloat(i.subtotal || "0"), 0);
      totalRevenue += orderTotal;
      totalCovers += o.covers || 0;

      const table = o.tableId ? await db.select().from(restaurantTables).where(eq(restaurantTables.id, o.tableId)).then(t => t[0]) : null;
      const areaId = table?.areaId || "unknown";
      const area = areaMap.get(areaId);
      if (!areaRevenue.has(areaId)) areaRevenue.set(areaId, { name: area?.name || "Otro", orders: 0, revenue: 0, covers: 0 });
      const ae = areaRevenue.get(areaId)!;
      ae.orders++;
      ae.revenue += orderTotal;
      ae.covers += o.covers || 0;

      for (const i of items.filter(it => it.orderId === o.id)) {
        const mi = menuMap.get(i.menuItemId);
        const name = mi?.name || "Desconocido";
        if (!itemSales.has(i.menuItemId)) itemSales.set(i.menuItemId, { name, count: 0, revenue: 0 });
        const ie = itemSales.get(i.menuItemId)!;
        ie.count += i.quantity;
        ie.revenue += parseFloat(i.subtotal || "0");
      }
    }

    const topItems = Array.from(itemSales.values()).sort((a, b) => b.count - a.count).slice(0, 10);
    const byArea = Array.from(areaRevenue.values()).sort((a, b) => b.revenue - a.revenue);

    return {
      totalOrders: orders.length, totalRevenue: Math.round(totalRevenue), totalCovers,
      avgTicket: orders.length > 0 ? Math.round(totalRevenue / orders.length) : 0,
      topItems, byArea,
    };
  }

  async bulkCheckIn(groupId: string): Promise<{ processed: number; skipped: number; skippedRooms: string[] }> {
    const links = await db.select().from(groupReservationLinks)
      .where(eq(groupReservationLinks.groupId, groupId));

    let processed = 0;
    let skipped = 0;
    const skippedRooms: string[] = [];

    for (const link of links) {
      const [reservation] = await db.select().from(reservations)
        .where(eq(reservations.id, link.reservationId));

      if (!reservation || (reservation.status !== "confirmed" && reservation.status !== "web_checkin" && reservation.status !== "pending")) continue;

      const todayStr = getArgentinaToday();
      if (reservation.checkInDate > todayStr) {
        skipped++;
        continue;
      }

      const [room] = await db.select().from(rooms)
        .where(eq(rooms.id, reservation.roomId));

      if (!room) {
        skipped++;
        continue;
      }

      await db.update(reservations)
        .set({ status: "checked_in" })
        .where(eq(reservations.id, reservation.id));

      await db.update(rooms)
        .set({ status: "occupied" })
        .where(eq(rooms.id, room.id));

      processed++;
    }

    if (processed > 0) {
      await db.update(groups)
        .set({ status: "inhouse" as any })
        .where(eq(groups.id, groupId));
    }

    return { processed, skipped, skippedRooms };
  }

  async bulkCheckOut(groupId: string): Promise<{ processed: number; skipped: number; pendingBalance: Array<{ room: string; guestName: string; balance: number }> }> {
    const links = await db.select().from(groupReservationLinks)
      .where(eq(groupReservationLinks.groupId, groupId));

    let processed = 0;
    let skipped = 0;
    const pendingBalance: Array<{ room: string; guestName: string; balance: number }> = [];

    const [group] = await db.select().from(groups).where(eq(groups.id, groupId));

    for (const link of links) {
      const [reservation] = await db.select().from(reservations)
        .where(eq(reservations.id, link.reservationId));

      if (!reservation || reservation.status !== "checked_in") continue;

      const chargesList = await db.select().from(charges)
        .where(eq(charges.reservationId, reservation.id));
      const paymentsList = await db.select().from(payments)
        .where(eq(payments.reservationId, reservation.id));

      const totalCharges = chargesList.reduce((sum, c) => sum + parseFloat(c.amount || "0"), 0);
      const totalPayments = paymentsList.reduce((sum, p) => sum + parseFloat(p.amount || "0"), 0);
      const roomTotal = parseFloat(reservation.totalRoomAmount || "0");
      const balance = roomTotal + totalCharges - totalPayments;

      const [room] = await db.select().from(rooms)
        .where(eq(rooms.id, reservation.roomId));

      if (balance > 0.01) {
        skipped++;
        const [guest] = await db.select().from(guests)
          .where(eq(guests.id, reservation.guestId));
        pendingBalance.push({
          room: room?.roomNumber || reservation.roomId,
          guestName: guest ? `${guest.lastName} ${guest.firstName}` : "Sin nombre",
          balance,
        });
        continue;
      }

      await db.update(reservations)
        .set({ status: "checked_out" })
        .where(eq(reservations.id, reservation.id));

      await db.update(rooms)
        .set({ status: "dirty" })
        .where(eq(rooms.id, reservation.roomId));

      try {
        await db.insert(housekeepingTasks).values({
          id: randomUUID(),
          roomId: reservation.roomId,
          type: "checkout_clean",
          priority: "high",
          status: "pending",
          notes: `Check-out grupal — ${group?.name || groupId}`,
          createdAt: new Date(),
        } as any);
      } catch {}

      processed++;
    }

    const allLinks = await db.select().from(groupReservationLinks)
      .where(eq(groupReservationLinks.groupId, groupId));
    let allDone = true;
    for (const l of allLinks) {
      const [r] = await db.select().from(reservations).where(eq(reservations.id, l.reservationId));
      if (r && r.status !== "checked_out" && r.status !== "cancelled") {
        allDone = false;
        break;
      }
    }
    if (allDone && allLinks.length > 0) {
      await db.update(groups).set({ status: "finished" as any }).where(eq(groups.id, groupId));
    }

    return { processed, skipped, pendingBalance };
  }
  // ==================== Cash Register Module ====================

  async getCashConfigs(): Promise<CashRegisterConfig[]> {
    return db.select().from(cashRegisterConfigs).orderBy(asc(cashRegisterConfigs.area));
  }

  async updateCashConfig(area: string, data: Partial<InsertCashRegisterConfig>): Promise<CashRegisterConfig | undefined> {
    const [updated] = await db.update(cashRegisterConfigs)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(cashRegisterConfigs.area, area))
      .returning();
    return updated;
  }

  async getCashShifts(area?: string, status?: string): Promise<CashShift[]> {
    const conditions: any[] = [];
    if (area) conditions.push(eq(cashShifts.area, area));
    if (status) conditions.push(eq(cashShifts.status, status));
    return db.select().from(cashShifts)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(cashShifts.openedAt));
  }

  async getCurrentShift(area: string): Promise<CashShift | undefined> {
    const [shift] = await db.select().from(cashShifts)
      .where(and(eq(cashShifts.area, area), eq(cashShifts.status, "open")))
      .orderBy(desc(cashShifts.openedAt))
      .limit(1);
    return shift;
  }

  private async _nextShiftNumber(area: string): Promise<number> {
    // Argentina is always UTC-3 (no DST). We need "today midnight" in Argentina time.
    // e.g. 23:00 Argentina = 02:00 UTC next day — so we must NOT use server local midnight (UTC).
    const nowUTC = new Date();
    // Shift the timestamp 3 hours back to get the "Argentina date"
    const argDate = new Date(nowUTC.getTime() - 3 * 60 * 60 * 1000);
    // Argentina midnight expressed in UTC = that date at 03:00 UTC
    const todayArgMidnightUTC = new Date(
      Date.UTC(argDate.getUTCFullYear(), argDate.getUTCMonth(), argDate.getUTCDate(), 3, 0, 0, 0)
    );
    const rows = await db.select({ cnt: count() }).from(cashShifts)
      .where(and(eq(cashShifts.area, area), gte(cashShifts.openedAt, todayArgMidnightUTC)));
    return (rows[0]?.cnt || 0) + 1;
  }

  async openShift(data: InsertCashShift): Promise<CashShift> {
    const existing = await this.getCurrentShift(data.area);
    if (existing) throw new Error("Ya hay un turno abierto para esta área");
    const shiftNumber = await this._nextShiftNumber(data.area);
    const [shift] = await db.insert(cashShifts).values({
      id: randomUUID(),
      area: data.area,
      shiftNumber,
      openedBy: data.openedBy || null,
      notes: data.notes || null,
      openedAt: new Date(),
      status: "open",
      autoCreado: (data as any).autoCreado ?? false,
      turnoAnteriorId: (data as any).turnoAnteriorId ?? null,
      turnoTipo: (data as any).turnoTipo ?? null,
    }).returning();
    return shift;
  }

  async closeShift(
    shiftId: string,
    closedBy: string,
    efectivoContado: number = 0,
    operadorSiguiente: string | null = null,
    enviarAAdministracion: boolean = false,
    notes?: string,
    turnoTipo?: string | null,
  ): Promise<{ shift: CashShift; summary: CashClosingSummary; turnoNuevo: CashShift }> {
    const [shift] = await db.select().from(cashShifts).where(eq(cashShifts.id, shiftId));
    if (!shift) throw new Error("Turno no encontrado");
    if (shift.status !== "open") throw new Error("El turno ya está cerrado");

    // Update turnoTipo if provided and not already set
    if (turnoTipo && !shift.turnoTipo) {
      await db.update(cashShifts).set({ turnoTipo }).where(eq(cashShifts.id, shiftId));
      shift.turnoTipo = turnoTipo;
    }

    const movements = await db.select().from(cashMovements).where(
      and(eq(cashMovements.shiftId, shiftId), eq(cashMovements.anulado, false))
    );

    // Normaliza tanto valores en español como en inglés almacenados históricamente
    const methodNorm: Record<string, string> = {
      efectivo: "cash", cash: "cash",
      tarjeta_debito: "debit_card", debit_card: "debit_card",
      tarjeta_credito: "credit_card", credit_card: "credit_card",
      transferencia: "transfer", transfer: "transfer",
      mercadopago: "mercadopago",
      cuenta_corriente: "current_account", current_account: "current_account",
      cargo_habitacion: "room_charge", room_charge: "room_charge",
    };
    const totals: Record<string, number> = {
      cash: 0, debit_card: 0, credit_card: 0, transfer: 0,
      mercadopago: 0, current_account: 0, room_charge: 0,
    };
    let totalGeneral = 0;
    let transactionCount = 0;
    for (const m of movements) {
      if (m.movementType === "informational") continue; // solo registro, no impacta saldo
      const amt = parseFloat(m.amount);
      const sign = m.movementType === "expense" ? -1 : 1;
      const method = methodNorm[m.paymentMethod] ?? m.paymentMethod;
      if (totals[method] !== undefined) totals[method] += amt * sign;
      totalGeneral += amt * sign;
      transactionCount++;
    }

    const diferencia = efectivoContado - totals.cash;

    const [summary] = await db.insert(cashClosingSummaries).values({
      id: randomUUID(),
      shiftId,
      area: shift.area,
      totalCash: efectivoContado > 0 ? efectivoContado.toFixed(2) : totals.cash.toFixed(2),
      totalDebitCard: totals.debit_card.toFixed(2),
      totalCreditCard: totals.credit_card.toFixed(2),
      totalTransfer: totals.transfer.toFixed(2),
      totalMercadopago: totals.mercadopago.toFixed(2),
      totalCurrentAccount: totals.current_account.toFixed(2),
      totalRoomCharge: totals.room_charge.toFixed(2),
      totalGeneral: totalGeneral.toFixed(2),
      transactionCount,
      closedBy,
      notes: notes || (diferencia !== 0 ? `Diferencia efectivo: $${diferencia.toFixed(2)}` : null),
    }).returning();

    const [updatedShift] = await db.update(cashShifts)
      .set({ status: "closed", closedAt: new Date(), closedBy })
      .where(eq(cashShifts.id, shiftId))
      .returning();

    // Enviar efectivo a Caja de Administración si corresponde
    if (enviarAAdministracion && efectivoContado > 0) {
      try {
        const now = new Date();
        const fecha = now.toISOString().split("T")[0];
        const hora = `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
        await db.execute(sql`
          INSERT INTO admin_cash_movements (fecha, hora, tipo, concepto, importe, signo, area_origen, operador, anulado)
          VALUES (${fecha}, ${hora},
            ${"ingreso_" + shift.area},
            ${"Rendición " + shift.area.charAt(0).toUpperCase() + shift.area.slice(1) + " — Turno #" + updatedShift.shiftNumber + " (" + closedBy + ")"},
            ${efectivoContado.toFixed(2)}, '+', ${shift.area}, ${closedBy}, false)
        `);
      } catch (e) {
        console.warn("[CashShift] No se pudo registrar en Caja Admin:", (e as any).message);
      }
    }

    // Crear automáticamente el siguiente turno.
    // Usamos shiftNumber + 1 del turno que se cierra para evitar el bug de
    // medianoche: si el turno se cierra después de las 00:00 Argentina,
    // _nextShiftNumber contaría 0 turnos del "nuevo día" y volvería a 1.
    const nextNum = updatedShift.shiftNumber + 1;
    const [turnoNuevo] = await db.insert(cashShifts).values({
      id: randomUUID(),
      area: shift.area,
      shiftNumber: nextNum,
      openedBy: operadorSiguiente || null,
      openedAt: new Date(),
      status: "open",
      autoCreado: !operadorSiguiente,
      turnoAnteriorId: shiftId,
    }).returning();

    return { shift: updatedShift, summary, turnoNuevo };
  }

  async getOrCreateActiveTurno(area: string): Promise<CashShift> {
    const [turnoActivo] = await db.select().from(cashShifts)
      .where(and(eq(cashShifts.area, area), eq(cashShifts.status, "open")))
      .orderBy(desc(cashShifts.openedAt))
      .limit(1);

    if (turnoActivo) return turnoActivo;

    console.warn(`[CashShift] No había turno abierto para ${area}. Autocreando.`);
    const nextNum = await this._nextShiftNumber(area);
    const [turnoNuevo] = await db.insert(cashShifts).values({
      id: randomUUID(),
      area,
      shiftNumber: nextNum,
      openedBy: null,
      openedAt: new Date(),
      status: "open",
      autoCreado: true,
    }).returning();
    return turnoNuevo;
  }

  async initCashShifts(): Promise<void> {
    const areas = ["recepcion", "restaurant", "spa"];
    for (const area of areas) {
      const [existing] = await db.select().from(cashShifts)
        .where(and(eq(cashShifts.area, area), eq(cashShifts.status, "open")))
        .limit(1);
      if (!existing) {
        const nextNum = await this._nextShiftNumber(area);
        await db.insert(cashShifts).values({
          id: randomUUID(),
          area,
          shiftNumber: nextNum,
          openedBy: null,
          openedAt: new Date(),
          status: "open",
          autoCreado: true,
        });
        console.log(`[Init] Turno inicial creado para área: ${area}`);
      }
    }
  }

  async tomarTurno(shiftId: string, operador: string, turnoTipo?: string | null): Promise<CashShift> {
    const setValues: Record<string, any> = { openedBy: operador, autoCreado: false };
    if (turnoTipo) setValues.turnoTipo = turnoTipo;
    const [shift] = await db.update(cashShifts)
      .set(setValues)
      .where(and(eq(cashShifts.id, shiftId), eq(cashShifts.status, "open")))
      .returning();
    if (!shift) throw new Error("Turno no encontrado o ya cerrado");
    return shift;
  }

  async getAutocreadoShifts(): Promise<CashShift[]> {
    return db.select().from(cashShifts)
      .where(and(eq(cashShifts.status, "open"), eq(cashShifts.autoCreado, true)))
      .orderBy(desc(cashShifts.openedAt));
  }

  async getShiftDetail(shiftId: string): Promise<{ shift: CashShift; movements: CashMovement[]; summary: CashClosingSummary | null }> {
    const [shift] = await db.select().from(cashShifts).where(eq(cashShifts.id, shiftId));
    if (!shift) throw new Error("Turno no encontrado");
    const movements = await db.select().from(cashMovements)
      .where(eq(cashMovements.shiftId, shiftId))
      .orderBy(asc(cashMovements.createdAt));
    const [summary] = await db.select().from(cashClosingSummaries)
      .where(eq(cashClosingSummaries.shiftId, shiftId))
      .limit(1);
    return { shift, movements, summary: summary || null };
  }

  async getCashMovements(shiftId: string): Promise<CashMovement[]> {
    return db.select().from(cashMovements)
      .where(eq(cashMovements.shiftId, shiftId))
      .orderBy(desc(cashMovements.createdAt));
  }

  async createCashMovement(data: InsertCashMovement): Promise<CashMovement> {
    const [movement] = await db.insert(cashMovements).values({
      id: randomUUID(),
      ...data,
    }).returning();
    return movement;
  }

  async registerCashMovement(area: string, sourceType: string, sourceId: string | null, sourceLabel: string, paymentMethod: string, amount: string, movementType: string = "income", registeredBy?: string, receiptType?: string, paymentId?: string | null): Promise<CashMovement> {
    const turno = await this.getOrCreateActiveTurno(area);
    const [movement] = await db.insert(cashMovements).values({
      id: randomUUID(),
      shiftId: turno.id,
      area,
      sourceType,
      sourceId,
      sourceLabel,
      paymentMethod,
      amount,
      movementType,
      registeredBy: registeredBy || null,
      receiptType: receiptType || null,
      paymentId: paymentId || null,
    }).returning();
    return movement;
  }

  async getCashSummary(area?: string, from?: string, to?: string): Promise<any[]> {
    const conditions: any[] = [];
    if (area) conditions.push(eq(cashClosingSummaries.area, area));
    if (from) conditions.push(gte(cashClosingSummaries.closedAt, new Date(from)));
    if (to) {
      const toDate = new Date(to);
      toDate.setDate(toDate.getDate() + 1);
      conditions.push(lt(cashClosingSummaries.closedAt, toDate));
    }

    const summaries = await db.select().from(cashClosingSummaries)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(cashClosingSummaries.closedAt));

    const results = [];
    for (const s of summaries) {
      const [shift] = await db.select().from(cashShifts).where(eq(cashShifts.id, s.shiftId));
      results.push({ ...s, shift });
    }
    return results;
  }
  async getAccountMovements(entityType: AccountEntityType, entityId: string): Promise<(AccountMovement & { saldoPendiente?: number })[]> {
    const rows = await db.select()
      .from(accountMovements)
      .where(
        and(
          eq(accountMovements.entityType, entityType),
          eq(accountMovements.entityId, entityId)
        )
      )
      .orderBy(desc(accountMovements.date), desc(accountMovements.createdAt));

    // Enrich cargo rows with their pending balance (amount - allocated)
    const cargoIds = rows.filter(r => r.type === "cargo").map(r => r.id);
    if (cargoIds.length === 0) return rows;

    const allocs = await db.select()
      .from(accountMovementAllocations)
      .where(inArray(accountMovementAllocations.cargoId, cargoIds));

    const allocatedByCargo = new Map<string, number>();
    for (const a of allocs) {
      allocatedByCargo.set(a.cargoId, (allocatedByCargo.get(a.cargoId) || 0) + parseFloat(a.amount));
    }

    return rows.map(r => {
      if (r.type !== "cargo") return r;
      const allocated = allocatedByCargo.get(r.id) || 0;
      const saldoPendiente = Math.round((parseFloat(r.amount) - allocated) * 100) / 100;
      return { ...r, saldoPendiente };
    });
  }

  async getAccountBalance(entityType: AccountEntityType, entityId: string): Promise<number> {
    const movements = await this.getAccountMovements(entityType, entityId);
    return movements.reduce((sum, m) => sum + parseFloat(m.amount), 0);
  }

  async getAccountMovementsByReservation(reservationId: string): Promise<AccountMovement[]> {
    return await db.select()
      .from(accountMovements)
      .where(eq(accountMovements.reservationId, reservationId))
      .orderBy(desc(accountMovements.createdAt));
  }

  async createAccountMovement(data: InsertAccountMovement): Promise<AccountMovement> {
    const [created] = await db.insert(accountMovements).values(data as any).returning();
    return created;
  }

  async getPendingCharges(entityType: AccountEntityType, entityId: string): Promise<(AccountMovement & { saldoPendiente: number })[]> {
    const movements = await db.select()
      .from(accountMovements)
      .where(
        and(
          eq(accountMovements.entityType, entityType),
          eq(accountMovements.entityId, entityId),
          eq(accountMovements.type, "cargo")
        )
      )
      .orderBy(asc(accountMovements.date), asc(accountMovements.createdAt));

    if (movements.length === 0) return [];

    const cargoIds = movements.map(m => m.id);
    const allocations = await db.select()
      .from(accountMovementAllocations)
      .where(inArray(accountMovementAllocations.cargoId, cargoIds));

    const allocatedByCargo = new Map<string, number>();
    for (const a of allocations) {
      allocatedByCargo.set(a.cargoId, (allocatedByCargo.get(a.cargoId) || 0) + parseFloat(a.amount));
    }

    return movements
      .map(m => {
        const cargoAmount = parseFloat(m.amount);
        const allocated = allocatedByCargo.get(m.id) || 0;
        const saldoPendiente = Math.round((cargoAmount - allocated) * 100) / 100;
        return { ...m, saldoPendiente };
      })
      .filter(m => m.saldoPendiente > 0.009);
  }

  async createPaymentWithAllocations(
    entityType: AccountEntityType,
    entityId: string,
    data: { date: string; description: string; amount: string; reference: string | null; paymentMethod?: string | null; retentions: AccountRetention[] | null; createdBy: string | null; guestName?: string | null },
    allocations: { cargoId: string; amount: string }[]
  ): Promise<{ movement: AccountMovement; allocations: AccountMovementAllocation[] }> {
    return await db.transaction(async (tx) => {
      const validationError = (message: string) => Object.assign(new Error(message), { statusCode: 400 });
      const paymentAmount = Math.abs(parseFloat(data.amount));
      const normalizedAllocations = allocations.map((allocation) => ({
        cargoId: String(allocation.cargoId || ""),
        amount: parseFloat(allocation.amount),
      }));
      const allocationsTotal = normalizedAllocations.reduce((sum, allocation) => sum + allocation.amount, 0);

      if (!Number.isFinite(paymentAmount) || paymentAmount <= 0) {
        throw validationError("Monto inválido");
      }
      if (normalizedAllocations.some((allocation) => !allocation.cargoId || !Number.isFinite(allocation.amount) || allocation.amount <= 0)) {
        throw validationError("Hay una asignación con datos inválidos");
      }
      if (normalizedAllocations.length > 0 && Math.abs(allocationsTotal - paymentAmount) > 0.01) {
        throw validationError("El total aplicado debe coincidir con los comprobantes seleccionados");
      }

      if (normalizedAllocations.length > 0) {
        const cargoIds = Array.from(new Set(normalizedAllocations.map((allocation) => allocation.cargoId)));
        if (cargoIds.length !== normalizedAllocations.length) {
          throw validationError("Un comprobante no puede asignarse más de una vez en el mismo pago");
        }
        const idsSql = sql.join(cargoIds.map((id) => sql`${id}`), sql`, `);

        // Lock selected cargos before calculating their remaining balance. A
        // concurrent payment waits here, then sees the first payment's
        // allocations and is rejected instead of overpaying the cargo.
        const lockedCargosResult = await tx.execute(sql`
          SELECT id, amount::numeric AS amount
          FROM account_movements
          WHERE id IN (${idsSql})
            AND entity_type = ${entityType}
            AND entity_id = ${entityId}
            AND type = 'cargo'
          ORDER BY id
          FOR UPDATE
        `);
        const lockedCargos = lockedCargosResult.rows as { id: string; amount: string }[];
        if (lockedCargos.length !== cargoIds.length) {
          throw validationError("Uno de los comprobantes seleccionados ya no está pendiente");
        }

        const allocatedResult = await tx.execute(sql`
          SELECT cargo_id, COALESCE(SUM(amount::numeric), 0) AS allocated
          FROM account_movement_allocations
          WHERE cargo_id IN (${idsSql})
          GROUP BY cargo_id
        `);
        const cargoById = new Map(lockedCargos.map((cargo) => [cargo.id, parseFloat(cargo.amount)]));
        const allocatedByCargo = new Map(
          (allocatedResult.rows as { cargo_id: string; allocated: string }[])
            .map((row) => [row.cargo_id, parseFloat(row.allocated)])
        );

        for (const allocation of normalizedAllocations) {
          const remaining = (cargoById.get(allocation.cargoId) ?? 0) - (allocatedByCargo.get(allocation.cargoId) ?? 0);
          if (allocation.amount > remaining + 0.01) {
            throw validationError("El importe aplicado supera el saldo pendiente del comprobante");
          }
        }
      }

      const [movement] = await tx.insert(accountMovements).values({
        entityType,
        entityId,
        date: data.date,
        type: "pago",
        description: data.description,
        amount: data.amount,
        reference: data.reference,
        paymentMethod: data.paymentMethod ?? null,
        retentions: data.retentions,
        createdBy: data.createdBy,
        guestName: data.guestName ?? null,
      } as any).returning();

      const createdAllocations: AccountMovementAllocation[] = [];
      for (const alloc of allocations) {
        const [created] = await tx.insert(accountMovementAllocations).values({
          pagoId: movement.id,
          cargoId: alloc.cargoId,
          amount: alloc.amount,
        } as any).returning();
        createdAllocations.push(created);
      }

      return { movement, allocations: createdAllocations };
    });
  }

  async getAccountMovementAllocations(pagoId: string): Promise<AccountMovementAllocation[]> {
    return await db.select()
      .from(accountMovementAllocations)
      .where(eq(accountMovementAllocations.pagoId, pagoId));
  }

  async getAccountSummary(): Promise<{
    companies: { id: string; name: string; balance: number; lastMovement: string | null }[];
    agencies: { id: string; name: string; balance: number; lastMovement: string | null }[];
    guests: { id: string; name: string; balance: number; lastMovement: string | null }[];
  }> {
    // Balance de empresas: usamos account_movements como fuente de verdad (igual que agencias),
    // porque el listado de movimientos muestra account_movements y el saldo debe coincidir.
    // La fórmula anterior (basada en reservations.company_id) divergía de los movimientos reales
    // en producción cuando los cargos se creaban sin company_id seteado en la reserva.
    const companiesRes = await db.execute(sql`
      SELECT c.id,
             COALESCE(NULLIF(c.nombre_fantasia, ''), c.razon_social) AS name,
             COALESCE(SUM(m.amount::numeric), 0)                     AS balance,
             MAX(m.date::text)                                        AS last_movement
      FROM companies c
      LEFT JOIN account_movements m ON m.entity_id = c.id AND m.entity_type = 'company'
      WHERE c.is_active = 'true'
      GROUP BY c.id, c.nombre_fantasia, c.razon_social
      HAVING COALESCE(SUM(m.amount::numeric), 0) <> 0
      ORDER BY balance DESC
    `);

    const agenciesRes = await db.execute(sql`
      SELECT a.id,
             COALESCE(NULLIF(a.nombre_fantasia, ''), a.razon_social) AS name,
             COALESCE(SUM(m.amount::numeric), 0)                     AS balance,
             MAX(m.date::text)                                        AS last_movement
      FROM agencies a
      LEFT JOIN account_movements m ON m.entity_id = a.id AND m.entity_type = 'agency'
      WHERE a.is_active = 'true'
      GROUP BY a.id, a.nombre_fantasia, a.razon_social
      HAVING COALESCE(SUM(m.amount::numeric), 0) <> 0
      ORDER BY balance DESC
    `);

    const guestsRes = await db.execute(sql`
      SELECT g.id,
             g.last_name || ' ' || g.first_name AS name,
             SUM(m.amount::numeric)              AS balance,
             MAX(m.date::text)                   AS last_movement
      FROM account_movements m
      JOIN guests g ON g.id = m.entity_id
      WHERE m.entity_type = 'guest'
      GROUP BY g.id, g.last_name, g.first_name
      HAVING SUM(m.amount::numeric) <> 0
      ORDER BY balance DESC
    `);

    return {
      companies: (companiesRes.rows as any[]).map(r => ({ id: r.id, name: r.name, balance: parseFloat(r.balance), lastMovement: r.last_movement })),
      agencies:  (agenciesRes.rows as any[]).map(r => ({ id: r.id, name: r.name, balance: parseFloat(r.balance), lastMovement: r.last_movement })),
      guests:    (guestsRes.rows as any[]).map(r => ({ id: r.id, name: r.name, balance: parseFloat(r.balance), lastMovement: r.last_movement })),
    };
  }

  // ==================== MOTOR FINANCIERO — FOLIOS ====================

  private async generateFolioCodigo(entityType: FolioEntityType): Promise<string> {
    const prefixes: Record<FolioEntityType, string> = {
      reservation: "RS",
      restaurant_order: "OR",
      spa_account: "SP",
      group: "GR",
      event: "EV",
      company: "CO",
      agency: "AG",
    };
    const prefix = prefixes[entityType] ?? "FL";
    const [row] = await db.select({ cnt: sql<number>`count(*)` }).from(folios)
      .where(eq(folios.entityType, entityType));
    const seq = (Number(row?.cnt ?? 0) + 1).toString().padStart(6, "0");
    return `${prefix}-${seq}`;
  }

  async getOrCreateFolio(entityType: FolioEntityType, entityId: string): Promise<Folio> {
    const [existing] = await db.select().from(folios)
      .where(and(eq(folios.entityType, entityType), eq(folios.entityId, entityId)));
    if (existing) return existing;
    const codigo = await this.generateFolioCodigo(entityType);
    const [created] = await db.insert(folios).values({
      codigo,
      entityType,
      entityId,
      status: "open",
      totalCharges: "0",
      totalPayments: "0",
      balance: "0",
    }).returning();
    return created;
  }

  async getFolioByEntity(entityType: FolioEntityType, entityId: string): Promise<Folio | null> {
    const [row] = await db.select().from(folios)
      .where(and(eq(folios.entityType, entityType), eq(folios.entityId, entityId)));
    return row ?? null;
  }

  async getFolioById(id: string): Promise<Folio | null> {
    const [row] = await db.select().from(folios).where(eq(folios.id, id));
    return row ?? null;
  }

  async getFolioWithMovements(folioId: string): Promise<FolioWithMovements | null> {
    const folio = await this.getFolioById(folioId);
    if (!folio) return null;
    const movements = await db.select().from(folioMovements)
      .where(eq(folioMovements.folioId, folioId))
      .orderBy(asc(folioMovements.createdAt));
    return { ...folio, movements };
  }

  async getFolioWithMovementsByEntity(entityType: FolioEntityType, entityId: string): Promise<FolioWithMovements | null> {
    const folio = await this.getFolioByEntity(entityType, entityId);
    if (!folio) return null;
    return this.getFolioWithMovements(folio.id);
  }

  async recalcFolioBalance(folioId: string): Promise<Folio> {
    const chargeTypes: FolioMovementType[] = ["charge", "transfer_in"];
    const paymentTypes: FolioMovementType[] = ["payment", "advance", "discount", "transfer_out", "void"];
    const [chargesRow] = await db.select({ total: sql<string>`COALESCE(SUM(amount::numeric), 0)` })
      .from(folioMovements).where(and(
        eq(folioMovements.folioId, folioId),
        inArray(folioMovements.type, chargeTypes),
      ));
    const [paymentsRow] = await db.select({ total: sql<string>`COALESCE(SUM(amount::numeric), 0)` })
      .from(folioMovements).where(and(
        eq(folioMovements.folioId, folioId),
        inArray(folioMovements.type, paymentTypes),
      ));
    const totalCharges = parseFloat(chargesRow?.total ?? "0");
    const totalPayments = parseFloat(paymentsRow?.total ?? "0");
    const balance = totalCharges - totalPayments;
    const [updated] = await db.update(folios).set({
      totalCharges: totalCharges.toFixed(2),
      totalPayments: totalPayments.toFixed(2),
      balance: balance.toFixed(2),
    }).where(eq(folios.id, folioId)).returning();
    return updated;
  }

  async addFolioCharge(
    entityType: FolioEntityType,
    entityId: string,
    amount: number,
    description: string,
    sourceType?: string,
    sourceId?: string,
    registeredBy?: string,
  ): Promise<FolioMovement> {
    const folio = await this.getOrCreateFolio(entityType, entityId);

    // Deduplication guard: prevent duplicate movements on payment retry.
    // Primary key: (folioId, type, sourceType, sourceId, description) when both
    // sourceType and sourceId are present — sourceId is typically the upstream
    // record's own id (charge.id, item.id, etc.), and description breaks ties
    // for the few cases where multiple distinct movements share an entity-level
    // sourceId (e.g. room/early/late charges all reference the reservation id).
    // Fallback (no sourceId): (folioId, type, description, amount).
    const dupCondition = (sourceType != null && sourceId != null)
      ? and(
          eq(folioMovements.folioId, folio.id),
          eq(folioMovements.type, "charge"),
          eq(folioMovements.sourceType, sourceType),
          eq(folioMovements.sourceId, sourceId),
          eq(folioMovements.description, description),
        )
      : and(
          eq(folioMovements.folioId, folio.id),
          eq(folioMovements.type, "charge"),
          eq(folioMovements.description, description),
          eq(folioMovements.amount, amount.toFixed(2)),
        );
    const [existing] = await db.select().from(folioMovements).where(dupCondition).limit(1);
    if (existing) {
      console.warn(`[Folio] Duplicate charge skipped — folioId=${folio.id} description="${description}" amount=${amount} sourceType=${sourceType ?? "N/A"} sourceId=${sourceId ?? "N/A"}`);
      return existing;
    }

    const [movement] = await db.insert(folioMovements).values({
      folioId: folio.id,
      type: "charge",
      amount: amount.toFixed(2),
      description,
      sourceType: sourceType ?? null,
      sourceId: sourceId ?? null,
      registeredBy: registeredBy ?? null,
    }).returning();
    await this.recalcFolioBalance(folio.id);
    return movement;
  }

  async addFolioPayment(
    entityType: FolioEntityType,
    entityId: string,
    amount: number,
    description: string,
    paymentMethod: string,
    sourceType?: string,
    sourceId?: string,
    cashMovementId?: string,
    registeredBy?: string,
    receiptType?: string,
  ): Promise<FolioMovement> {
    const folio = await this.getOrCreateFolio(entityType, entityId);

    // Deduplication guard: prevent duplicate movements on payment retry.
    // Primary key: (folioId, type, sourceType, sourceId, description) when both
    // sourceType and sourceId are present — sourceId is typically the upstream
    // record's own id (payment.id, etc.), and description breaks ties for the
    // few cases where multiple distinct payments share an entity-level sourceId
    // (e.g. multi-split restaurant payments all reference the same order id).
    // Fallback (no sourceId): (folioId, type, description, amount).
    const dupCondition = (sourceType != null && sourceId != null)
      ? and(
          eq(folioMovements.folioId, folio.id),
          eq(folioMovements.type, "payment"),
          eq(folioMovements.sourceType, sourceType),
          eq(folioMovements.sourceId, sourceId),
          eq(folioMovements.description, description),
        )
      : and(
          eq(folioMovements.folioId, folio.id),
          eq(folioMovements.type, "payment"),
          eq(folioMovements.description, description),
          eq(folioMovements.amount, amount.toFixed(2)),
        );
    const [existing] = await db.select().from(folioMovements).where(dupCondition).limit(1);
    if (existing) {
      console.warn(`[Folio] Duplicate payment skipped — folioId=${folio.id} description="${description}" amount=${amount} sourceType=${sourceType ?? "N/A"} sourceId=${sourceId ?? "N/A"}`);
      return existing;
    }

    const [movement] = await db.insert(folioMovements).values({
      folioId: folio.id,
      type: "payment",
      amount: amount.toFixed(2),
      description,
      paymentMethod,
      sourceType: sourceType ?? null,
      sourceId: sourceId ?? null,
      cashMovementId: cashMovementId ?? null,
      registeredBy: registeredBy ?? null,
      receiptType: receiptType ?? null,
    }).returning();
    await this.recalcFolioBalance(folio.id);
    return movement;
  }

  async addFolioAdjustment(
    folioId: string,
    type: FolioMovementType,
    amount: number,
    description: string,
    registeredBy?: string,
    voidedMovementId?: string,
    voidReason?: string,
  ): Promise<FolioMovement> {
    // Deduplication guard: if this adjustment reverses a specific movement
    // (voidedMovementId is set), use that as the unique key so an NC retry
    // can't insert a second reversal for the same voided movement.
    // Fallback (no voidedMovementId): match on (folioId, type, description, amount).
    const dupCondition = voidedMovementId != null
      ? and(
          eq(folioMovements.folioId, folioId),
          eq(folioMovements.type, type),
          eq(folioMovements.voidedMovementId, voidedMovementId),
        )
      : and(
          eq(folioMovements.folioId, folioId),
          eq(folioMovements.type, type),
          eq(folioMovements.description, description),
          eq(folioMovements.amount, amount.toFixed(2)),
        );
    const [existing] = await db.select().from(folioMovements).where(dupCondition).limit(1);
    if (existing) {
      console.warn(`[Folio] Duplicate adjustment skipped — folioId=${folioId} type=${type} description="${description}" amount=${amount} voidedMovementId=${voidedMovementId ?? "N/A"}`);
      return existing;
    }

    const [movement] = await db.insert(folioMovements).values({
      folioId,
      type,
      amount: amount.toFixed(2),
      description,
      registeredBy: registeredBy ?? null,
      voidedMovementId: voidedMovementId ?? null,
      voidReason: voidReason ?? null,
    }).returning();
    await this.recalcFolioBalance(folioId);
    return movement;
  }

  async closeFolio(folioId: string, closedBy: string): Promise<Folio> {
    const updated = await this.recalcFolioBalance(folioId);
    const [closed] = await db.update(folios).set({
      status: "closed",
      closedAt: new Date(),
      closedBy,
    }).where(eq(folios.id, folioId)).returning();
    return closed;
  }

  async listFolios(entityType?: FolioEntityType, status?: FolioStatus): Promise<Folio[]> {
    const conditions: any[] = [];
    if (entityType) conditions.push(eq(folios.entityType, entityType));
    if (status) conditions.push(eq(folios.status, status));
    return db.select().from(folios)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(folios.openedAt));
  }

  // ── Gift Vouchers ───────────────────────────────────────────────────────────

  async getGiftVouchers(filters?: { status?: string; area?: string; search?: string }): Promise<GiftVoucher[]> {
    const conditions: any[] = [];
    if (filters?.status && filters.status !== "all") {
      conditions.push(eq(giftVouchers.status, filters.status as any));
    }
    if (filters?.area && filters.area !== "all") {
      conditions.push(eq(giftVouchers.area, filters.area as any));
    }
    if (filters?.search) {
      const term = `%${filters.search}%`;
      conditions.push(
        or(
          ilike(giftVouchers.voucherCode, term),
          ilike(giftVouchers.buyerName, term),
          ilike(giftVouchers.beneficiaryName, term),
          ilike(giftVouchers.description, term),
        )
      );
    }
    return db.select().from(giftVouchers)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(giftVouchers.issuedAt));
  }

  async getGiftVoucher(id: string): Promise<GiftVoucher | undefined> {
    const [v] = await db.select().from(giftVouchers).where(eq(giftVouchers.id, id));
    return v;
  }

  async getGiftVoucherByCode(code: string): Promise<GiftVoucher | undefined> {
    const [v] = await db.select().from(giftVouchers).where(eq(giftVouchers.voucherCode, code));
    return v;
  }

  async createGiftVoucher(data: InsertGiftVoucher): Promise<GiftVoucher> {
    const voucher: typeof giftVouchers.$inferInsert = {
      ...data,
      area: parseGiftVoucherArea(data.area),
      status: data.status === undefined ? undefined : parseGiftVoucherStatus(data.status),
      valueType: data.valueType === undefined ? undefined : parseGiftVoucherValueType(data.valueType),
    };
    const [v] = await db.insert(giftVouchers).values(voucher).returning();
    return v;
  }

  async updateGiftVoucher(id: string, data: Partial<InsertGiftVoucher>): Promise<GiftVoucher | undefined> {
    const { area, status, valueType, ...voucherData } = data;
    const voucher: Partial<typeof giftVouchers.$inferInsert> = {
      ...voucherData,
      ...(area === undefined ? {} : { area: parseGiftVoucherArea(area) }),
      ...(status === undefined ? {} : { status: parseGiftVoucherStatus(status) }),
      ...(valueType === undefined ? {} : { valueType: parseGiftVoucherValueType(valueType) }),
    };
    const [v] = await db.update(giftVouchers).set(voucher).where(eq(giftVouchers.id, id)).returning();
    return v;
  }

  async markGiftVoucherUsed(id: string, usedBy: string, usedNotes?: string): Promise<GiftVoucher | undefined> {
    const [v] = await db.update(giftVouchers).set({
      status: "usado",
      usedAt: new Date(),
      usedBy,
      usedNotes: usedNotes ?? null,
    }).where(eq(giftVouchers.id, id)).returning();
    return v;
  }

  async deleteGiftVoucher(id: string): Promise<boolean> {
    const result = await db.delete(giftVouchers).where(eq(giftVouchers.id, id)).returning();
    return result.length > 0;
  }

  async generateVoucherCode(): Promise<string> {
    const year = new Date().getFullYear();
    const prefix = `VCHR-${year}-`;
    // Use MAX of the numeric suffix so gaps from deletions don't cause duplicate-key errors.
    const result = await db.execute(
      sql`SELECT COALESCE(MAX(CAST(RIGHT(voucher_code, 4) AS INTEGER)), 0)::text AS max_seq
          FROM gift_vouchers WHERE voucher_code LIKE ${prefix + '%'}`
    );
    const lastSeq = parseInt((result.rows[0] as any).max_seq ?? "0", 10);
    return `${prefix}${String(lastSeq + 1).padStart(4, "0")}`;
  }

  // ── Toma de Inventario ────────────────────────────────────────────────────────

  async getInventoryCounts(): Promise<any[]> {
    const rows = await db.execute(sql`
      SELECT
        ic.*,
        COUNT(ici.id)::int                                                                   AS total_items,
        COUNT(CASE WHEN ici.actual_stock IS NOT NULL THEN 1 END)::int                        AS counted_items,
        COUNT(CASE WHEN ici.actual_stock IS NOT NULL
                    AND ABS(ici.actual_stock::numeric - ici.expected_stock::numeric) > 0.001
                   THEN 1 END)::int                                                          AS items_with_diff
      FROM inventory_counts ic
      LEFT JOIN inventory_count_items ici ON ic.id = ici.count_id
      GROUP BY ic.id
      ORDER BY ic.created_at DESC
    `);
    return rows.rows;
  }

  async createInventoryCount(data: { date: string; area?: string; notes?: string; createdBy?: string }): Promise<any> {
    const countResult = await db.execute(sql`
      INSERT INTO inventory_counts (date, area, notes, created_by)
      VALUES (${data.date}, ${data.area || null}, ${data.notes || null}, ${data.createdBy || null})
      RETURNING *
    `);
    const count = countResult.rows[0] as any;

    const itemsResult = data.area
      ? await db.execute(sql`
          SELECT ii.id, ii.name, ii.unit, ii.current_stock::numeric AS current_stock
          FROM inventory_items ii
          LEFT JOIN item_categories ic ON ii.category_id = ic.id
          WHERE ii.is_active = 'true' AND ic.area = ${data.area}
          ORDER BY ii.name ASC
        `)
      : await db.execute(sql`
          SELECT ii.id, ii.name, ii.unit, ii.current_stock::numeric AS current_stock
          FROM inventory_items ii
          WHERE ii.is_active = 'true'
          ORDER BY ii.name ASC
        `);

    for (const item of itemsResult.rows as any[]) {
      await db.execute(sql`
        INSERT INTO inventory_count_items (count_id, item_id, item_name, unit, expected_stock)
        VALUES (${count.id}, ${item.id}, ${item.name}, ${item.unit}, ${item.current_stock ?? 0})
      `);
    }
    return count;
  }

  async getInventoryCountWithItems(id: string): Promise<any | null> {
    const countResult = await db.execute(sql`SELECT * FROM inventory_counts WHERE id = ${id}`);
    if (!countResult.rows.length) return null;
    const count = countResult.rows[0] as any;

    const itemsResult = await db.execute(sql`
      SELECT ici.*, ii.sku, ii.cost_price::numeric AS cost_price
      FROM inventory_count_items ici
      LEFT JOIN inventory_items ii ON ici.item_id = ii.id
      WHERE ici.count_id = ${id}
      ORDER BY ici.item_name ASC
    `);
    return { ...count, items: itemsResult.rows };
  }

  async updateInventoryCountItem(countId: string, itemId: string, actualStock: number | null, notes?: string): Promise<void> {
    await db.execute(sql`
      UPDATE inventory_count_items
      SET actual_stock = ${actualStock}, notes = ${notes ?? null}
      WHERE count_id = ${countId} AND item_id = ${itemId}
    `);
  }

  async closeInventoryCount(id: string, closedBy: string): Promise<{ adjustments: number }> {
    const itemsResult = await db.execute(sql`
      SELECT * FROM inventory_count_items
      WHERE count_id = ${id} AND actual_stock IS NOT NULL
    `);

    let adjustments = 0;
    for (const item of itemsResult.rows as any[]) {
      const expected = parseFloat(item.expected_stock);
      const actual = parseFloat(item.actual_stock);
      const diff = actual - expected;
      if (Math.abs(diff) < 0.001) continue;

      const curResult = await db.execute(sql`SELECT current_stock FROM inventory_items WHERE id = ${item.item_id}`);
      const current = parseFloat((curResult.rows[0] as any)?.current_stock ?? "0");
      const newStock = Math.max(0, current + diff);

      await db.execute(sql`
        INSERT INTO stock_movements (item_id, movement_type, quantity, previous_stock, new_stock, notes, created_at, created_by, source_type, source_id)
        VALUES (
          ${item.item_id}, 'ajuste', ${Math.abs(diff)}, ${current}, ${newStock},
          ${'Ajuste por toma de inventario'}, now(), ${closedBy}, 'inventory_count', ${id}
        )
      `);
      await db.execute(sql`UPDATE inventory_items SET current_stock = ${newStock} WHERE id = ${item.item_id}`);
      adjustments++;
    }

    await db.execute(sql`
      UPDATE inventory_counts SET status = 'cerrado', closed_at = now(), closed_by = ${closedBy}
      WHERE id = ${id}
    `);
    return { adjustments };
  }
}

export const storage = new DatabaseStorage();
