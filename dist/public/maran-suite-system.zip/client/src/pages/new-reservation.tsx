import { useState, useMemo, useEffect } from "react";
import { fmtMoney, getArgentinaToday, toArgentinaDateStr } from "@/lib/utils";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import {
  CalendarPlus,
  User,
  Building2,
  DoorOpen,
  Calendar,
  DollarSign,
  Check,
  CheckCircle2,
  AlertCircle,
  Sunrise,
  Sunset,
  ShoppingCart,
  XCircle,
  Plus,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { GuestSelector, CompanySelector, AgencySelector } from "@/components/entity-selector";
import type { Guest, Company, Agency, RoomType, RoomWithType, RatePlan, InsertGuest, InsertCompany, InsertAgency } from "@shared/schema";

export default function NewReservationPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const search = useSearch();

  const searchParams = new URLSearchParams(search);
  const prefilledRoomId = searchParams.get("roomId") || "";
  const prefilledRoomTypeId = searchParams.get("roomTypeId") || "";
  const prefilledDate = searchParams.get("date") || "";
  const isFromPlanning = !!prefilledRoomId;

  const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [selectedAgency, setSelectedAgency] = useState<Agency | null>(null);
  const [selectedRoomTypeId, setSelectedRoomTypeId] = useState<string>(prefilledRoomTypeId);
  const [selectedRoomId, setSelectedRoomId] = useState<string>(prefilledRoomId);
  const [selectedRatePlanId, setSelectedRatePlanId] = useState<string>("");
  const [checkInDate, setCheckInDate] = useState<string>(() => {
    if (prefilledDate) return prefilledDate;
    return getArgentinaToday();
  });
  const [checkOutDate, setCheckOutDate] = useState<string>(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return toArgentinaDateStr(tomorrow);
  });
  const [numberOfGuests, setNumberOfGuests] = useState<number>(1);
  const [notes, setNotes] = useState<string>("");
  const [discountType, setDiscountType] = useState<string>("none");
  const [discountValue, setDiscountValue] = useState<string>("0");
  const [bedTypeNotes, setBedTypeNotes] = useState<string>("MAT");
  const [earlyCheckIn, setEarlyCheckIn] = useState(false);
  const [earlyCheckInTime, setEarlyCheckInTime] = useState("");
  const [earlyCheckInCharge, setEarlyCheckInCharge] = useState("");
  const [lateCheckOut, setLateCheckOut] = useState(false);
  const [lateCheckOutTime, setLateCheckOutTime] = useState("");
  const [lateCheckOutCharge, setLateCheckOutCharge] = useState("");
  const [specialRateReason, setSpecialRateReason] = useState<string>("");
  const [specialRateAmount, setSpecialRateAmount] = useState<string>("");

  const bedConfigOptions = [
    { value: "MAT", label: "Matrimonial" },
    { value: "TWIN", label: "Twin (2 individuales)" },
    { value: "MAT_CC", label: "Matrimonial + Cama chica" },
    { value: "TWIN_CC", label: "Twin + Cama chica" },
    { value: "MAT_EXTRA", label: "Matrimonial + Extra" },
    { value: "MAT_CC_EXTRA", label: "Matrimonial + CC + Extra" },
  ];

  const { data: chargeTypesData = [] } = useQuery<{ id: string; label: string; description: string; defaultAmount: string; category: string; allowRecurring: boolean }[]>({
    queryKey: ["/api/charge-types"],
  });
  const nrChargePresets = [
    ...chargeTypesData.map(ct => ({ label: ct.label, description: ct.description, amount: String(ct.defaultAmount), category: ct.category, allowRecurring: ct.allowRecurring ?? false })),
    { label: "Cargo personalizado", description: "", amount: "", category: "otros", allowRecurring: false },
  ];
  const [pendingCharges, setPendingCharges] = useState<Array<{ description: string; amount: string; category: string; quantity: number; isRecurring?: boolean }>>([]);
  const [showNrChargeForm, setShowNrChargeForm] = useState(false);
  const [nrChargePresetLabel, setNrChargePresetLabel] = useState("");
  const [nrChargeDesc, setNrChargeDesc] = useState("");
  const [nrChargeAmount, setNrChargeAmount] = useState("");
  const [nrChargeQty, setNrChargeQty] = useState(1);
  const [nrChargeCategory, setNrChargeCategory] = useState("otros");
  const [nrChargeRecurring, setNrChargeRecurring] = useState(false);

  const { data: roomTypes } = useQuery<RoomType[]>({
    queryKey: ["/api/room-types"],
  });

  const { data: rooms } = useQuery<RoomWithType[]>({
    queryKey: ["/api/rooms"],
  });

  const { data: ratePlans } = useQuery<RatePlan[]>({
    queryKey: ["/api/rate-plans/by-room-type", selectedRoomTypeId],
    queryFn: async () => {
      if (!selectedRoomTypeId) return [];
      const res = await fetch(`/api/rate-plans/by-room-type/${selectedRoomTypeId}`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!selectedRoomTypeId,
  });

  const { data: allReservations = [] } = useQuery<any[]>({
    queryKey: ["/api/reservations"],
  });

  const { data: maintenanceBlocks = [] } = useQuery<{ roomId: string; blockFrom: string; blockTo: string }[]>({
    queryKey: ["/api/maintenance/blocks"],
  });

  const { data: companies } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const handleGuestSelect = (guest: Guest) => {
    setSelectedGuest(guest);
    if (guest.companyId && companies) {
      const company = companies.find(c => c.id === guest.companyId);
      if (company) setSelectedCompany(company);
    }
  };

  const nights = useMemo(() => {
    if (!checkInDate || !checkOutDate) return 0;
    const start = new Date(checkInDate);
    const end = new Date(checkOutDate);
    const diff = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    return diff > 0 ? diff : 0;
  }, [checkInDate, checkOutDate]);

  // Recalcular cargos repetitivos pendientes cuando cambian las noches
  useEffect(() => {
    if (nights <= 0) return;
    setPendingCharges(prev => prev.map(c => {
      if (!c.isRecurring) return c;
      const unit = parseFloat(c.amount) / (c.quantity || 1);
      return { ...c, quantity: nights, amount: String(unit * nights) };
    }));
  }, [nights]);

  const availableRooms = (() => {
    // Habitaciones bloqueadas por reservas que se superponen al período
    const blockedByReservation = new Set(
      allReservations
        .filter(r =>
          (r.status === "tentative" || r.status === "confirmed" || r.status === "checked_in" || r.status === "web_checkin" || r.status === "pending" || r.status === "reserved") &&
          r.roomId &&
          checkInDate && checkOutDate &&
          r.checkInDate < checkOutDate &&
          r.checkOutDate > checkInDate
        )
        .map((r: any) => r.roomId)
        .filter(Boolean)
    );

    return rooms?.filter((room) => {
      if (selectedRoomTypeId && room.roomTypeId !== selectedRoomTypeId) return false;
      if (!selectedRoomTypeId) return false;
      if (room.isActive === false) return false;
      if ((room as any).isVirtual) return false;
      // Tiene reserva que se superpone en esas fechas → no
      if (blockedByReservation.has(room.id)) return false;
      // En mantenimiento: verificar bloqueo activo
      if (room.status === "maintenance") {
        const hasActiveBlock = maintenanceBlocks.some(
          blk => blk.roomId === room.id &&
            checkInDate && checkOutDate &&
            blk.blockFrom < checkOutDate &&
            blk.blockTo > checkInDate
        );
        return !hasActiveBlock;
      }
      // available, inspected, dirty, cleaning → sí
      return true;
    })?.sort((a, b) => parseInt(a.roomNumber) - parseInt(b.roomNumber));
  })();

  // Tarifas: las del tipo seleccionado (filtradas en servidor), excluyendo las vencidas
  const applicableRatePlans = ratePlans?.filter((rp) => {
    if (rp.validTo && rp.validTo < checkInDate) return false; // plan vencido
    return true;
  });

  const selectedRatePlan = ratePlans?.find((rp) => rp.id === selectedRatePlanId);
  
  const baseRate = selectedRatePlanId === "__special__"
    ? (parseFloat(specialRateAmount) || 0)
    : (selectedRatePlan ? parseFloat(selectedRatePlan.baseRate) : 0);
  const finalRate = useMemo(() => {
    if (!baseRate) return 0;
    if (discountType === "percent") {
      return baseRate * (1 - parseFloat(discountValue) / 100);
    } else if (discountType === "fixed") {
      return Math.max(0, baseRate - parseFloat(discountValue));
    }
    return baseRate;
  }, [baseRate, discountType, discountValue]);

  const totalAmount = fmtMoney(finalRate * nights);
  // Valores para la API: siempre en formato decimal estándar (sin locale)
  const apiBaseRate = baseRate > 0 ? baseRate.toFixed(2) : null;
  const apiFinaRate = finalRate > 0 ? finalRate.toFixed(2) : null;
  const apiTotalAmount = (finalRate > 0 && nights > 0) ? (finalRate * nights).toFixed(2) : null;

  const createGuestMutation = useMutation({
    mutationFn: async (guest: InsertGuest): Promise<Guest> => {
      const res = await apiRequest("POST", "/api/guests", guest);
      return res.json();
    },
    onSuccess: (newGuest: Guest) => {
      queryClient.invalidateQueries({ queryKey: ["/api/guests"] });
      setSelectedGuest(newGuest);
      toast({
        title: "Huesped creado",
        description: `${newGuest.lastName} ${newGuest.firstName} ha sido registrado.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo crear el huesped.",
        variant: "destructive",
      });
    },
  });

  const createCompanyMutation = useMutation({
    mutationFn: async (company: InsertCompany): Promise<Company> => {
      const res = await apiRequest("POST", "/api/companies", company);
      return res.json();
    },
    onSuccess: (newCompany: Company) => {
      queryClient.invalidateQueries({ queryKey: ["/api/companies"] });
      setSelectedCompany(newCompany);
      toast({
        title: "Empresa creada",
        description: `${newCompany.razonSocial} ha sido registrada.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo crear la empresa.",
        variant: "destructive",
      });
    },
  });

  const createAgencyMutation = useMutation({
    mutationFn: async (agency: InsertAgency): Promise<Agency> => {
      const res = await apiRequest("POST", "/api/agencies", agency);
      return res.json();
    },
    onSuccess: (newAgency: Agency) => {
      queryClient.invalidateQueries({ queryKey: ["/api/agencies"] });
      setSelectedAgency(newAgency);
      toast({ title: "Agencia creada", description: `${newAgency.razonSocial} ha sido registrada.` });
    },
    onError: () => toast({ title: "Error", description: "No se pudo crear la agencia.", variant: "destructive" }),
  });

  const createReservationMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/reservations", {
        reservationCode: "",
        guestId: selectedGuest!.id,
        companyId: selectedCompany?.id || null,
        agencyId: selectedAgency?.id || null,
        roomTypeId: selectedRoomTypeId,
        roomId: selectedRoomId,
        ratePlanId: selectedRatePlanId === "__special__" ? null : (selectedRatePlanId || null),
        specialRateReason: selectedRatePlanId === "__special__" ? specialRateReason : null,
        checkInDate,
        checkOutDate,
        nights,
        baseRatePerNight: apiBaseRate,
        discountType,
        discountValue,
        finalRatePerNight: apiFinaRate,
        totalRoomAmount: apiTotalAmount,
        status: "confirmed",
        source: selectedAgency ? "agencia" : selectedCompany ? "empresa" : "directo",
        numberOfGuests,
        notes: notes || null,
        bedTypeId: null,
        bedTypeNotes: (bedTypeNotes && bedTypeNotes !== "__none__") ? bedTypeNotes : null,
        earlyCheckIn,
        earlyCheckInTime: earlyCheckInTime || null,
        earlyCheckInCharge: earlyCheckInCharge || null,
        lateCheckOut,
        lateCheckOutTime: lateCheckOutTime || null,
        lateCheckOutCharge: lateCheckOutCharge || null,
      });
      const created = await res.json();
      if (pendingCharges.length > 0 && created?.id) {
        const todayStr = getArgentinaToday();
        for (const charge of pendingCharges) {
          const totalAmt = charge.isRecurring
            ? charge.amount
            : (parseFloat(charge.amount) * charge.quantity).toFixed(2);
          const unitAmt = charge.isRecurring
            ? String(parseFloat(charge.amount) / (charge.quantity || 1))
            : undefined;
          await apiRequest("POST", "/api/charges", {
            description: charge.description,
            amount: totalAmt,
            category: charge.category,
            reservationId: created.id,
            date: todayStr,
            ...(charge.isRecurring && { isRecurring: true, unitAmount: unitAmt }),
          });
        }
      }
      return created;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reservations/check-in"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reservations/recent"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Reserva creada",
        description: "La reserva ha sido creada exitosamente.",
      });
      setLocation("/reservations");
    },
    onError: (error: any) => {
      const raw = error?.message || "";
      let description = "No se pudo crear la reserva. Intente nuevamente.";
      try {
        const jsonStart = raw.indexOf("{");
        if (jsonStart >= 0) {
          const parsed = JSON.parse(raw.substring(jsonStart));
          description = parsed.error || parsed.message || description;
        }
      } catch {}
      toast({ title: "No se pudo crear la reserva", description, variant: "destructive" });
    },
  });

  const canSubmit = selectedGuest && selectedRoomTypeId && selectedRoomId && nights > 0 && checkInDate && checkOutDate &&
    (selectedRatePlanId === "__special__"
      ? (specialRateReason.trim().length > 0 && parseFloat(specialRateAmount) > 0)
      : !!selectedRatePlanId);

  const sectionCardClass = (isComplete: boolean, isRequired: boolean): string => {
    if (isComplete) return "border-green-500 bg-green-50 dark:bg-green-950/30 dark:border-green-700 transition-colors";
    if (isRequired) return "border-amber-400 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-600 transition-colors";
    return "transition-colors";
  };

  const SectionStatus = ({ complete, required }: { complete: boolean; required?: boolean }) => {
    if (complete) return <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400 ml-auto flex-shrink-0" />;
    if (required) return <AlertCircle className="h-4 w-4 text-amber-500 ml-auto flex-shrink-0" />;
    return null;
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight" data-testid="text-new-reservation-title">
          Nueva Reserva
        </h1>
        <p className="text-muted-foreground">Complete los datos para crear una nueva reserva</p>
      </div>

      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="flex items-center gap-4 p-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <CalendarPlus className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold">Crear Reserva</h3>
            <p className="text-sm text-muted-foreground">
              Complete todos los campos requeridos para registrar la reserva
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <GuestSelector
            selectedGuest={selectedGuest}
            onSelect={handleGuestSelect}
            onCreateNew={(guest) => createGuestMutation.mutate(guest)}
            onClear={() => setSelectedGuest(null)}
            cardClassName={sectionCardClass(!!selectedGuest, true)}
          />

          <CompanySelector
            selectedCompany={selectedCompany}
            onSelect={setSelectedCompany}
            onCreateNew={(company) => createCompanyMutation.mutate(company)}
            onClear={() => setSelectedCompany(null)}
            cardClassName={sectionCardClass(!!selectedCompany, false)}
          />

          <AgencySelector
            selectedAgency={selectedAgency}
            onSelect={setSelectedAgency}
            onCreateNew={(agency) => createAgencyMutation.mutate(agency)}
            onClear={() => setSelectedAgency(null)}
            cardClassName={sectionCardClass(!!selectedAgency, false)}
          />

          <Card className={sectionCardClass(nights > 0, true)}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Fechas y Servicios especiales
                <SectionStatus complete={nights > 0} required />
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Fecha de Entrada</Label>
                  <Input
                    type="date"
                    value={checkInDate}
                    onChange={(e) => setCheckInDate(e.target.value)}
                    data-testid="input-checkin-date"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Fecha de Salida</Label>
                  <Input
                    type="date"
                    value={checkOutDate}
                    onChange={(e) => setCheckOutDate(e.target.value)}
                    min={checkInDate}
                    data-testid="input-checkout-date"
                  />
                </div>
              </div>
              {nights > 0 && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Badge variant="secondary">{nights} noche(s)</Badge>
                </div>
              )}
              <div className="border-t pt-3 grid gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sunrise className="h-4 w-4 text-orange-500" />
                    <Label htmlFor="nr-earlyCheckIn" className="cursor-pointer">Early Check-in</Label>
                    <span className="text-xs text-muted-foreground">(Estándar: 12:00 hs)</span>
                  </div>
                  <Switch
                    id="nr-earlyCheckIn"
                    checked={earlyCheckIn}
                    onCheckedChange={(checked) => { setEarlyCheckIn(checked); if (!checked) { setEarlyCheckInTime(""); setEarlyCheckInCharge(""); } }}
                    data-testid="switch-early-checkin"
                  />
                </div>
                {earlyCheckIn && (
                  <div className="grid grid-cols-2 gap-2 pl-6">
                    <div>
                      <Label className="text-xs">Hora acordada</Label>
                      <Input type="time" value={earlyCheckInTime} onChange={(e) => setEarlyCheckInTime(e.target.value)} data-testid="input-early-checkin-time" />
                    </div>
                    <div>
                      <Label className="text-xs">Cargo (vacío = cortesía)</Label>
                      <Input type="number" step="0.01" min="0" placeholder="0.00" value={earlyCheckInCharge} onChange={(e) => setEarlyCheckInCharge(e.target.value)} data-testid="input-early-checkin-charge" />
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sunset className="h-4 w-4 text-purple-500" />
                    <Label htmlFor="nr-lateCheckOut" className="cursor-pointer">Late Check-out</Label>
                    <span className="text-xs text-muted-foreground">(Estándar: 11:00 hs)</span>
                  </div>
                  <Switch
                    id="nr-lateCheckOut"
                    checked={lateCheckOut}
                    onCheckedChange={(checked) => { setLateCheckOut(checked); if (!checked) { setLateCheckOutTime(""); setLateCheckOutCharge(""); } }}
                    data-testid="switch-late-checkout"
                  />
                </div>
                {lateCheckOut && (
                  <div className="grid grid-cols-2 gap-2 pl-6">
                    <div>
                      <Label className="text-xs">Hora acordada</Label>
                      <Input type="time" value={lateCheckOutTime} onChange={(e) => setLateCheckOutTime(e.target.value)} data-testid="input-late-checkout-time" />
                    </div>
                    <div>
                      <Label className="text-xs">Cargo (vacío = cortesía)</Label>
                      <Input type="number" step="0.01" min="0" placeholder="0.00" value={lateCheckOutCharge} onChange={(e) => setLateCheckOutCharge(e.target.value)} data-testid="input-late-checkout-charge" />
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className={sectionCardClass(!!(selectedRoomTypeId && selectedRoomId), true)}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <DoorOpen className="h-4 w-4" />
                Habitacion
                <SectionStatus complete={!!(selectedRoomTypeId && selectedRoomId)} required />
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Tipo de Habitacion</Label>
                {isFromPlanning ? (
                  <div className="flex items-center gap-2">
                    <div className="flex-1 rounded-md border bg-muted px-3 py-2 text-sm" data-testid="text-room-type-prefilled">
                      {roomTypes?.find(rt => rt.id === selectedRoomTypeId)?.name || selectedRoomTypeId}
                    </div>
                    <Badge variant="secondary" className="text-xs">Desde planning</Badge>
                  </div>
                ) : (
                  <Select
                    value={selectedRoomTypeId}
                    onValueChange={(v) => {
                      setSelectedRoomTypeId(v);
                      setSelectedRoomId("");
                      setSelectedRatePlanId("");
                    }}
                  >
                    <SelectTrigger data-testid="select-room-type">
                      <SelectValue placeholder="Seleccionar tipo..." />
                    </SelectTrigger>
                    <SelectContent>
                      {roomTypes?.filter(rt => rt.id).map((rt) => (
                        <SelectItem key={rt.id} value={rt.id}>
                          {rt.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>

              <div className="space-y-2">
                <Label>Habitacion Disponible</Label>
                {isFromPlanning ? (
                  <div className="flex items-center gap-2">
                    <div className="flex-1 rounded-md border bg-muted px-3 py-2 text-sm" data-testid="text-room-prefilled">
                      {rooms?.find(r => r.id === selectedRoomId)
                        ? `Hab. ${rooms.find(r => r.id === selectedRoomId)!.roomNumber} - Piso ${rooms.find(r => r.id === selectedRoomId)!.floor}`
                        : selectedRoomId}
                    </div>
                    <Badge variant="secondary" className="text-xs">Desde planning</Badge>
                  </div>
                ) : (
                  <>
                    <Select
                      value={selectedRoomId}
                      onValueChange={setSelectedRoomId}
                      disabled={!selectedRoomTypeId}
                    >
                      <SelectTrigger data-testid="select-room">
                        <SelectValue placeholder={selectedRoomTypeId ? "Seleccionar habitacion..." : "Primero seleccione tipo"} />
                      </SelectTrigger>
                      <SelectContent>
                        {availableRooms?.filter(r => r.id).map((room) => {
                          const statusLabel: Record<string, string> = {
                            available: "",
                            inspected: " · Inspeccionada",
                            dirty: " · Sucia",
                            cleaning: " · En limpieza",
                            maintenance: " · Mantenimiento",
                          };
                          const statusDot: Record<string, string> = {
                            available: "🟢",
                            inspected: "🔵",
                            dirty: "🟠",
                            cleaning: "🟡",
                            maintenance: "🔴",
                          };
                          return (
                            <SelectItem key={room.id} value={room.id}>
                              {statusDot[room.status] ?? "⚪"} Hab. {room.roomNumber} - Piso {room.floor}{statusLabel[room.status] ?? ""}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                    {selectedRoomTypeId && availableRooms?.length === 0 && (
                      <p className="text-sm text-destructive">No hay habitaciones disponibles para este tipo</p>
                    )}
                  </>
                )}
              </div>

              <div className="space-y-2">
                <Label>Cantidad de Huespedes</Label>
                <Input
                  type="number"
                  min="1"
                  value={numberOfGuests}
                  onChange={(e) => setNumberOfGuests(parseInt(e.target.value) || 1)}
                  data-testid="input-guests"
                />
              </div>

              <div className="space-y-2">
                <Label>Tipo de camaje</Label>
                <Select
                  value={bedTypeNotes}
                  onValueChange={setBedTypeNotes}
                >
                  <SelectTrigger data-testid="select-bed-type">
                    <SelectValue placeholder="Seleccionar tipo de camaje..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">Sin especificar</SelectItem>
                    {bedConfigOptions.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card className={sectionCardClass(!!selectedRatePlanId, true)}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Tarifa y Descuentos
                <SectionStatus complete={!!selectedRatePlanId} required />
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Plan de Tarifa</Label>
                <Select
                  value={selectedRatePlanId}
                  onValueChange={(v) => { setSelectedRatePlanId(v); if (v !== "__special__") { setSpecialRateReason(""); setSpecialRateAmount(""); } }}
                  disabled={!selectedRoomTypeId}
                >
                  <SelectTrigger data-testid="select-rate-plan">
                    <SelectValue placeholder={selectedRoomTypeId ? "Seleccionar tarifa..." : "Primero seleccione tipo"} />
                  </SelectTrigger>
                  <SelectContent>
                    {applicableRatePlans?.filter(rp => rp.id).map((rp) => (
                      <SelectItem key={rp.id} value={rp.id}>
                        {rp.name} - ${rp.baseRate}/noche
                      </SelectItem>
                    ))}
                    <SelectItem value="__special__">⭐ Tarifa Especial (manual)</SelectItem>
                  </SelectContent>
                </Select>
                {selectedRatePlanId === "__special__" && (
                  <div className="space-y-3 p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-700 mt-2">
                    <div className="space-y-1.5">
                      <Label>Tarifa por noche <span className="text-destructive">*</span></Label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                        <Input type="number" min={0} step="0.01" placeholder="0.00" value={specialRateAmount} onChange={(e) => setSpecialRateAmount(e.target.value)} className="pl-7" data-testid="input-special-rate-amount" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Motivo <span className="text-destructive">*</span> <span className="font-normal text-muted-foreground text-xs">(aparece en informe diario y caja)</span></Label>
                      <Textarea placeholder="Ej: Convenio verbal, cliente frecuente, cortesía gerencia..." value={specialRateReason} onChange={(e) => setSpecialRateReason(e.target.value)} rows={2} data-testid="input-special-rate-reason" />
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Tipo de Descuento</Label>
                  <Select value={discountType} onValueChange={setDiscountType}>
                    <SelectTrigger data-testid="select-discount-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Sin descuento</SelectItem>
                      <SelectItem value="percent">Porcentaje (%)</SelectItem>
                      <SelectItem value="fixed">Monto fijo ($)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {discountType !== "none" && (
                  <div className="space-y-2">
                    <Label>Valor</Label>
                    <Input
                      type="number"
                      min="0"
                      value={discountValue}
                      onChange={(e) => setDiscountValue(e.target.value)}
                      data-testid="input-discount-value"
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Notas</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Notas adicionales sobre la reserva..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={5}
                data-testid="input-notes"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <ShoppingCart className="h-4 w-4" />
                Consumos / Cargos adicionales
                {pendingCharges.length > 0 && (
                  <Badge variant="secondary">{pendingCharges.length}</Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {pendingCharges.length === 0 && !showNrChargeForm && (
                <p className="text-sm text-muted-foreground">Sin cargos adicionales agregados.</p>
              )}
              {pendingCharges.length > 0 && (
                <div className="border rounded-md divide-y">
                  {pendingCharges.map((charge, idx) => (
                    <div key={idx} className="flex items-center justify-between px-3 py-2 text-sm">
                      <div className="flex items-center gap-1.5 flex-1 min-w-0">
                        {charge.isRecurring && (
                          <span className="text-xs px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 font-medium shrink-0">×noche</span>
                        )}
                        <span className="truncate">{charge.description}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 ml-2">
                        <span className="font-medium">${fmtMoney(charge.isRecurring ? parseFloat(charge.amount) : parseFloat(charge.amount) * charge.quantity)}</span>
                        <Button type="button" size="sm" variant="ghost" className="h-5 w-5 p-0 text-destructive" onClick={() => setPendingCharges(prev => prev.filter((_, i) => i !== idx))}>
                          <XCircle className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  <div className="flex justify-between px-3 py-2 text-sm font-semibold bg-muted/30">
                    <span>Total cargos</span>
                    <span>${fmtMoney(pendingCharges.reduce((sum, c) => sum + (c.isRecurring ? parseFloat(c.amount) : parseFloat(c.amount) * c.quantity), 0))}</span>
                  </div>
                </div>
              )}
              {showNrChargeForm && (
                <div className="border rounded-md p-3 space-y-2 bg-muted/20">
                  <Select value={nrChargePresetLabel} onValueChange={(val) => {
                    setNrChargePresetLabel(val);
                    const preset = nrChargePresets.find(p => p.label === val);
                    if (preset) { setNrChargeDesc(preset.description); setNrChargeAmount(preset.amount); setNrChargeCategory(preset.category); setNrChargeQty(1); setNrChargeRecurring(false); }
                  }}>
                    <SelectTrigger data-testid="select-nr-charge-preset"><SelectValue placeholder="Tipo de cargo..." /></SelectTrigger>
                    <SelectContent>
                      {nrChargePresets.filter(p => p.label).map(p => <SelectItem key={p.label} value={p.label}>{p.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <div className="grid grid-cols-4 gap-1 items-end">
                    <div className="col-span-2 space-y-1">
                      <Label className="text-xs text-muted-foreground">Descripción</Label>
                      <Input value={nrChargeDesc} onChange={(e) => setNrChargeDesc(e.target.value)} placeholder="Descripción" className="h-8 text-sm" data-testid="input-nr-charge-desc" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Precio unit.</Label>
                      <Input type="number" value={nrChargeAmount} onChange={(e) => setNrChargeAmount(e.target.value)} placeholder="0.00" className="h-8 text-sm" data-testid="input-nr-charge-amount" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Cant.</Label>
                      <Input type="number" min={1} value={nrChargeQty} onChange={(e) => { setNrChargeRecurring(false); setNrChargeQty(Math.max(1, parseInt(e.target.value) || 1)); }} className="h-8 text-sm" data-testid="input-nr-charge-qty" />
                    </div>
                  </div>
                  {/* Toggle cargo repetitivo — solo si el tipo lo permite */}
                  {nrChargePresets.find(p => p.label === nrChargePresetLabel)?.allowRecurring && (
                    <div className="flex items-center gap-3 py-1">
                      <Switch
                        id="nr-recurring-toggle"
                        checked={nrChargeRecurring}
                        onCheckedChange={(checked) => {
                          setNrChargeRecurring(checked);
                          setNrChargeQty(checked ? (nights || 1) : 1);
                        }}
                        data-testid="switch-nr-recurring-charge"
                      />
                      <Label htmlFor="nr-recurring-toggle" className="text-xs cursor-pointer select-none flex items-center gap-1.5">
                        <span>Cargo por noche</span>
                        {nrChargeRecurring && nights > 0 && (
                          <span className="text-muted-foreground">· {nights} noche{nights !== 1 ? "s" : ""}</span>
                        )}
                      </Label>
                    </div>
                  )}
                  {nrChargeAmount && nrChargeRecurring && nights > 0 && (
                    <div className="flex items-center rounded-md bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 px-3 py-2 text-sm">
                      <span className="text-blue-700 dark:text-blue-300 font-medium">
                        {nights} noches × ${fmtMoney(nrChargeAmount || "0")} = <span className="font-bold">${fmtMoney(String(parseFloat(nrChargeAmount || "0") * nights))}</span>
                      </span>
                    </div>
                  )}
                  <div className="flex justify-end gap-2">
                    <Button type="button" size="sm" variant="outline" onClick={() => { setShowNrChargeForm(false); setNrChargePresetLabel(""); setNrChargeDesc(""); setNrChargeAmount(""); setNrChargeQty(1); setNrChargeRecurring(false); }}>Cancelar</Button>
                    <Button type="button" size="sm" onClick={() => {
                      if (!nrChargeDesc || !nrChargeAmount) return;
                      const totalAmt = nrChargeRecurring
                        ? String(parseFloat(nrChargeAmount) * (nights || 1))
                        : nrChargeAmount;
                      const desc = nrChargeRecurring && nights > 1
                        ? `${nrChargeDesc} (x${nights})`
                        : nrChargeDesc;
                      setPendingCharges(prev => [...prev, {
                        description: desc,
                        amount: totalAmt,
                        category: nrChargeCategory,
                        quantity: nrChargeRecurring ? (nights || 1) : nrChargeQty,
                        ...(nrChargeRecurring && { isRecurring: true }),
                      }]);
                      setShowNrChargeForm(false); setNrChargePresetLabel(""); setNrChargeDesc(""); setNrChargeAmount(""); setNrChargeQty(1); setNrChargeRecurring(false);
                    }} data-testid="button-confirm-nr-charge">Agregar cargo</Button>
                  </div>
                </div>
              )}
              {!showNrChargeForm && (
                <Button type="button" size="sm" variant="outline" onClick={() => setShowNrChargeForm(true)} data-testid="button-toggle-nr-charge">
                  <Plus className="h-4 w-4 mr-1" />
                  Agregar cargo
                </Button>
              )}
            </CardContent>
          </Card>
          </div>
        </div>
      </div>

      <Card className="bg-muted/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Resumen de Reserva</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Huesped</p>
              <p className="font-medium">
                {selectedGuest ? `${selectedGuest.lastName} ${selectedGuest.firstName}` : "-"}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Habitacion</p>
              <p className="font-medium">
                {selectedRoomId ? rooms?.find(r => r.id === selectedRoomId)?.roomNumber : "-"}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Noches</p>
              <p className="font-medium">{nights}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total</p>
              <p className="font-medium text-lg">
                ${fmtMoney(finalRate * nights + pendingCharges.reduce((s, c) => s + parseFloat(c.amount || "0"), 0))}
              </p>
              {pendingCharges.length > 0 && (
                <p className="text-xs text-muted-foreground">
                  Hab. ${totalAmount} + cargos ${fmtMoney(pendingCharges.reduce((s, c) => s + parseFloat(c.amount || "0"), 0))}
                </p>
              )}
            </div>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <Button variant="outline" onClick={() => setLocation("/reservations")} data-testid="button-cancel">
              Volver
            </Button>
            <Button
              onClick={() => createReservationMutation.mutate()}
              disabled={!canSubmit || createReservationMutation.isPending}
              data-testid="button-create-reservation"
            >
              {createReservationMutation.isPending ? (
                "Creando..."
              ) : (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Crear Reserva
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
